import logging
import os
import sys
import uuid
import re
from datetime import datetime
from collections import OrderedDict
import subprocess
from dateutil.relativedelta import relativedelta
from sumoappclient.common.utils import get_normalized_path
from sumoappclient.common.logger import get_logger
import boto3
import yaml
import hcl
import signal

DATE_FORMAT = "%Y-%m-%d-%H-%M-%S"
FILE_PREFIX = "apptests"
LOG_FILES_DELETION_DAYS = 7
ALL_V1_APPS_FILENAME = "full_app_list.txt"
ALL_V2_APPS_FILENAME = "full_app_list.yaml"
PUSH_SCRIPT_FILENAME = "push_new_sumo_app.bash"
EXCLUDED_APP_PREFIXES = ("PCI/PCIv2", "SecurityApp", "//")
EXCLUDED_MODULE_LOGGING = ("requests", "urllib3")
EXCLUDED_APPS_WITHOUT_SC_PARAMS = (
    "Global Intelligence for Amazon GuardDuty",
    "Data Volume",
    "Data Volume (Legacy)",
    "Audit",
    "Artifactory",
    "Enterprise Audit - Collector & Data Forwarding Management",
    "Enterprise Audit - Content Management",
    "Enterprise Audit - Security Management",
    "Enterprise Audit - User & Role Management",
    "Global Intelligence for CloudTrail DevOps",
    "Global Intelligence for AWS CloudTrail SecOps",
    "Amazon EKS - Control Plane",
    "Kubernetes - Control Plane < 1.16",
    "Kubernetes - Control Plane >= 1.16",
    "PCI Compliance"
)
APP_CATEGORIES = ["Amazon Web Services", "Compliance and Security", "Database", "DevOps", "Google Cloud Platform", "IT Infrastructure", "Kubernetes", "Microsoft Azure", "Operating System", "Security", "Storage", "Sumo Logic", "Sumo Logic Certified", "Sumo Logic Global Intelligence", "Sumo Logic Solutions", "Tracing", "Web Server", "Work from Home Solution"]


def get_content_directory_from_wd():
    work_dir = os.getcwd()
    work_dir = work_dir.split("content")[0]
    work_dir = os.path.join(work_dir, "content")
    return work_dir


class ENVIRONMENT:
    CONTENT_DIR = os.getenv("SUMO_APPS_V1_REPO_PATH", get_content_directory_from_wd())
    SUMO_APP_UTILS_MODE = os.getenv("SUMO_APP_UTILS_MODE", "PARTNER")
    SUMO_DEPLOYMENT = os.getenv("SUMOLOGIC_ENVIRONMENT")


def get_content_dirpath():
    content_dirpath = ENVIRONMENT.CONTENT_DIR
    return get_normalized_path(content_dirpath)


def get_file_data(filepath):
    data = None
    with open(filepath) as fp:
        data = fp.read()
    return data


class USER(object):
    '''
        Do not trust these parameters anyone can modify them so use it for small things like creating folder

    '''

    @property
    def is_partner(self):
        return ENVIRONMENT.SUMO_APP_UTILS_MODE == "PARTNER"


USER = USER()


def touch(path):
    with open(path, 'a'):
        os.utime(path, None)


def get_test_log_dir():
    log_dir = os.path.join(os.getcwd(), "testlogs")
    if not os.path.isdir(log_dir):
        os.mkdir(log_dir)
    return log_dir


def get_test_log_file_name():

    BUILD_NUMBER = os.environ.get("BUILD_NUMBER", "UNKNOWN")
    ID = uuid.uuid4().hex[:8]
    current_date = datetime.now().strftime(DATE_FORMAT)
    FILENAME = "_".join([FILE_PREFIX, current_date,
                         BUILD_NUMBER, ID]) + '.log'
    LOGFILE = os.path.join(get_test_log_dir(), FILENAME)
    return LOGFILE


def do_cleanup(log):

    LOG_DIR = get_test_log_dir()
    last_week_date = datetime.now() - relativedelta(days=LOG_FILES_DELETION_DAYS)
    log.debug("Checking for older log files than %s in %s" % (
        last_week_date.strftime(DATE_FORMAT), LOG_DIR))
    for subdir, dirs, files in os.walk(LOG_DIR):
        for file in files:
            if file.startswith(FILE_PREFIX):
                name, created_date, _, _ = file.split("_")
                created_date = datetime.strptime(created_date, DATE_FORMAT)
                if created_date < last_week_date:
                    log.debug("deleting log file %s" % file)
                    os.remove(os.path.join(LOG_DIR, file))


def get_test_logger():
    log = logging.getLogger("testlogger")
    if not log.handlers:

        log.setLevel(logging.DEBUG)
        logFormatter = logging.Formatter("%(asctime)s | %(threadName)s | %(levelname)s | %(message)s")

        consoleHandler = logging.StreamHandler(sys.stdout)
        consoleHandler.setFormatter(logFormatter)
        log.addHandler(consoleHandler)

        filehandler = logging.FileHandler(get_test_log_file_name())

        filehandler.setFormatter(logFormatter)
        log.addHandler(filehandler)

        # disabling logging for requests/urllib3
        for module_name in EXCLUDED_MODULE_LOGGING:
            logging.getLogger(module_name).setLevel(logging.WARNING)

    return log


def run_cmd(cmd):
    logger = get_logger(__name__, ENABLE_LOGFILE=True, ENABLE_CONSOLE_LOG=True, LOG_FILEPATH="/tmp/sumoapptestutils.log", LOG_LEVEL=os.environ.get("LOG_LEVEL", "INFO"))
    logger.debug("running cmd: %s" % cmd)
    try:
        p = subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=True)
    except subprocess.CalledProcessError as e:
        logger.error('Error running command: ' + '"' + e.cmd + '"' + ' Return code: %s Output: %s' % (str(e.returncode), str(e.output)))
        return e.returncode, e.cmd
    return 0, p


def get_app_config_key(sourcefile):
    return os.path.splitext(os.path.basename(sourcefile))[0]


def delete_batch_files_in_s3(bucket_name, region, prefix=""):
    s3 = boto3.resource('s3', region)
    bucket = s3.Bucket(bucket_name)
    bucket.objects.filter(Prefix=prefix).delete()


def slugify(text,replace_char="-"):
    return re.sub('\W+', replace_char,text.strip().lower()).strip(replace_char)


def get_sanitized_app_name(appname):
    sanitized_app_name = "".join(map(lambda x: x.strip().capitalize(), re.split(r"-|_| ", appname)))
    return sanitized_app_name


def load_tf_to_json(filepath):
    if not os.path.isfile(filepath):
        raise Exception(f"{filepath} doesn't exist or incorrect path")
    if not filepath.endswith("tf"):
        raise Exception(f"{filepath} please provide tf file")
    try:
        with open(filepath, 'r') as fp:
            obj = hcl.load(fp)
    except Exception as e:
        raise Exception(f"Error in reading {filepath} {e}")

    return obj


def load_yaml_to_json(filepath):
    if not os.path.isfile(filepath):
        raise Exception(f"{filepath} doesn't exist or incorrect path")
    if not filepath.endswith("yaml") and not filepath.endswith("yaml.example"):
        raise Exception(f"{filepath} please provide yaml file")
    try:
        with open(filepath, 'r') as fp:
            json = yaml.safe_load(fp)
    except Exception as e:
        raise Exception(f"Error in reading {filepath} {e}")

    return json


def dump_jsondata_to_yaml(data, filepath):
    if not filepath.endswith("yaml"):
        raise Exception(f"{filepath} please provide yaml file")
    try:
        with open(filepath, 'w') as fp:
            if isinstance(data, OrderedDict):
                yaml.add_representer(OrderedDict, lambda dumper, data: dumper.represent_mapping('tag:yaml.org,2002:map', data.items()))
            yaml.safe_dump(data, fp, default_flow_style=False, sort_keys=False)
    except Exception as e:
        raise Exception(f"Error in writing {filepath} {e}")

    return True


def sort_report_data(data):

    if isinstance(data, dict):
        return {key: sort_report_data(value) for key, value in sorted(data.items())}
    elif isinstance(data, list):
        return [sort_report_data(item) for item in data]
    else:
        return data


class GracefulKiller:
    '''
        This is done so that the for loop exits when user does Ctrl-C
    '''
    kill_now = False

    def __init__(self):
        signal.signal(signal.SIGINT, self.exit_gracefully)
        signal.signal(signal.SIGTERM, self.exit_gracefully)

    def exit_gracefully(self, *args):
        self.kill_now = True


account_type_mapping = {
    "trial": "Trial",
    "free": "Free",
    "paid": "Paid",
    "demo": "Demo",
    "professional": "Professional",
    "slftrial": "SlfTrial",
    "test": "Test",
    "enterprise": "Enterprise",
    "essentials": "Essentials",
    "enterprise_ops": "EnterpriseOps",
    "enterprise_sec": "EnterpriseSec",
    "enterprise_suite": "EnterpriseSuite",
    "credits_free": "CreditsFree",
    "credits_trial": "CreditsTrial",
    "credits_pov_trial": "CreditsPovTrial"
}
