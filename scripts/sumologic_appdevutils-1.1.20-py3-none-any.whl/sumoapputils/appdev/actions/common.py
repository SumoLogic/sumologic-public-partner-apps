import requests
from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.find_uuid import FindUuidAction
import sys
import time


class Common:

    def find_uuid(self, params):
        if not state.app_uuid:
            app_uuid, _ = FindUuidAction().execute()
            utils.debug(f"No uuid given. Attempting to find uuid for app {state.app_name}")
            if app_uuid is None:
                utils.debug(f"No existing app with name {state.app_name} was found in any deployment.")
                sys.exit(1)
            else:
                utils.debug(f"Using existing uuid: {app_uuid} for installing app: {state.app_name}")
                state.app_uuid = app_uuid
                params['uuid'] = state.app_uuid
        params['uuid'] = state.app_uuid

    def _wait_for_job_completion(self, base_url: str, job_id: str, auth, timeout: int = 60) -> None:
        start_time = time.time()
        status = "InProgress"
        utils.info(f"Job for url {base_url} created with jobid: {job_id}")
        while status == "InProgress":
            if time.time() - start_time > timeout:
                return "Failed", {"error_message": f"Job timed out."}

            status_endpoint = f"{base_url}/{job_id}/status"
            response = requests.get(url=status_endpoint, auth=auth)
            response_json = response.json()
            status = response_json["status"]

            time.sleep(5)

        return status, response_json

    def uninstall(self, dep: str, params: dict, auth):
        response_json = ''
        try:
            response = requests.post(
                url=f"{utils.endpoint(dep)}/{params['uuid']}/uninstall",
                auth=auth,
                headers={'Content-Type': 'application/json'}
            )
            response_json = response.json()
            response.raise_for_status()
            jobId = response_json["jobId"]
            return self._wait_for_job_completion(f"{utils.endpoint(dep)}/uninstall", jobId, auth)
        except Exception as e:
            return 'Failed', response_json
