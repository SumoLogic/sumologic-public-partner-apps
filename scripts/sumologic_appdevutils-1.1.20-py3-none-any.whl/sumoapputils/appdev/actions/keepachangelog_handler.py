import os
import re
from datetime import datetime
import keepachangelog
from sumoapputils.appdev import utils
from collections import OrderedDict, defaultdict


class KeepachangelogHandler:
    top_content: str = """
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html)."""

    class ChangeType:
        ADDED = "added"
        CHANGED = "changed"
        DEPRECATED = "deprecated"
        REMOVED = "removed"
        FIXED = "fixed"
        SECURITY = "security"

    def __init__(self, app: dict = None, changelog_filepath: str = None, app_name: str = None):
        v2_repo_path = os.environ.get('SUMO_APPS_V2_REPO_PATH')
        self.changelog_filepath = changelog_filepath if changelog_filepath else f"{v2_repo_path}/src/{app['relativeFolderPath']}/CHANGELOG.md"
        self.app_name = app_name if app_name else app['name']
        self.__changelog_dict = self.__get_changelog(show_unreleased=True, get_original=True)

    def __get_changelog(self, show_unreleased: bool = False, get_original: bool = False):
        if get_original or not self.__changelog_dict:
            self.__changelog_dict = keepachangelog.to_dict(self.changelog_filepath, show_unreleased=show_unreleased)
        elif not show_unreleased and self.__changelog_dict.get("unreleased"):
            del self.__changelog_dict["unreleased"]

        return self.__changelog_dict

    def has_current_version(self, version) -> tuple:
        changelog_versions = list(self.__changelog_dict.keys())
        current_version = None if not changelog_versions else changelog_versions[0]
        if not current_version == version:
            return False, f"Current version {version} does not exists as latest version in changelog for app {self.app_name}"

        return True, ""

    def has_changelog_version(self, version) -> bool:
        return version in list(self.__changelog_dict.keys())

    def has_valid_format(self) -> dict:
        invalid_versions = defaultdict(list)
        for version in self.__changelog_dict.keys():
            if version != 'unreleased':
                #  Test semantic versioning (1.0.0)
                if re.search('^\d\.\d\.\d$', version) is None:
                    invalid_versions[version].append(f"Invalid format for version {version} in app {self.app_name}")

            for key in self.__changelog_dict[version].keys():
                if key == 'metadata':
                    #  Test date is present for each release
                    if version != 'unreleased' and self.__changelog_dict[version][key].get("release_date") is None:
                        invalid_versions[version].append(
                            f"Release date does not exists for {version} in app {self.app_name}"
                        )
                    continue

                #  Test change type belongs to categories defined in keepachangelog
                if key not in [
                    self.ChangeType.FIXED, self.ChangeType.ADDED, self.ChangeType.CHANGED, self.ChangeType.REMOVED, self.ChangeType.SECURITY, self.ChangeType.DEPRECATED
                ]:
                    invalid_versions[version].append(
                        f"Invalid ChangeType {key} for version {version} in app {self.app_name}"
                    )

        return invalid_versions

    def update_changelog(self, change_type, change_list, version="unreleased", write=False):
        version_changelog = self.__changelog_dict.get(version) or {
            "metadata": {"version": version}
        }
        if change_list:
            if version_changelog.get(change_type):
                version_changelog[change_type].extend(change_list)
                version_changelog[change_type] = set(version_changelog[change_type])
            else:
                version_changelog[change_type] = change_list
        else:
            if version_changelog.get(change_type):
                del version_changelog[change_type]

        self.__changelog_dict[version] = version_changelog

        if write:
            keys = list(self.__changelog_dict[version].keys())
            keys.remove("metadata")

            if not keys:
                del self.__changelog_dict[version]
            self.__write_changelog()

    def show_changelog(self, version="unreleased"):
        version_changelog = self.__changelog_dict.get(version)
        if version_changelog:
            print(f"\nExisting changelog for version {version}:")
            for change_type in version_changelog.keys():
                if change_type == "metadata":
                    continue

                changes = version_changelog.get(change_type)
                if changes:
                    print(f"## {change_type}")
                    for change in changes:
                        print(f"- {change}")

    def __write_changelog(self):
        changelog_ordered_dict: OrderedDict = OrderedDict()
        if self.__changelog_dict.get("unreleased"):
            changelog_ordered_dict["unreleased"] = self.__changelog_dict.pop("unreleased")
        for k in sorted(self.__changelog_dict, key=lambda x: x[0], reverse=True):
            changelog_ordered_dict[k] = self.__changelog_dict[k]

        self.content = keepachangelog.from_dict(changelog_ordered_dict).replace(self.top_content, "")
        with open(self.changelog_filepath, "w") as cl_file:
            cl_file.write(self.content)

    def release_unreleased_changelog(self, app_version):
        new_changelog_dict = {}
        if not self.__changelog_dict.get("unreleased"):
            utils.warn(f"Unreleased version for {self.app_name} not found")
            return False

        if self.__changelog_dict.get(app_version) is not None:
            utils.warn(f"Release version {app_version} for {self.app_name} app already exists")
            return False

        new_changelog_dict[app_version] = self.__changelog_dict["unreleased"]
        del self.__changelog_dict["unreleased"]
        new_changelog_dict[app_version]["metadata"]["version"] = app_version
        new_changelog_dict[app_version]["metadata"]["release_date"] = datetime.today().strftime("%Y-%m-%d")
        new_changelog_dict.update(self.__changelog_dict)
        self.__changelog_dict = new_changelog_dict
        self.__write_changelog()
        return True
