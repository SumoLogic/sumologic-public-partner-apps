from sumoapputils.appdev.actions.keepachangelog_handler import KeepachangelogHandler
from sumoapputils.appdev import utils
from sumoapputils.appdev.actions.verify_upload import VerifyUploadAction


class ReleaseChangelog:
    def execute(self, apps: list):
        for app in apps:
            app_version = VerifyUploadAction.get_latest_app_version_from_repo(utils.find_app_directory(app['name']))
            changelog_handler = KeepachangelogHandler(app)
            if changelog_handler.release_unreleased_changelog(app_version):
                utils.info(f"Changelog for app {app['name']} with version {app_version} is updated")
