import requests
from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.common import Common
from sumoapputils.common.utils import slugify, ALL_V2_APPS_FILENAME, load_yaml_to_json

class AppsVersionInfo(Common):

    def __init__(self):
        self.params = {}
        self.apps_by_deployment = {}

    def __getVersionInfo(self,dep,auth,uuid,version):
        try:
            response = requests.get(
                url=f"{utils.endpoint(dep)}/{uuid}/details?version={version}",
                auth=auth
            )
            response_json = response.json()
            if(response.status_code==200):
                utils.info(f"version found for uuid: {uuid} and version: {version}")
                return "Success", response_json
            else:
                utils.info(f"Details api failed with status code {response.status_code} for uuid: {uuid} and version: {version}")
                return "Failure", response_json
            
        except Exception as e:
            print("Exception Occured on calling details api")
            print(response_json)
            return 'Failure', response_json
        
        
    def execute(self,app_name, app_uuid, app_version):
        for dep in state.deployments:
            auth = utils.auth(dep)
            if auth is None:
                utils.warn(f"No auth found for {dep}. Skipping it.")
                self.apps_by_deployment[dep] = None
            else:
                utils.info(f"Checking availability of app: {app_name} with version : {app_version} on deployment: {dep}")
                app_found = False
                status, response = self.__getVersionInfo(dep, auth, app_uuid, app_version)
                if status == "Success":
                    app_found = True
                else:
                    app_found = False
                error_msg = ""
                if app_found:
                    utils.success(f"App name - {app_name} with version : {app_version} and UUID - {app_uuid} in deployment - {dep} is available")
                else:
                    error_msg = f"App not found. App name - {app_name} with version : {app_version} and UUID - {app_uuid} in deployment - {dep}"
                    utils.error(error_msg)
                return status, response