import json
import os
import shutil
from time import sleep
import traceback
import requests
from requests_toolbelt import MultipartEncoder
from sumoapputils.appdev.actions.version_info_appsv2 import AppsVersionInfo
from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.register import RegisterAction
from sumoapputils.appdev.utils import get_default_apps_directory


class UploadAction:

    UPLOAD_ZIP_FILESIZE_LIMIT = 8

    def __init__(self):
        self.app_dir = utils.find_app_directory(state.app_name)
        self.app_version = utils.get_version_from_manifest(self.app_dir)
        self.zip_path = None
        self.upload_job_ids = {}
        self.upload_job_statuses = {}
        self.upload_job_errors = {}

    def execute(self):
        try:
            RegisterAction().execute()
            self.zip_app()
            for dep in state.deployments:
                self.upload_app(dep)
            self.wait_on_upload_jobs()
            return self.upload_job_errors
        finally:
            self.remove_zip()

    def zip_app(self):
        # Todo use standard libraries (purge in utils) instead of find and hardcoded /tmp/
        # Todo put checks so that no other files get zipped apart from tf and manifest
        utils.debug(f"Zipping the {state.app_name} app from app directory {self.app_dir}")
        base_name = f'/tmp/{self.app_dir}'
        current_dir = os.getcwd()
        app_dir = os.path.join(get_default_apps_directory(),self.app_dir)
        os.chdir(app_dir)
        os.system("find . -name '.DS_Store' -delete")
        os.chdir(current_dir)
        shutil.make_archive(base_name, 'zip', get_default_apps_directory(), self.app_dir)
        self.zip_path = f"{base_name}.zip"

    def remove_zip(self):
        if self.zip_path is not None:
            os.remove(self.zip_path)

    def resolveUploadURL(self, dep: str, is_private: bool) -> str:
        version = state.app_version if state.app_version is not None else self.app_version
        if is_private:
            return f"{utils.endpoint(dep)}/private/{state.app_uuid}/"
        else:
            return f"{utils.endpoint(dep)}/{state.app_uuid}/{version}/"

    def upload_app(self, dep: str):
        if dep == "prod":
            status,response = AppsVersionInfo().execute(state.app_name,state.app_uuid,self.app_version)
            if status=="Success":
                utils.error(f"App: {state.app_name} and version {self.app_version} already exists in prod. We cannot replace app package in prod")
                raise Exception("Version already exists in prod")
        auth = utils.auth(dep)
        if auth is None:
            utils.warn(f"No auth found for {dep}. Skipping it.")
        else:
            utils.info(f"Uploading the app: {state.app_name} to deployment {dep}")
            with open(self.zip_path, 'rb') as zip_file:
                file_size = os.path.getsize(self.zip_path)
                file_size_mb = file_size / (1024 * 1024)
                if file_size_mb > self.UPLOAD_ZIP_FILESIZE_LIMIT:
                    self.upload_job_statuses[dep] = "Failed"
                    error_msg = f"Upload failed for deployment {dep}!, error: deployment file is greater than limit of {self.UPLOAD_ZIP_FILESIZE_LIMIT}MB"
                    self.upload_job_errors[dep] = error_msg
                    utils.error(error_msg)
                    return

                encoder = MultipartEncoder(
                    fields={'file': (f'{self.app_dir}.zip', zip_file, 'application/zip')}
                )
                app_upload_url = self.resolveUploadURL(dep, state.is_private)
                response = requests.put(
                    url=app_upload_url,
                    auth=utils.auth(dep),
                    data=encoder.to_string(),
                    headers={'Content-Type': encoder.content_type}
                )
                job_id = None
                try:
                    response.raise_for_status()
                    job_id = json.loads(response.text)['jobId']
                    utils.debug(f"Upload job created. jobId={job_id}")
                    self.upload_job_ids[dep] = job_id
                    self.upload_job_statuses[dep] = "InProgress"
                except:
                    self.upload_job_statuses[dep] = "Failed"
                    error_msg = f"Error in Upload API for App: {state.app_name} Url: {app_upload_url} response: {response.text} reason: {response.reason}"
                    self.upload_job_errors[dep] = error_msg
                    utils.error(f"Upload failed for deployment {dep}!\n{error_msg}")

    def resolveUploadJobStatusURL(self, dep: str, job_id: str, is_private: bool):
        if is_private:
            return f"{utils.endpoint(dep)}/private/upload/{job_id}/status"
        else:
            return f"{utils.endpoint(dep)}/upload/{job_id}/status"

    def update_job_status(self, dep: str):
        job_id = self.upload_job_ids[dep]
        app_status_url = self.resolveUploadJobStatusURL(dep, job_id, state.is_private)
        response = requests.get(
            url=app_status_url,
            auth=utils.auth(dep),
            headers={'Content-Type': 'application/json'}
        )
        try:
            response.raise_for_status()
            status = json.loads(response.text).get('status')
            if status == "Success":
                utils.success(f"Upload succeeded for App: {state.app_name} on deployment {dep}")
            elif status == "Failed":
                error_msg = f"Url: {app_status_url} response: {response.text} reason: {response.reason}"
        except Exception as e:
            error_msg = f"Error in Upload Job API for App: {state.app_name} Url: {app_status_url} response: {response.text} reason: {response.reason} traceback: {traceback.format_exc()}"
            status = "Failed"

        if status == "Failed":
            self.upload_job_errors[dep] = error_msg
            utils.error(f"Upload failed for deployment {dep}!\n{error_msg}")

        self.upload_job_statuses[dep] = status

    def get_unfinished_deps(self):
        return [dep for dep in state.deployments if self.upload_job_statuses.get(dep) == "InProgress"]

    def wait_on_upload_jobs(self):
        unfinished_deps = self.get_unfinished_deps()
        while unfinished_deps:
            utils.debug(f"Upload job statuses: {json.dumps(self.upload_job_statuses)}")
            utils.debug(f"Remaining deployments: {str(unfinished_deps)}")
            for dep in state.deployments:
                self.update_job_status(dep)
            sleep(5)
            unfinished_deps = self.get_unfinished_deps()
