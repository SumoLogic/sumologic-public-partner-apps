import requests
import sys
from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.find_uuid import FindUuidAction


class DeleteAction:

    def __init__(self):
        self.params = {}
        self.app_delete_errors = {}

    def execute(self):
        self.find_uuid()
        for dep in state.deployments:
            self.__delete_app(dep)
        return self.app_delete_errors

    def find_uuid(self):
        if not state.app_uuid:
            app_uuid, _ = FindUuidAction().execute()
            utils.info(f"No uuid given. Attempting to find uuid for app {state.app_name}")
            if app_uuid is None:
                utils.info(f"No existing app with name {state.app_name} was found in any deployment.")
                sys.exit(1)
            else:
                utils.info(f"Using existing uuid: {app_uuid} for deleting app: {state.app_name}")
                state.app_uuid = app_uuid
        self.params['uuid'] = state.app_uuid

    def resolveDeleteURL(self, dep: str, is_private: bool):
        if is_private:
            return f"{utils.endpoint(dep)}/private/{self.params['uuid']}"
        else:
            return f"{utils.endpoint(dep)}/{self.params['uuid']}"

    def __delete_app(self, dep: str):
        utils.info(f"Deleting app: {state.app_name} on deployment: {dep}")
        auth = utils.auth(dep)
        if auth is None:
            utils.warn(f"No auth found for {dep}. Skipping it.")
            self.apps_by_deployment[dep] = None
        else:
            response = requests.delete(
                url=self.resolveDeleteURL(dep, state.is_private),
                auth=auth,
                headers={'Content-Type': 'application/json'}
            )
            if response.ok:
                utils.success(f"Successfully Deleted app: {state.app_name} for deployment {dep}")
            else:
                error_msg = f"Deletion failed for app: {state.app_name} on deployment {dep}!\n{response.content}"
                utils.error(error_msg)
                self.app_delete_errors[dep] = error_msg
