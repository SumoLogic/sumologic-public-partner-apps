from datetime import datetime
import difflib
import json
import os
import sys
import re
import shutil
from collections import OrderedDict
from json import JSONEncoder
from types import SimpleNamespace

import click
import yaml
from requests.auth import HTTPBasicAuth
from sumoapputils.common.testutils import get_test_class
from sumoapputils.common.utils import run_cmd, get_file_data
from sumoappclient.common.utils import get_normalized_path

default_extract_keys = ["name", "panels.name", "type", "*.title", "*.queryString", "*.description", "*.searchQuery",
                        "*.timeRange", "*.timerange", "*.queryText", "*.query", "*.defaultTimeRange"]

internal_external_map = {"syd": "au", "mon": "ca", "fra": "de", "dub": "eu", "mum": "in", "tky": "jp", "prod": "us1", "kr": "kr"}

CURRENT_LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")

LOG_LEVEL_MAP = {
    "DEBUG": 10,
    "INFO": 20,
    "SUCCESS": 20,
    "WARNING": 30,
    "ERROR": 40
}


class SumoLogicCredentialsNotFound(Exception):
    pass


def show_diff(text, n_text):
    class Colors:
        # RED = '\033[91m'
        RED = '\033[31m'
        END = '\033[0m'
        # END = '\033[m'
        GREEN = '\033[32m'

    seqm = difflib.SequenceMatcher(None, text, n_text)
    output = []
    for opcode, a0, a1, b0, b1 in seqm.get_opcodes():
        if opcode == 'equal':
            output.append(seqm.a[a0:a1])
        elif opcode == 'insert':

            output.append(Colors.GREEN + seqm.b[b0:b1] + Colors.END)
        elif opcode == 'delete':

            output.append(Colors.RED + seqm.a[a0:a1] + Colors.END)
        elif opcode == 'replace':
            # pass
            # seqm.a[a0:a1] -> seqm.b[b0:b1]
            output.append(Colors.RED + seqm.a[a0:a1] + Colors.END)
            output.append(Colors.GREEN + seqm.b[b0:b1] + Colors.END)
        else:
            raise Exception("unexpected opcode")
    return ''.join(output)


def show_vimdiff(old_file, new_file):
    return_code, cmd = run_cmd(
        "vimdiff %s %s -c 'colo molokai' -c TOhtml -c 'w! diff.html' -c 'qa!'" % (old_file, new_file))
    if return_code:
        raise Exception(
            "Makesure you are running this command in unix systems with vimdiff installed. Process code: %d" % return_code)
    if not os.path.isfile("diff.html"):
        raise Exception('Unable to find generated diff.html')
    return_code, cmd = run_cmd("open diff.html")
    if return_code:
        raise Exception("Unable to open html file. Process code: %d" % return_code)


def is_key_present(preserve_keys, cur_key):
    for key in preserve_keys:
        if key.startswith("*"):

            if cur_key.endswith(key.rsplit(".", 1)[-1]):
                return True
        elif key == cur_key:
            return True
    return False


def filterjson(jsonobj, preserve_keys, cur_key=""):
    next_key = cur_key + "." if cur_key else cur_key
    has_any_preserved_key = flag = False
    if jsonobj:
        if isinstance(jsonobj, dict):
            keys_to_delete = []
            for k, v in jsonobj.items():
                if is_key_present(preserve_keys, next_key + k):
                    flag = True
                elif isinstance(v, (dict, list)):
                    # dict of dict # dict of list
                    jsonobj[k], flag = filterjson(v, preserve_keys, next_key + k)
                    if not is_key_present(preserve_keys, next_key + k) and not flag:
                        keys_to_delete.append(k)
                elif not is_key_present(preserve_keys, next_key + k):
                    keys_to_delete.append(k)
                    flag = False

                has_any_preserved_key = flag or has_any_preserved_key
            # if keys_to_delete:
            #     print('deleting keys', keys_to_delete)
            # else:
            #     print('preserving', jsonobj.keys())
            for k in keys_to_delete:
                del jsonobj[k]
        elif isinstance(jsonobj, list):
            for idx, item in enumerate(jsonobj):
                if isinstance(item, (dict, list)):
                    # list of dict #list of list
                    jsonobj[idx], flag = filterjson(item, preserve_keys, cur_key)
                    has_any_preserved_key = flag or has_any_preserved_key

    return jsonobj, has_any_preserved_key


def generate_mini_appfile(filepath, extract_keys):
    appjson = get_file_data(filepath)
    appDict = json.loads(appjson, object_pairs_hook=OrderedDict)
    dashboard_class = get_test_class(appjson=appDict)
    dashboards, searches = dashboard_class.get_content(appDict)
    dashboard_class.remove_text_panels(dashboards)

    dashboards = dashboard_class.order_dashboards_by_name(dashboards)
    dashboards = dashboard_class.order_panels_by_name(dashboards)
    searches = dashboard_class.order_searches_by_name(searches)
    filterjson(dashboards, extract_keys)
    filterjson(searches, extract_keys)
    output = {"appname": appDict["name"], "dashboards": dashboards, "searches": searches}
    if "description" in extract_keys:
        output["description"] = appDict["description"]
    return output


def success(*args):
    if LOG_LEVEL_MAP["SUCCESS"] >= LOG_LEVEL_MAP[CURRENT_LOG_LEVEL]:
        click.echo(str(datetime.now()) + " " + click.style(*args, fg='green'))


def info(*args):
    if LOG_LEVEL_MAP["INFO"] >= LOG_LEVEL_MAP[CURRENT_LOG_LEVEL]:
        click.echo(str(datetime.now()) + " " + click.style(*args, fg='white'))


def error(*args):
    if LOG_LEVEL_MAP["ERROR"] >= LOG_LEVEL_MAP[CURRENT_LOG_LEVEL]:
        click.echo(str(datetime.now()) + " " + click.style(*args, fg='red'))


def warn(*args):
    if LOG_LEVEL_MAP["WARNING"] >= LOG_LEVEL_MAP[CURRENT_LOG_LEVEL]:
        click.echo(str(datetime.now()) + " " + click.style(*args, fg='magenta'))


def debug(*args):
    if LOG_LEVEL_MAP["DEBUG"] >= LOG_LEVEL_MAP[CURRENT_LOG_LEVEL]:
        click.echo(str(datetime.now()) + " " + click.style(*args, fg='yellow'))


def pretty_json(json_str):
    return json.dumps(json.loads(json_str), indent=2)


def get_api_deployments():
    return ['stag', 'long', "in", "au", "de", "jp", "ca", "eu", "fed", "us2", "us1", "kr"]


def get_all_authorized_deployments():
    return filter_deployments(['stag', 'long', 'mum', 'syd', 'fra', 'tky', 'mon', 'dub', 'fed', 'us2', 'prod', 'kr'])


def filter_deployments(deps):
    result = []
    for d in deps:
        try:
            if auth(d) is not None:
                result.append(d)
        except SumoLogicCredentialsNotFound:
            error(f"Error in getting credentials for deployment {d}:  {SumoLogicCredentialsNotFound}. Remove deployment entries with empty string (access_id/access_key) from json credential file.")

    return result


def get_endpoint(deployment):
    if deployment in internal_external_map:
        deployment = internal_external_map[deployment]

    prod_deployments = [dep for dep in get_api_deployments() if dep not in ('stag', 'long')]
    if deployment == "us1" or deployment == "prod":
        return "https://api.sumologic.com/api"
    elif deployment in prod_deployments:
        return "https://api.%s.sumologic.com/api" % deployment
    elif deployment in ('stag', 'long'):
        return 'https://%s-api.sumologic.net/api' % deployment
    else:
        return 'https://%s-api.ephemeral.in/api' % deployment


def apps_v1_repo_path():
    path = os.environ.get('SUMO_APPS_V1_REPO_PATH')
    if not path:
        error("Apps repo path must be provided via environment variable SUMO_APPS_V1_REPO_PATH !")
        sys.exit(1)
    path = get_normalized_path(path)
    if not os.path.isdir(path):
        error(f"Apps repo path: {path} does not exists!")
        sys.exit(1)

    return path


def apps_v2_repo_path():
    path = os.environ.get('SUMO_APPS_V2_REPO_PATH')
    if not path:
        error("Apps repo path must be provided via environment variable SUMO_APPS_V2_REPO_PATH !")
        sys.exit(1)
    path = get_normalized_path(path)
    if not os.path.isdir(path):
        error(f"Apps repo path: {path} does not exists!")
        sys.exit(1)

    return path


def find_app_directory(name):
    all_app_directories = next(os.walk(get_default_apps_directory()))[1]
    for app_dir in all_app_directories:
        manifest_path = os.path.join(get_default_apps_directory(), app_dir, "manifest.yaml")
        if os.path.exists(manifest_path):
            with open(manifest_path, 'r') as file:
                if yaml.safe_load(file)['name'] == name:
                    return app_dir

    error(f"No app directory was found for app with name {name}")
    sys.exit(1)


def get_version_from_manifest(app_dir: str):
    manifest_path = os.path.join(get_default_apps_directory(), app_dir, "manifest.yaml")
    if os.path.exists(manifest_path):
        with open(manifest_path, 'r') as file:
            return yaml.safe_load(file)['version']
    else:
        error(f"Manifest File {manifest_path} not Found")
        sys.exit(1)


def endpoint(deployment):
    return f"{get_endpoint(deployment)}/v2/apps"


def get_deployment_keys(deployment: str):
    access_id = os.environ.get('SUMO_ACCESS_ID')
    access_key = os.environ.get('SUMO_ACCESS_KEY')

    if access_id and access_key:
        return access_id, access_key

    path = os.environ.get('SUMO_ACCESS_KEYS_FILE_PATH')
    if not path:
        raise SumoLogicCredentialsNotFound("Access keys file path must be provided via environment variable SUMO_ACCESS_KEYS_FILE_PATH !")

    path = get_normalized_path(path)
    if not os.path.isfile(path):
        raise SumoLogicCredentialsNotFound(f"Access keys file path: {path} does not exists!")

    with open(path) as file:
        keys_map = json.load(file)
        auth_for_dep = keys_map.get(deployment)
        if auth_for_dep:
            access_id = auth_for_dep.get('access_id', "")
            access_key = auth_for_dep.get('access_key', "")

            if access_id and access_key:
                return access_id, access_key
            else:
                raise SumoLogicCredentialsNotFound("Access keys and Access ids not found")

    return None, None


def slugify_text(text):
    # replacing any contiguous sequence of non alphabet(spaces, "_" etc) with underscore `-`
    text = re.sub(r"[ @_!#$%^&*()<>?/\|}{~:`',\\]+", '-', text.strip())
    # replacing any contiguous - with single -
    text = re.sub(r"[-]+", '-', text.strip())

    # remove last -
    text = text.strip("-")
    return text


def auth(deployment: str):
    access_id, access_key = get_deployment_keys(deployment)
    if access_id and access_key:
        return HTTPBasicAuth(access_id, access_key)

    return None


class ns_encoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, SimpleNamespace):
            return obj.__dict__
        return super(ns_encoder, self).default(obj)


def copytree(src, dst, symlinks=False, ignore=None):
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            shutil.copytree(s, d, symlinks, ignore)
        else:
            shutil.copy2(s, d)


def get_default_apps_directory():
    root_apps_dir = apps_v2_repo_path()
    apps_folder = os.path.join(root_apps_dir, "src")
    return apps_folder


def purge(dir, pattern):
    for root, dirs, files in os.walk(dir):
        for filename in files:
            if re.search(pattern, filename):
                filepath = os.path.join(root, filename)
                os.remove(filepath)


def read_file(file_path: str):
    """Read content from a file."""
    try:
        with open(file_path, 'r') as file:
            return file.read()
    except IOError as e:
        print(f"Error reading file {file_path}: {e}")
        return None


def write_file(file_path: str, content: str):
    try:
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(content)
    except IOError as e:
        print(f"Error writing to file {file_path}: {e}")


def append_to_file(file_path: str, content: str):
    try:
        with open(file_path, 'a', encoding='utf-8') as file:
            file.write(content)
    except IOError as e:
        print(f"Error appending to file {file_path}: {e}")


def extract_moved_blocks(text: str):
    """Extract 'moved' blocks from the given text."""
    pattern = r'(moved\s*\{[^}]*\})'
    return re.findall(pattern, text, re.DOTALL)


def format_moved_blocks(blocks: list):
    """Format the extracted blocks."""
    return "\n\n".join(block.strip() for block in blocks)


def process_folders_tf(folders_tf_path: str, folders_tf_text: str):
    moved_blocks = []
    if os.path.isfile(folders_tf_path):
        content = read_file(folders_tf_path)
        if content:
            moved_blocks = extract_moved_blocks(content)
    write_file(folders_tf_path, folders_tf_text)
    if moved_blocks:
        append_to_file(folders_tf_path, format_moved_blocks(moved_blocks))
