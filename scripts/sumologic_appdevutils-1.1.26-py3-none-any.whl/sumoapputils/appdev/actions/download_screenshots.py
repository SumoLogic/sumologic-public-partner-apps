import requests
import json
import shutil
import os
import traceback
from sumoapputils.appdev import utils
from sumoapputils.appdev.actions.translate_content import BaseContent
from sumoapputils.common.appmanifest import AppManifestV2SchemaV2AppOnly
from sumoapputils.common.utils import load_yaml_to_json
from PIL import Image
from typing import Any, Dict, List


class DownloadScreenshotAction(BaseContent):

    def get_screenshot_folder(self, slugified_app_folder_name, output_folder_path):
        if not output_folder_path:
            current_directory = os.getcwd()
            screenshot_folderpath = os.path.join(current_directory, slugified_app_folder_name)
            if not os.path.exists(screenshot_folderpath):
                os.makedirs(screenshot_folderpath)
        else:
            screenshot_folderpath = output_folder_path
        return screenshot_folderpath

    def execute(self, app_folder_name, appfolderpath, output_folder_path=None, require_uncropped_images=False, force_download=False, time_range="-24h"):
        file_ext = "png"
        utils.info(f"Downloading Screenshot for app folder: {app_folder_name}")
        appMedia = []
        try:
            if appfolderpath.lower() == "personal":
                parent_app_folder = self.get_personal_folder()
            elif appfolderpath.lower() == "installed apps":
                parent_app_folder = self.get_global_folder()
            app_folder_id = self.get_app_folder_id(app_folder_name, parent_app_folder)
            if not app_folder_id:
                raise Exception("folder does not exists please install it.")
            all_content = self.get_all_content(app_folder_id)
            v2_dashboards = self.get_v2_dashboards(all_content)
            v2_dashboard_contendIds = [dashboard['id'] for dashboard in v2_dashboards]
            v2_dashboards = self.get_dashboards_by_contentId(v2_dashboard_contendIds)
            screenshot_folderpath = self.get_screenshot_folder(utils.slugify_text(app_folder_name), output_folder_path)
            fail_count = 0
            for dashboard in v2_dashboards:
                dashboard_name = dashboard.get("title")
                variables = dashboard.get("variables")
                utils.debug(f"fetching screenshot for {dashboard_name}")
                dashboard_screenshot_uncropped_image_name = "%s_uncropped.%s" % (utils.slugify_text(dashboard_name), file_ext)
                dashboard_screenshot_cropped_image_name = "%s.%s" % (utils.slugify_text(dashboard_name), file_ext)
                downloaded_screenshot_raw_image_path = os.path.join(screenshot_folderpath, dashboard_screenshot_uncropped_image_name)
                cropped_screenshot_image_path = os.path.join(screenshot_folderpath, dashboard_screenshot_cropped_image_name)
                appMedia.append({
                    "title": dashboard_name,
                    "description": dashboard.get("description", ''),
                    "type": "image",
                    "location": f"./assets/images/preview/{dashboard_screenshot_cropped_image_name}"
                })
                if (not os.path.isfile(cropped_screenshot_image_path)) or force_download:
                    try:
                        self.__take_dashboard_screenshot(dashboard['id'], variables, downloaded_screenshot_raw_image_path, time_range)
                        self.__crop_dashboard_screenshot(downloaded_screenshot_raw_image_path, cropped_screenshot_image_path, require_uncropped_images)
                    except Exception as e:
                        utils.error(f"Error in downloading screenshot of {dashboard_name} error: {e}. download it manually")
                        fail_count += 1
                else:
                    utils.warn(f"Skipped downloading : screenshot {cropped_screenshot_image_path} already present! Use --force_download_images flag to replace it.")
            if fail_count > 0:
                utils.error(f"{fail_count} screenshots failed to download for app {app_folder_name}!")
                return False
            else:
                self.update_app_media_section(appMedia, output_folder_path)
                utils.info(f"All screenshots for app {app_folder_name} downloaded successfully!")
                return True
        except Exception as e:
            utils.error(f"Error occurred in downloading screenshots for app {app_folder_name} Error: {e} Traceback: {traceback.format_exc()}")
            return False

    def update_app_media_section(self, appMedia, output_folder_path):
        assets_folderpath = os.path.join("assets", "images", "preview")
        if not (assets_folderpath in output_folder_path):
            utils.warn("Not updating manifest.yaml, output folder path does not contain assets/images/preview")
            return
        manifestFilePath = os.path.join(os.path.abspath(os.path.expanduser(output_folder_path)).replace(assets_folderpath, ""), "manifest.yaml")
        if not os.path.exists(manifestFilePath):
            utils.warn(f"Not updating manifest.yaml,  filepath: {manifestFilePath} not found")
            return

        manifestjson = load_yaml_to_json(manifestFilePath)
        manifestjson["appMedia"] = appMedia
        manifestjson["installable"] = True
        AppManifestV2SchemaV2AppOnly.update_manifest(manifestjson, manifest_filepath=manifestFilePath)
        utils.warn(f"Updated manifest.yaml with {len(appMedia)} entries")

    def get_v2_dashboards(self, content_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return [item for item in content_list if item['itemType'] == 'Dashboard']

    def __take_dashboard_screenshot(self, dashboard_id, variables, image_filepath, time_range):
        auth = utils.auth(self.deployment)
        if auth is None:
            utils.warn(f"No auth found for {self.deployment}. Skipping it.")
            self.apps_by_deployment[self.deployment] = None
        else:
            download_endpoint = f"{utils.get_endpoint(self.deployment)}/v2/dashboards/reportJobs"
            payload = {
                "action": {
                    "actionType": "DirectDownloadReportAction"
                },
                "exportFormat": "Png",
                "timezone": "America/Los_Angeles",
                "template": {
                    "templateType": "DashboardTemplate",
                    "id": dashboard_id,
                    "timeRange": {
                        "type": "BeginBoundedTimeRange",
                        "from": {
                            "type": "RelativeTimeRangeBoundary",
                            "relativeTime": time_range
                        }
                    }
                }
            }
            if variables:
                payload["template"]["variableValues"] = {
                    "data": {variable.get("name"): [variable.get("defaultValue", "*")] for variable in variables}
                }

            response = requests.post(
                url=download_endpoint,
                auth=auth,
                headers={'Content-Type': 'application/json'},
                data=json.dumps(payload)
            )
            if response.ok:
                job_id = json.loads(response.content)['id']

                self._wait_for_job_completion(download_endpoint, job_id)

                # downloading actual raw image file
                download_result_endpoint = f"{download_endpoint}/{job_id}/result"
                response = requests.get(
                    url=download_result_endpoint,
                    auth=auth,
                    headers={'Content-Type': 'application/json'},
                    stream=True
                )
                if response.ok:
                    with open(image_filepath, 'wb') as fout:
                        shutil.copyfileobj(response.raw, fout)
                else:
                    raise Exception(f"Error in dashboard_id: {dashboard_id} for {image_filepath} in dashboards/reportJobs/result api: {response.content}")
            else:
                raise Exception(f"Error in dashboard_id: {dashboard_id} for {image_filepath} in dashboards/reportJobs api: {response.content}")

    def __crop_dashboard_screenshot(self, source_imagepath, target_imagepath, require_uncropped_images):

        image = Image.open(source_imagepath)
        utils.info(f"Original Dimensions of {source_imagepath}: {image.getbbox()}")
        # background color for dark themed screenshots
        bg_color = (16, 24, 39, 255)
        img_copy = image.copy()
        for y in range(img_copy.size[1]):
            for x in range(img_copy.size[0]):
                if img_copy.getpixel((x, y)) == bg_color:
                    img_copy.putpixel((x, y), (0, 0, 0, 0))

        # img_copy.save('%s' % source_imagepath.replace(".png","_colored.png"))
        (topLeftX, topLeftY, bottomRightX, bottomRightY) = img_copy.getbbox()
        utils.info(f"Cropping {source_imagepath}: {(0, 0, bottomRightX, bottomRightY)}")
        cropped = image.crop((0, 0, bottomRightX, bottomRightY))
        cropped.save(target_imagepath)
        if not require_uncropped_images:
            os.remove(source_imagepath)
