import os
import re
from typing import List

from sumoapputils.appdev import utils
from sumoapputils.appdev.actions.base_content import BaseContent


class ExportFields(BaseContent):

    def __init__(self, *args, **kwargs):
        super(ExportFields, self).__init__(*args, **kwargs)

    def execute(self, output_path: str, fields: List[str], force_update=False):
        try:
            collection_path = self.create_collection_folder(output_path)
            tf_file_path = os.path.join(collection_path, "fields.tf")

            if os.path.exists(tf_file_path) and not force_update:
                utils.warn("Error: fields.tf already exists. Use force_update flag to overwrite.")
                pass

            self.generate_tf_file(fields, tf_file_path)
            ExportFields.add_depends_on(os.path.join(output_path, "resources", "dashboards.tf"), lookforward_pattern="layout", field_list=fields)
            ExportFields.add_depends_on(os.path.join(output_path, "resources", "monitors.tf"), lookforward_pattern="queries", field_list=fields)
            ExportFields.add_depends_on(os.path.join(output_path, "resources", "logSearches.tf"), lookforward_pattern="time_range", field_list=fields)

            utils.info(f"fields.tf file created successfully at {tf_file_path}")

        except Exception as e:
            utils.error(f"Error: An unexpected error during fields creation error: {e}")

    @classmethod
    def add_depends_on(cls, tf_file_path, lookforward_pattern, field_list=None, fields_file_path=None):
        if not os.path.exists(tf_file_path):
            utils.warn(f"Error: {tf_file_path} does not exists.")
            return

        delete_depends_on = False
        if not field_list:
            if not os.path.exists(fields_file_path):
                utils.warn(f"Error: {fields_file_path} does not exists. Either provide field_list or fields_file_path")
                delete_depends_on = True
            else:
                field_list = cls.get_fields_from_file(fields_file_path)

        try:
            depends_on_text = "\n" if delete_depends_on else f"depends_on = [{','.join(f'sumologic_field.{field}' for field in field_list)}]\n"
            with open(tf_file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            processed_lines = []
            skip_depends_on = False
            for idx, line in enumerate(lines):
                # assuming monitor_type will appear before "queries" attribute in monitors.tf
                stripped_line = line.lstrip()

                if re.match("depends_on\\s*=", stripped_line):
                    continue
                else:
                    if re.match("monitor_type\s*=\s*\"Logs\"", stripped_line):
                        skip_depends_on = False
                    elif re.match("monitor_type\s*=\s*\"Metrics\"", stripped_line):
                        skip_depends_on = True
                    if not skip_depends_on and re.match(f"{lookforward_pattern}\\s*{{", stripped_line):
                        processed_lines.append(depends_on_text)
                    processed_lines.append(line)
            with open(tf_file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred while adding depends_on in {tf_file_path}: {e}")

    @staticmethod
    def get_fields_from_file(fields_file_path):
        field_list = set()
        pattern = re.compile(f"sumologic_field\s+\(?<field_name>\w+\)\\s*{{")  # Compile regex once

        try:
            with open(fields_file_path, 'r', encoding='utf-8') as file:
                for line in file:
                    match = pattern.match(line.lstrip())  # Strip and match in one step
                    if match:
                        field_list.add(match.group(1))
        except FileNotFoundError:
            print(f"Error: File not found - {fields_file_path}")
        except IOError as e:
            print(f"Error reading file {fields_file_path}: {e}")

        return field_list

    def create_collection_folder(self, parent_path):
        collection_path = os.path.join(parent_path, "collection")
        if not os.path.exists(collection_path):
            os.makedirs(collection_path)
        return collection_path

    def generate_tf_file(self, fields, file_path):
        with open(file_path, 'w') as f:
            for field in fields:
                f.write(f'resource "sumologic_field" "{field}"' + ' {\n')
                f.write('\tdata_type  = "String"\n')
                f.write(f'\tfield_name = "{field}"\n')
                f.write('\tstate      = "Enabled"\n')
                f.write('}\n\n')
