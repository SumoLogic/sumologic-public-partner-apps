from typing import Dict, List
from dataclasses import dataclass
from enum import Enum
import os
from sumoapputils.common.utils import load_tf_to_json, load_yaml_to_json
from sumoapputils.appdev import utils
from sumoapputils.appdev.appreviewer.content_visual_quality_review import ContentImageQualityReviewGenerator
from sumoapputils.appdev.appreviewer.basereview import BaseReviewGenerator
from sumoapputils.appdev.appreviewer.bedrockbackend import BedrockBackend


class TriggerType(Enum):
    CRITICAL = "Critical"
    RESOLVED_CRITICAL = "ResolvedCritical"
    WARNING = "Warning"
    RESOLVED_WARNING = "ResolvedWarning"
    MISSING_DATA = "MissingData"
    RESOLVED_MISSING_DATA = "ResolvedMissingData"


class ThresholdType(Enum):
    GREATER_THAN_OR_EQUAL = "GreaterThanOrEqual"
    LESS_THAN_OR_EQUAL = "LessThanOrEqual"
    LESS_THAN = "LessThan"
    GREATER_THAN = "GreaterThan"


@dataclass
class MonitorConditions:
    alert_condition: str = ""
    recovery_condition: str = ""


class V2AppDocGenerator:
    """Generator for creating documentation from monitor configurations."""

    MARKDOWN_HEADER = """
    | Name | Description | Alert Condition | Recover Condition |\n|:--|:--|:--|:--|
    """.strip()
    template_name = "generate_v2app_doc_v1.py"

    def __init__(self, app_folder_name: str, only_monitors: bool = False, **kwargs):
        self.trigger_type_conditions = {
            ThresholdType.GREATER_THAN_OR_EQUAL.value: lambda t: f"Count >= {t}",
            ThresholdType.LESS_THAN_OR_EQUAL.value: lambda t: f"Count <= {t}",
            ThresholdType.LESS_THAN.value: lambda t: f"Count < {t}",
            ThresholdType.GREATER_THAN.value: lambda t: f"Count > {t}",
        }
        appfolder = os.path.join(utils.apps_v2_repo_path(), "src", app_folder_name)
        if os.path.exists(app_folder_name):
            self.appfolder = app_folder_name
        elif not os.path.exists(appfolder):
            raise Exception(f"{appfolder} and {app_folder_name} are not valid app folders")
        else:
            self.appfolder = appfolder

        self.app_name = self.get_app_name()
        self.only_monitors = only_monitors
        self.model_backend = None if self.only_monitors else BedrockBackend(appfolder, self.template_name, **kwargs)

    def execute(self) -> None:
        """
        Execute the documentation generation process.
        """
        if not self.only_monitors:
            self.generate_dashboards_docs()
        self.generate_monitor_table()

    def _process_triggers(self, triggers: List[Dict]) -> MonitorConditions:
        """
        Process all triggers and determine their conditions.

        Args:
            triggers: List of dictionaries containing trigger configurations

        Returns:
            MonitorConditions object containing alert and recovery conditions
        """
        conditions = MonitorConditions()

        for trigger in triggers:
            trigger_type = trigger.get("trigger_type")
            threshold_type = trigger.get("threshold_type")
            threshold = trigger.get("threshold")

            # Handle missing data cases
            if trigger_type in [
                TriggerType.MISSING_DATA.value,
                TriggerType.RESOLVED_MISSING_DATA.value,
            ]:
                if trigger_type == TriggerType.MISSING_DATA.value:
                    conditions.alert_condition = "Missing Data"
                else:
                    conditions.recovery_condition = "Data Found"
                continue

            # Process threshold-based conditions
            condition_func = self.trigger_type_conditions.get(threshold_type)
            if not condition_func:
                print(f"Condition not found for {trigger_type}")
                continue

            condition = condition_func(threshold)

            # Assign condition based on trigger type
            if trigger_type in [TriggerType.CRITICAL.value, TriggerType.WARNING.value]:
                conditions.alert_condition = condition
            elif trigger_type in [
                TriggerType.RESOLVED_CRITICAL.value,
                TriggerType.RESOLVED_WARNING.value,
            ]:
                conditions.recovery_condition = condition

        return conditions

    def _format_markdown_row(self, monitor: Dict, conditions: MonitorConditions) -> str:
        """
        Format monitor information into a markdown table row.

        Args:
            monitor: Dictionary containing monitor information
            conditions: MonitorConditions object containing alert and recovery conditions

        Returns:
            Formatted markdown table row
        """
        return (
            f"| `{monitor.get('name', '')}` | {monitor.get('description', '')} | "
            f"{conditions.alert_condition} | {conditions.recovery_condition} |\n"
        )

    def generate_monitor_table(self) -> None:
        """
        Process monitor JSON data and generate markdown documentation.

        Args:
            json_data: Dictionary containing monitor configuration data
        """
        monitorFile = os.path.join(self.appfolder, "resources", "monitors.tf")
        if os.path.exists(monitorFile):
            monitor_json_data = load_tf_to_json(monitorFile)

            try:
                rows = [self.MARKDOWN_HEADER, "\n"]

                monitors = monitor_json_data.get("resource", {}).get("sumologic_monitor", {})
                if not monitors:
                    print("No monitors found in configuration")
                    return

                for monitor in monitors.values():
                    conditions = self._process_triggers(monitor.get("triggers", []))
                    rows.append(self._format_markdown_row(monitor, conditions))

                md_file_content = "".join(rows)
                md_file_content = f"### {self.app_name} Alerts\n\n{md_file_content}"
                print(f"Generated monitor table for {self.app_name} containing {len(monitors)} monitors!\n")
                print(md_file_content)

            except Exception as e:
                print(f"Error processing monitor data: {str(e)}")
        else:
            utils.info(f"monitors.tf file does not exist. Path {monitorFile}")

    def get_app_name(self):
        manifestFile = os.path.join(self.appfolder, "manifest.yaml")
        if os.path.exists(manifestFile):
            self.manifestJson = load_yaml_to_json(manifestFile)
            return self.manifestJson["name"]
        else:
            raise Exception(f"{manifestFile} file doesn't exists")

    def get_dashboard_prompt_params(self, screenshot_file_path, dashboard_name) -> dict:
        return {
            "encoded_image_url": ContentImageQualityReviewGenerator.local_image_to_data_url(f"{screenshot_file_path}"),
            "dashboard_name": dashboard_name,
            "app_name": self.app_name
        }

    def get_dashboard_content(self, response, dashtitle, screenshotpath):
        app_folder_name = os.path.basename(self.appfolder)
        dashboard_doc_content = BaseReviewGenerator.extract_by_tag(response.content, tag="response")
        image_file_name = os.path.basename(screenshotpath)
        screenshot_link = "<img src={useBaseUrl('https://sumologic-app-data-v2.s3.amazonaws.com/dashboards/" + f"{app_folder_name}/{image_file_name}" + "')} alt=\"" + dashtitle + "\" style={{border: '1px solid gray'}} width=\"800\" />"
        return f"### {dashtitle}\n{dashboard_doc_content}\n{screenshot_link}\n\n"

    def generate_dashboards_docs(self):

        if self.manifestJson["installable"]:
            dashlist = self.manifestJson["appMedia"]
            all_dashboard_doc_content = ''
            for dash in dashlist:
                dashtitle = dash["title"]
                screenshotlocation = dash["location"]
                # removing ./ relative url from screenshot
                screenshotpath = os.path.join(self.appfolder, screenshotlocation[2:])
                prompt_params = self.get_dashboard_prompt_params(screenshotpath, dashtitle)
                response = self.model_backend.invoke_model(prompt_params)
                all_dashboard_doc_content += self.get_dashboard_content(response, dashtitle, screenshotpath)

            print(f"\nGenerated doc for {self.app_name} containing {len(dashlist)} dashboards!\n")
            print(all_dashboard_doc_content)
        else:
            utils.info(f"{self.app_name} is a doc only app.")
