import json
from types import SimpleNamespace as Namespace

import requests

from sumoapputils.appdev import utils, state


class ListAction:

    def __init__(self):
        self.apps_by_deployment = {}

    def execute(self):
        for dep in state.deployments:
            apps = self.__list_for_dep(dep)
            if apps:
                self.apps_by_deployment[dep] = apps
        return self.apps_by_deployment

    def __list_for_dep(self, dep: str):
        auth = utils.auth(dep)
        if auth is None:
            utils.warn(f"No auth found for {dep}. Skipping it.")
            return None
        else:
            apps_api_url = utils.endpoint(dep)
            response = requests.get(
                url=apps_api_url,
                auth=auth,
                headers={'Content-Type': 'application/json'}
            )
            if response.ok:
                apps = json.loads(response.content, object_hook=self.__hook)
                filtered = [app for app in getattr(apps, 'apps', []) if state.app_name is None or app.name == state.app_name]
                utils.info(f"Found {len(filtered)} apps after filtering.")
                apps = Namespace(**{'apps': filtered})
                return apps
            else:
                utils.error(f"Error in get {apps_api_url} API: status={response.status_code} reason={response.reason} text={response.text}")
                return None

    def list_for_all_dep(self):
        apps_by_deployment = {}
        for dep in state.all_authorized_deployments:
            apps_by_deployment[dep] = self.__list_for_dep(dep)
        return apps_by_deployment

    def __hook(self, d):
        if not d:
            return None
        else:
            return Namespace(**d)
