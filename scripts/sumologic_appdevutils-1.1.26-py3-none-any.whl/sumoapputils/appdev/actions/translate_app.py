import os
import json
import re
import yaml
from sumoapputils.appdev.actions.translate_content import TranslateContent
from sumoapputils.appdev.actions.translate_manifest import TranslateManifest
from sumoapputils.appdev.actions.translate_manifest_partner import TranslateManifestPartner
from sumoapputils.appdev.actions.exportV2app import ExportV2App
from sumoapputils.appdev.createapp import create_app_directory
from sumoapputils.common.utils import get_file_data, load_yaml_to_json
from sumoapputils.common.appmanifest import AppManifestV2SchemaV2AppOnly
from sumoapputils.common.appmanifest_partner import AppManifestV2SchemaV2PartnerAppOnly
from sumoapputils.appdev import utils


class TranslateApp:
    def get_manifest_file_path(self, folder_path: str):
        for file_name in os.listdir(folder_path):
            if file_name.endswith('.manifest.json'):
                return os.path.join(folder_path, file_name)
        return ""

    def initialize_manifest_instance(self, v1_app_path: str):
        return AppManifestV2SchemaV2PartnerAppOnly() if "sumologic-public-partner-apps" in v1_app_path else AppManifestV2SchemaV2AppOnly()

    def initialize_translate_manifest_instance(self, v1_app_path: str):
        return TranslateManifestPartner() if "sumologic-public-partner-apps" in v1_app_path else TranslateManifest()

    def get_content_file_path(self, folder_path: str):
        for file_name in os.listdir(folder_path):
            if file_name.endswith('.json') and not (file_name.endswith('.min.json') or file_name.endswith('.manifest.json')):
                return os.path.join(folder_path, file_name)
        return ""

    def execute(self, app_path: str, tf_path: str, output_path: None, force_update=False, use_existing_appfolder=False):

        manifest_file_path = self.get_manifest_file_path(app_path)
        manifestjson = json.load(open(manifest_file_path))
        if not output_path:
            output_path = create_app_directory(None, manifestjson['name'])

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        content_file_path = self.get_content_file_path(app_path)
        # creating manifest using v1 app's manifest
        v1_manifest_json_dict = self.initialize_translate_manifest_instance(app_path).execute(manifest_file_path, content_file_path, output_path)

        content_file_json = json.loads(get_file_data(content_file_path))
        tc = TranslateContent()
        personal_folder = tc.get_personal_folder()
        personal_folder_id = personal_folder['id']
        app_name = v1_manifest_json_dict['name']
        app_folder_id = tc.get_app_folder_id(app_name, personal_folder)
        if app_folder_id and (not use_existing_appfolder):
            utils.warn(f"{app_name} folder already exists please delete it.")
            return
        if not use_existing_appfolder:
            tc.import_app_content(content_file_json, personal_folder_id)
        ExportV2App().execute(app_name, tf_path, output_path, "personal", force_update=force_update)
        # creating changelog and readme
        manifestObj = self.initialize_manifest_instance(app_path)
        changelog_filepath = manifestObj.create_changelog(manifestjson['name'], output_path, force_update)
        self.fix_changelog_content(changelog_filepath)
        readme_filepath = manifestObj.create_readme(manifestjson['name'], output_path, manifestjson['description'], input_path=app_path)
        generated_files = "\n".join([filepath for filepath in [changelog_filepath, readme_filepath, manifest_file_path] if os.path.isfile(filepath)])
        utils.info(f"generated below files: \n{generated_files}")
        self.fix_config_yaml(output_path, v1_manifest_json_dict)

    def fix_changelog_content(self, changelog_filepath):
        with open(changelog_filepath, "r") as chfp:
            changelog_content = chfp.read()

        changelog_content = re.sub("Initial commit .+", "Migrated to [next-gen](https://help.sumologic.com/docs/get-started/apps-integrations/#next-gen-apps) app.", changelog_content)

        with open(changelog_filepath, "w") as chfp:
            chfp.write(changelog_content)

    def fix_config_yaml(self, output_path, v1_manifest_json_dict):
        config_file_path = os.path.join(output_path, "config.yaml")
        app_name = v1_manifest_json_dict['name']
        if not os.path.isfile(config_file_path):
            return
        config_json = load_yaml_to_json(config_file_path)
        num_params = len(config_json.get("parameters", []))
        # Label should be same as in older app
        if num_params == 1:
            config_json["parameters"][0]["label"] = v1_manifest_json_dict["parameters"][0]["label"]
        else:
            utils.warn(f"{app_name} has more than 1 source parameters. please fix the labels as per older app")

        if len(v1_manifest_json_dict["parameters"]) != num_params:
            raise Exception("older manifest and new config yaml do not have same number of parameters")

        for parameter in v1_manifest_json_dict["parameters"]:
            if parameter.get("hidden", False):
                raise Exception(f"{app_name} contains unsupported hidden parameter")

        # saving config.yaml file
        yaml_output = yaml.dump(config_json, sort_keys=False)
        with open(config_file_path, "w") as yaml_file:
            yaml_file.write(yaml_output)
