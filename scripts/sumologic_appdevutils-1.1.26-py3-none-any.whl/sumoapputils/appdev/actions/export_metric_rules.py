import copy
import os
import shutil
import subprocess
import traceback
import re
import requests
import json
from typing import Any, Dict, List


from sumoapputils.appdev import utils
from sumoapputils.appdev.actions.base_content import BaseContent


class ExportMetricRules(BaseContent):

    def __init__(self, *args, **kwargs):
        super(ExportMetricRules, self).__init__(*args, **kwargs)

    def terraformize_fers(self, terraform_path: str, output_path: str, destination_folder: str, fer_ids: List[str], force_update: bool) -> None:
        try:
            dst_path = os.path.join(output_path, destination_folder, "metricRules.tf")
            if (not os.path.exists(dst_path)) or force_update:
                terraformer_flags = f"import sumologic --resources=field_extraction_rule --filter=field_extraction_rule={':'.join(fer_ids)} -o '{output_path}'"

                command_str = f"{terraform_path} {terraformer_flags}"
                utils.debug(command_str)

                access_id, access_key = utils.get_deployment_keys(self.deployment)

                new_environ = copy.copy(os.environ)
                new_environ["SUMOLOGIC_ACCESS_ID"] = access_id
                new_environ["SUMOLOGIC_ACCESS_KEY"] = access_key

                new_environ["SUMOLOGIC_BASE_URL"] = utils.get_endpoint(self.deployment) + "/"
                if "SUMOLOGIC_ENVIRONMENT" in new_environ:
                    # SUMOLOGIC_ENVIRONMENT is set to stag then terraformer gives error
                    # for both stag and prod base url works
                    del new_environ["SUMOLOGIC_ENVIRONMENT"]
                completed_process = subprocess.run(command_str, check=True, text=True, shell=True, capture_output=True, env=new_environ)
                utils.debug(completed_process.stdout)

                self.copy_and_merge_FERs(output_path)
                self.fix_field_extraction_rules(dst_path)
            else:
                utils.warn(f"Skipping FERs export {dst_path} already exists")

        except subprocess.CalledProcessError as cpe:
            utils.error(f"Error: Terraform process failed with return code {cpe.returncode}. Error message: {cpe.stderr}")

        except Exception as e:
            utils.error(f"Error: An unexpected error occurred this: {e}")

    def execute(self, terraform_path: str, output_path: str, fers_names_to_fetch: List[str], force_update=False) -> None:

        try:

            if not os.path.exists(output_path):
                utils.error(f"The given path does not exist App not found at : {output_path}")

            fer_ids = self.fetch_fer_ids_from_details(fers_names_to_fetch)
            self.terraformize_fers(terraform_path, output_path, "collection", fer_ids, force_update)

        except Exception as e:
            utils.error(f"Error occurred during FERs export error: {e} traceback: {traceback.format_exc()}")

    def fetch_fer_details(self) -> Dict[str, Any]:

        endpoint = f"{utils.get_endpoint(self.deployment)}/v1/extractionRules"

        response = requests.get(
            url=endpoint,
            auth=utils.auth(self.deployment),
        )

        if response.status_code != 200:
            raise Exception(f"Failed to get FERs on {self.deployment} status code {response.status_code}: {response.text}")

        return json.loads(response.content)

    def fetch_fer_ids_from_details(self, fers_names_to_fetch: List[str]) -> List[str]:

        data = self.fetch_fer_details()
        # Extracting the list of IDs for the specified names
        ids = [item["id"] for item in data["data"] if item["name"] in fers_names_to_fetch]

        return ids

    def fix_field_extraction_rules(self, file_path: str) -> None:
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            fer_resource_pattern = re.compile(r'\bresource\s*"sumologic_field_extraction_rule"')

            processed_lines = []
            for line in lines:
                # removing tfer and suffix from resources names in fer file
                if fer_resource_pattern.search(line):
                    line = re.sub(r'tfer--', '', line)
                    line = re.sub(r'-[a-zA-Z0-9]*(?=" {)', '', line)
                processed_lines.append(line)

            # Write the updated content back to the file
            with open(file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)

        except FileNotFoundError:
            utils.error(f"File not found during fixing sumologic_field_extraction_rule at file location : {file_path}")

        except Exception as e:
            utils.error("Error: An unexpected error occurred while fixing sumologic_field_extraction_rule resource names:", e)

    def copy_and_merge_FERs(self, source_path) -> None:
        sumologic_folder = os.path.join(source_path, 'sumologic')

        # Check if the sumologic folder exists
        if os.path.exists(sumologic_folder):
            field_extraction_rules_folder = os.path.join(sumologic_folder, 'field_extraction_rule')
            source_file_path = os.path.join(field_extraction_rules_folder, 'field_extraction_rule.tf')

            # Check if the source file exists
            if os.path.exists(source_file_path):
                collection_folder = os.path.join(source_path, 'collection')
                destination_file_path = os.path.join(collection_folder, 'metricRules.tf')

                # Check if the collection folder exists, create it if it doesn't
                if not os.path.exists(collection_folder):
                    os.makedirs(collection_folder)
                    with open(destination_file_path, 'w') as new_file:
                        new_file.write("")

                # Read the content of the source file
                with open(source_file_path, 'r') as source_file:
                    source_content = source_file.read()

                # Append the content to the destination file
                with open(destination_file_path, 'w') as destination_file:
                    destination_file.write(source_content)

                # Delete the sumologic folder
                shutil.rmtree(sumologic_folder)
            else:
                raise Exception(f"Error: 'field_extraction_rule.tf' file not found in the {source_path}/sumologic folder.")
        else:
            raise Exception(f"Error: 'sumologic' folder not found in the {source_path} folder.")
