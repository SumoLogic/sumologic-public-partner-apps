import os
import shutil
import subprocess
import copy
import pathlib

from sumoapputils.appdev import utils
from string import Template


class TerraformValidate:

    def render_template(self, template_params: dict, input_filepath: str, output_filepath: str):
        with open(input_filepath, 'r') as fin:
            src = Template(fin.read())
            result = src.substitute(template_params)
            with open(output_filepath, 'w') as fout:
                fout.write(result)

    def execute(self, app_path: str, terraform_path: str):
        is_error = False
        cleanup_paths = []
        try:
            current_dir = os.getcwd()
            resources_path = os.path.join(app_path, "resources")
            collections_field_file_path = os.path.join(app_path, "collection", "fields.tf")
            if os.path.exists(collections_field_file_path):
                shutil.copy(collections_field_file_path, resources_path)
                cleanup_paths.append(os.path.join(resources_path, "fields.tf"))
            os.makedirs(resources_path, exist_ok=True)
            versions_tf_path = os.path.join(resources_path, "versions.tf")
            if os.path.exists(versions_tf_path):
                os.remove(versions_tf_path)
            version_tf_template_path = os.path.join(pathlib.Path(__file__).parent.parent.parent, "common", "templates", "versions.tf.tmpl")
            self.render_template(template_params={},input_filepath=version_tf_template_path, output_filepath=versions_tf_path)
            os.chdir(resources_path)
            command_str = f"{terraform_path} init"
            step = "initialization"
            utils.debug(command_str)
            new_environ = copy.copy(os.environ)
            p = subprocess.run(command_str, check=True, text=True, shell=True, capture_output=True, env=new_environ)
            utils.debug(p.stdout)
            if p.returncode != 0:
                utils.error(f"Error: Terraform init failed with return code {p.returncode}. Error message: {p.stderr}")
                is_error = True
            utils.info("Terraform init completed successfully for app %s" % app_path)
            step = "validation"
            command_str = f"{terraform_path} validate"
            utils.debug(command_str)
            p = subprocess.run(command_str, check=True, text=True, shell=True, capture_output=True, env=new_environ)
            if p.returncode != 0:
                utils.error(f"Error: Terraform validate failed with return code {p.returncode}. Error message: {p.stderr}")
                is_error = True
            utils.info("Terraform validate completed successfully for app %s" % app_path)
        except subprocess.CalledProcessError as cpe:
            utils.error(f"Error: Terraform {step} process failed with return code {cpe.returncode}. Error message: {cpe.stderr}")
            is_error = True
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred: {e}")
            is_error = True
        finally:
            cleanup_paths.extend([
                versions_tf_path, os.path.join(resources_path, ".terraform.lock.hcl"), os.path.join(resources_path, ".terraform")
            ])
            for path in cleanup_paths:
                if os.path.exists(path):
                    if os.path.isdir(path):
                        shutil.rmtree(path, ignore_errors=False, onerror=None)
                    else:
                        os.remove(path)
            if not current_dir or not os.path.exists(current_dir):
                current_dir = os.getcwd()
            os.chdir(current_dir)
            return is_error
