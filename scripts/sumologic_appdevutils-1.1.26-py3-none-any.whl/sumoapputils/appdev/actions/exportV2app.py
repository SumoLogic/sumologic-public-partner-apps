import os.path
import re
import shutil
import subprocess
import textwrap
import yaml
from typing import Any, Dict, List
from sumoapputils.appdev.utils import get_endpoint, process_folders_tf
from sumoapputils.common.utils import slugify, get_scope_key_variable_default_value, get_scope_key_variable_value
from sumoapputils.common.appmanifest import ConfigGenerator
import requests
import traceback
import copy
from sumoapputils.appdev import utils
from sumoapputils.appdev.actions.base_content import BaseContent
from sumoapputils.appdev.actions.export_fields import ExportFields


class ExportV2App(BaseContent):

    def generate_variables_tf(self, folders: Dict[str, Dict[str, str]], app_folder_id) -> str:
        variables_text = ""

        for _, folder in folders.items():
            if folder["id"] == app_folder_id:
                continue
            folder_name = slugify(folder["name"],"_")
            variables_text += f'variable "{folder_name}_folder_name" {{\n'
            variables_text += '  type        = string\n'
            variables_text += f'  description = "{folder_name} folder name"\n'
            variables_text += f'  default     = "{folder["name"]}"\n'
            variables_text += '}\n\n'

            variables_text += f'variable "{folder_name}_folder_description" {{\n'
            variables_text += '  type        = string\n'
            variables_text += f'  description = "{folder_name} folder description"\n'
            variables_text += f'  default     = "{folder["description"]}"\n'
            variables_text += '}\n\n'

        return variables_text

    def generate_folders_tf(self, folders: Dict[str, Dict[str, str]], root_folder_id: str,
                            root_parent_folder_id: str) -> Dict[str, str]:
        folders_tf = dict()

        for folder_id, folder in folders.items():
            folder_text = ""
            folder_name = slugify(folder["name"], "_")
            folder_var_name = f'var.{folder_name}_folder_name'
            folder_var_desc = f'var.{folder_name}_folder_description'
            # folders in the root folder
            if folder["parentId"] == root_folder_id:
                parent_id = 'sumologic_folder.integration_folder.id'
            # root folder - parent is personal folder
            elif folder["parentId"] == root_parent_folder_id:
                parent_id = "var.integration_root_dir"
                folder_name = "integration"
                folder_var_name = 'var.integration_name'
                folder_var_desc = 'var.integration_description'
            # child folders of the folders in app folder
            else:
                parent_id = f'sumologic_folder.{slugify(folders[folder["parentId"]]["name"], "_")}_folder.id'

            folder_text += f'resource "sumologic_folder" "{folder_name}_folder" {{\n'
            folder_text += f'  name        = {folder_var_name}\n'
            folder_text += f'  description = {folder_var_desc}\n'
            folder_text += f'  parent_id   = {parent_id}\n'
            folder_text += '}\n\n'

            folders_tf[folder_id] = folder_text

        return folders_tf

    def create_static_variables_tf(self) -> str:
        content = f'''variable "integration_root_dir" {{
    type        = string
    description = "The folder in which app should be installed."
    default     = ""
}}
variable "integration_name" {{
  type        = string
  description = "The name of the integration"
  default     = ""
}}

variable "integration_description" {{
  type        = string
  description = "The description of the integration"
  default     = ""
}}

'''
        return textwrap.dedent(content)

    def get_app_content_with_folders(self, folder_id: str):
        folders = {}
        content = []
        folder = self.get_folder(folder_id)
        if folder["itemType"] == "Folder":
            folders[folder["id"]] = folder
            if "children" in folder:
                for child in folder["children"]:
                    if child["itemType"] == "Folder":
                        childContent = self.get_app_content_with_folders(child["id"])
                        folders.update(childContent[0])
                        content.extend(childContent[1])
                    else:
                        content.append(child)
        return [folders, content]

    def clean_up(self, app_folder_id: str) -> None:
        delete_content_endpoint = f"{get_endpoint(self.deployment)}/v2/content/{app_folder_id}/delete"

        response = requests.delete(
            url=delete_content_endpoint,
            auth=utils.auth(self.deployment),
        )
        if response.status_code != 200:
            raise Exception(f"Failed to delete folder {app_folder_id} on {self.deployment} status code {response.status_code}: {response.text}")

    def get_v2_dashboards(self, content_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return [item for item in content_list if item['itemType'] == 'Dashboard']

    def get_saved_searches(self, content_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return [item for item in content_list if item['itemType'] == 'Search']

    def get_saved_scheduled_searches(self, content_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return [item for item in content_list if item['itemType'] == 'SavedSearchWithScheduleSyncDefinition']

    def replace_parameter_in_tf_file(self, folders_dict: Dict[str, Dict[str, Any]], file_path: str, app_folder_id: str, parameter="folder_id") -> None:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()

        # Define a regex pattern to match the folder_id line
        pattern = r'(%s\s*=\s*)(")([0-9A-Za-z]+)(")' % (parameter)

        def replace_id(match):
            original_id = match.group(3)
            if original_id == app_folder_id:
                real_id = "sumologic_folder.integration_folder.id"
            else:
                real_id = f"sumologic_folder.{slugify(str(folders_dict[original_id]['name']), '_')}_folder.id"
            return f'{match.group(1)}{real_id}'

        # Replace the matched IDs using the re.sub() method
        updated_content = re.sub(pattern, replace_id, content)

        # Save the updated content to the file
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(updated_content)

    def fix_dashboards(self, file_path: str) -> None:
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            prefix = "title = "
            suffix_to_remove = " - New"
            processed_lines = []
            idx = 0
            num_lines = len(lines)
            while idx < num_lines:
                line = lines[idx]
                if 'resource "sumologic_dashboard"' in line:
                    # removing tfer suffix which gets added after export
                    line = re.sub(r'tfer--', '', line)
                    line = re.sub(r'-[a-zA-Z0-9]*(?="\s+{)', '', line)
                    # removing special characters from resource names
                    line = re.sub(r'[^a-z_ \"{\n]+', '', line)
                    # removing underscore from beginning of resource name
                    line = re.sub(r'\"_', '\"', line)
                stripped_line = line.lstrip()
                if stripped_line.startswith(prefix) and suffix_to_remove in stripped_line:
                    line = line.replace(suffix_to_remove, "")

                # skipping linked dashboards
                if stripped_line.startswith("linked_dashboard"):
                    next_stripped_line = stripped_line
                    while not next_stripped_line.startswith("}"):
                        next_stripped_line = lines[idx].lstrip()
                        idx += 1
                else:
                    processed_lines.append(line)
                    idx += 1

            with open(file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred while fixing dashboard resource names: {e}")

    def fix_saved_searches(self, file_path: str) -> None:
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            prefix = "title = "
            suffix_to_remove = " - New"
            processed_lines = []
            for line in lines:
                if 'resource "sumologic_log_search"' in line:
                    line = re.sub(r'tfer--', '', line)
                    line = re.sub(r'-[a-zA-Z0-9]*(?=" {)', '', line)
                stripped_line = line.lstrip()
                if stripped_line.startswith(prefix) and suffix_to_remove in stripped_line:
                    line = line.replace(suffix_to_remove, "")
                processed_lines.append(line)

            with open(file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred while fixing sumologic_log_search resource names: {e}")

    def generate_output_tf(self, dashboards_tf_path: str, folders_tf_path: str, searches_tf_path: str, monitor_tf_path: str) -> str:
        def extract_resource_names(file_path, resource_type):
            resource_names = []

            # Regular expression to match the desired pattern
            pattern = re.compile(fr'resource "{resource_type}" "(.+)" {{')

            # Open the file and read its lines
            with open(file_path, 'r') as file:
                for line in file.readlines():
                    # Search for the pattern in the current line
                    match = pattern.search(line)

                    # If a match is found, extract the resource name and add it to the list
                    if match:
                        resource_name = match.group(1)
                        resource_names.append(resource_name)

            return resource_names

        def generate_output_text(output_name, resource_type, object_names, name_attribute_name):
            output_text = f'output "{output_name}" {{\n'
            output_text += f'  description = "all the {output_name}"\n'
            output_text += '  value       = [\n'

            for name in object_names:
                output_text += f'    {{\n'
                output_text += f'      "id" = {resource_type}.{name}.id,\n'
                output_text += f'      "name" = {resource_type}.{name}.{name_attribute_name},\n'
                output_text += f'    }},\n'

            # Remove the extra comma and close the brackets
            output_text = output_text[:-2] + "\n"
            output_text += '  ]\n'
            output_text += '}\n\n'

            return output_text

        dashboard_resource_names = extract_resource_names(dashboards_tf_path, "sumologic_dashboard")
        folder_resource_names = extract_resource_names(folders_tf_path, "sumologic_folder")
        if os.path.isfile(searches_tf_path):
            search_resource_names = extract_resource_names(searches_tf_path, "sumologic_log_search")
        else:
            search_resource_names = []

        if os.path.isfile(monitor_tf_path):
            monitor_resource_names = self.extrace_resource_names(monitor_tf_path, "sumologic_monitor")
        else:
            monitor_resource_names = []
        output_tf = ""

        if dashboard_resource_names:
            output_tf += generate_output_text("dashboards", "sumologic_dashboard", dashboard_resource_names, "title")
        if folder_resource_names:
            output_tf += generate_output_text("folders", "sumologic_folder", folder_resource_names, "name")
        if search_resource_names:
            output_tf += generate_output_text("log_searches", "sumologic_log_search", search_resource_names, "name")
        if monitor_resource_names:
            output_tf += generate_output_text("monitors", "sumologic_monitor", monitor_resource_names, "name")

        return output_tf

    def terraformize_dashboards(self, terraform_path: str, dashboard_ids: List[str], output_path: str,
                                folders_dict: Dict[str, Dict[str, Any]], app_folder_id: str, force_update: bool) -> None:
        try:
            dst_path = os.path.join(output_path, "resources", "dashboards.tf")
            if (not os.path.exists(dst_path)) or force_update:
                terraformer_flags = f"import sumologic -v --resources=dashboard --filter 'Name=id;Value={':'.join(dashboard_ids)}' -o '{output_path}'"
                # Print the exact command being run
                command_str = f"{terraform_path} {terraformer_flags}"
                utils.debug(command_str)
                # Ensure that flags are passed correctly
                access_id, access_key = utils.get_deployment_keys(self.deployment)
                new_environ = copy.copy(os.environ)
                new_environ["SUMOLOGIC_ACCESS_ID"] = access_id
                new_environ["SUMOLOGIC_ACCESS_KEY"] = access_key
                # Provider needs slash at the end
                # https://github.com/SumoLogic/terraform-provider-sumologic/blob/6064499b2268f2856a9937a032718767d679dd4c/sumologic/sumologic_client.go#L34
                new_environ["SUMOLOGIC_BASE_URL"] = get_endpoint(self.deployment) + "/"
                if "SUMOLOGIC_ENVIRONMENT" in new_environ:
                    # SUMOLOGIC_ENVIRONMENT is set to stag then terraformer gives error
                    # for both stag and prod base url works
                    del new_environ["SUMOLOGIC_ENVIRONMENT"]
                p = subprocess.run(command_str, check=True, text=True, shell=True, capture_output=True, env=new_environ)
                utils.debug(p.stdout)

                # After successful translation, dashboards are saved in `output_path/sumologic/dashboard/dashboard.tf
                # this file should be moved to `output_path/resources/` folder and folder ids should be fixed

                src_path = os.path.join(output_path, "sumologic", "dashboard", "dashboard.tf")
                generated_folder_path = os.path.join(output_path, "sumologic")
                shutil.move(src_path, dst_path)
                shutil.rmtree(generated_folder_path)
                self.replace_parameter_in_tf_file(folders_dict, dst_path, app_folder_id)
                self.fix_dashboards(dst_path)
                fields_file_path = os.path.join(output_path, "collection", "fields.tf")
                ExportFields.add_depends_on(dst_path, lookforward_pattern="layout", fields_file_path=fields_file_path)
            else:
                utils.warn(f"Skipping dashboard export {dst_path} already exists")

        except subprocess.CalledProcessError as cpe:
            utils.error(f"Error: Terraform process failed with return code {cpe.returncode}. Error message: {cpe.stderr}")

        except Exception as e:
            utils.error(f"Error: An unexpected error occurred this: {e}")

    def terraformize_saved_searches(self, terraform_path: str, log_search_ids: List[str], output_path: str,
                                    folders_dict: Dict[str, Dict[str, Any]], app_folder_id: str, force_update: bool) -> None:
        try:
            dst_path = os.path.join(output_path, "resources", "logSearches.tf")
            if (not os.path.exists(dst_path)) or force_update:
                terraformer_flags = f"import sumologic -v --resources=log_search --filter 'Name=id;Value={':'.join(log_search_ids)}' -o '{output_path}'"
                # Print the exact command being run
                command_str = f"{terraform_path} {terraformer_flags}"
                utils.debug(command_str)
                # Ensure that flags are passed correctly
                access_id, access_key = utils.get_deployment_keys(self.deployment)
                new_environ = copy.copy(os.environ)
                new_environ["SUMOLOGIC_ACCESS_ID"] = access_id
                new_environ["SUMOLOGIC_ACCESS_KEY"] = access_key
                # Provider needs slash at the end
                # https://github.com/SumoLogic/terraform-provider-sumologic/blob/6064499b2268f2856a9937a032718767d679dd4c/sumologic/sumologic_client.go#L34
                new_environ["SUMOLOGIC_BASE_URL"] = get_endpoint(self.deployment) + "/"
                if "SUMOLOGIC_ENVIRONMENT" in new_environ:
                    # SUMOLOGIC_ENVIRONMENT is set to stag then terraformer gives error
                    # for both stag and prod base url works
                    del new_environ["SUMOLOGIC_ENVIRONMENT"]
                p = subprocess.run(command_str, check=True, text=True, shell=True, capture_output=True, env=new_environ)
                utils.debug(p.stdout)

                # After successful translation, log searches are saved in `output_path/sumologic/log_search/log_search.tf
                # this file should be moved to `output_path/resources/` folder and folder ids should be fixed

                src_path = os.path.join(output_path, "sumologic", "log_search", "log_search.tf")
                generated_folder_path = os.path.join(output_path, "sumologic")
                shutil.move(src_path, dst_path)
                shutil.rmtree(generated_folder_path)
                self.replace_parameter_in_tf_file(folders_dict, dst_path, app_folder_id, parameter="parent_id")
                self.fix_saved_searches(dst_path)
                fields_file_path = os.path.join(output_path, "collection", "fields.tf")
                ExportFields.add_depends_on(dst_path, lookforward_pattern="time_range", fields_file_path=fields_file_path)
            else:
                utils.warn(f"Skipping log search export {dst_path} already exists")

        except subprocess.CalledProcessError as cpe:
            utils.error(f"Error: Terraform process failed with return code {cpe.returncode}. Error message: {cpe.stderr}")

        except Exception as e:
            utils.error(f"Error: An unexpected error occurred this: {e}")

    def generate_config_scope_variables_tf(self, config_parameters) -> str:
        variables_text = ""
        num_config_parameters = len(config_parameters.get("parameters", []))

        for parameter in config_parameters.get("parameters", []):
            scope_key_variable = get_scope_key_variable_value(parameter)
            scope_key_variable_display_name = ConfigGenerator.get_display_name(scope_key_variable)

            variables_text += f'variable "{scope_key_variable}" {{\n'
            variables_text += '  type        = string\n'
            variables_text += f'  description = "The scope for app queries"\n'
            variables_text += f'  default     = ""\n'
            variables_text += '}\n\n'
            default_value_of_scope_key_variable = get_scope_key_variable_default_value(parameter, silent=True)
            if default_value_of_scope_key_variable and parameter["componentType"] == "scope":
                variables_text += f'variable "{default_value_of_scope_key_variable}" {{\n'
                variables_text += '  type        = string\n'
                variables_text += f'  description = "The default scope value of {scope_key_variable_display_name} variable"\n'
                variables_text += f'  default     = ""\n'
                variables_text += '}\n\n'

            pattern = re.compile(r'\s+')
            label_without_space = re.sub(pattern, '', parameter["label"])

            scope_key_variable_display_name_default_value = scope_key_variable.replace(ConfigGenerator.param_prefix, label_without_space)  # LogDataSource1 LogDataSource2
            variables_text += f'variable "{scope_key_variable_display_name}" {{\n'
            variables_text += '  type        = string\n'
            variables_text += f'  description = "The display name for {scope_key_variable} scope"\n'
            variables_text += f'  default     = "{scope_key_variable_display_name_default_value}"\n'
            variables_text += '}\n\n'

        return variables_text

    def execute(self, app_folder_name: str, terraformer_path: str,
                output_path: str, appfolderpath, force_update=False) -> None:
        try:
            if appfolderpath.lower() == "personal":
                parent_app_folder = self.get_personal_folder()
            elif appfolderpath.lower() == "installed apps":
                parent_app_folder = self.get_global_folder()

            app_folder = self.get_app_folder(app_folder_name, parent_app_folder)
            appContent = self.get_app_content_with_folders(app_folder['id'])
            folders_dict = appContent[0]
            all_content = appContent[1]
            app_description = app_folder.get("description", '')
            if len(app_description) >= 250:
                utils.warn("Provide app folder description with length less then 250 characters, truncating it")
                app_description = app_description[:250]
            variables_tf = self.create_static_variables_tf() + self.generate_variables_tf(
                folders_dict, app_folder['id'])
            folders_tf = self.generate_folders_tf(folders_dict, app_folder['id'],
                                                  parent_app_folder['id'])
            folders_tf_text = "".join(folders_tf.values())

            # Ensure the "resources" folder exists, create it if not
            resources_path = os.path.join(output_path, "resources")
            os.makedirs(resources_path, exist_ok=True)

            # generate dashboards using terraformer
            v2_dashboards = self.get_v2_dashboards(all_content)
            v2_dashboard_contendIds = [dashboard['id'] for dashboard in v2_dashboards]
            v2_dashboard_url_ids = self.get_dashboards_ids_by_contentId(v2_dashboard_contendIds)
            self.terraformize_dashboards(terraformer_path, v2_dashboard_url_ids, output_path, folders_dict, app_folder['id'], force_update)

            # generate log searches using terraformer
            saved_searches = self.get_saved_searches(all_content)
            if saved_searches:
                saved_searches_contendIds = [saved_search['id'] for saved_search in saved_searches]
                self.terraformize_saved_searches(terraformer_path, saved_searches_contendIds, output_path, folders_dict, app_folder['id'], force_update)

            folders_tf_path = os.path.join(output_path, "resources", "folders.tf")
            log_searches_tf_path = os.path.join(output_path, "resources", "logSearches.tf")
            dashboards_tf_path = os.path.join(output_path, "resources", "dashboards.tf")
            output_path_tf_path = os.path.join(output_path, "resources", "output.tf")
            monitor_path_tf_path = os.path.join(output_path, "resource", "monitors.tf")
            config_file_path = os.path.join(output_path, "config.yaml")

            # Updating dashboard and logSearches
            config_parameters = ConfigGenerator(output_path).process_queries(app_folder_name)
            num_config_parameters = len(config_parameters.get("parameters", []))

            if num_config_parameters > 0:

                # saving config.yaml file
                yaml_output = yaml.dump(config_parameters, sort_keys=False)
                with open(config_file_path, "w") as yaml_file:
                    yaml_file.write(yaml_output)

                # Updating variables.tf with scope variables
                variables_tf += self.generate_config_scope_variables_tf(config_parameters)
            process_folders_tf(folders_tf_path, folders_tf_text)

            with open(os.path.join(output_path, "resources", "variables.tf"), 'w', encoding='utf-8') as file:
                file.write(variables_tf)

            output_tf = self.generate_output_tf(dashboards_tf_path, folders_tf_path, log_searches_tf_path, monitor_path_tf_path)

            with open(output_path_tf_path, 'w', encoding='utf-8') as file:
                file.write(output_tf)

            generated_files = "\n".join([filepath for filepath in [folders_tf_path, log_searches_tf_path, dashboards_tf_path, output_path_tf_path, config_file_path] if os.path.isfile(filepath)])

            utils.info(f"{app_folder_name} folder successfully exported! generated below files: \n{generated_files}")

            # Todo generate example files by running ./test/util/render_otelcol_example.sh <App_folder_name>
            # Todo call download screenshot without force download export force download variable in export v2 app command
            # Todo iterate over folder and check image exist and update manifest for appmedia
        except Exception as e:
            utils.error(f"Error occurred during exporting app translation error: {e} traceback: {traceback.format_exc()}")
