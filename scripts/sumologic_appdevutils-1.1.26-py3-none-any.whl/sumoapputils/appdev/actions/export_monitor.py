from typing import List, Dict, Any
import re
import copy
import os
import shutil
import subprocess
import traceback
import yaml
from sumoapputils.appdev import utils
from sumoapputils.common.appmanifest import ConfigGenerator
from sumoapputils.common.utils import slugify, load_yaml_to_json
from sumoapputils.appdev.actions.base_content import BaseContent
from sumoapputils.appdev.actions.export_fields import ExportFields


class ExportMonitor(BaseContent):

    def __init__(self, *args, **kwargs):
        super(ExportMonitor, self).__init__(*args, **kwargs)
        self.create_monitor_folder = False

    def file_contains_text(self, monitor_folders_tf_path, regex_expr):

        if not os.path.isfile(monitor_folders_tf_path):
            return False

        with open(monitor_folders_tf_path, "r") as fp:
            file_content = fp.read()

        return re.search(regex_expr, file_content)

    def get_monitor_content_ids(self, monitor_folder: str, monitor_path: str):
        folders = {}
        monitor_ids = []
        folders[monitor_folder["id"]] = monitor_folder
        if "children" in monitor_folder:
            for child in monitor_folder["children"]:
                if child["contentType"] == "Folder":
                    child_monitors_root_path = monitor_path + "/" + child["name"]
                    child_monitor_folder = self.get_monitor_folder(child_monitors_root_path)
                    child_monitor_content = self.get_monitor_content_ids(child_monitor_folder, child_monitors_root_path)
                    folders.update(child_monitor_content[0])
                    monitor_ids.extend(child_monitor_content[1])
                else:
                    monitor_ids.append(child["id"])
        return [folders, monitor_ids]

    def get_app_name(self, output_path):
        manifestfile = os.path.join(output_path, "manifest.yaml")
        if os.path.isfile(manifestfile):
            manifestjson = load_yaml_to_json(manifestfile)
            return manifestjson["name"]
        else:
            utils.warn(f"No app name found since manifestfile: {manifestfile} does not exists")
        return None

    # deletes the monitor_folder text from folder.tf
    def delete_monitor_folder_resource(self, file_path, block_start):
        with open(file_path, 'r') as file:
            content = file.read()
        pattern = r'resource\s+"{0}"\s*{{(?:[^{{}}]|{{(?:[^{{}}]|{{[^{{}}]*}})*}})*}}'.format(block_start)
        match = re.search(pattern, content)
        if match:
            modified_content = content[:match.start()] + content[match.end():]
            with open(file_path, 'w') as file:
                file.write(modified_content)
        return

    # deletes the code block in output.tf file for a particular resource type
    def delete_code_block(self, file_path, block_start):
        with open(file_path, 'r') as file:
            content = file.read()
        pattern = r'output\s+"{0}"\s*{{(?:[^{{}}]|{{(?:[^{{}}]|{{[^{{}}]*}})*}})*}}'.format(block_start)
        match = re.search(pattern, content)
        if match:
            modified_content = content[:match.start()] + content[match.end():]
            with open(file_path, 'w') as file:
                file.write(modified_content)
        return

    def execute(self, monitor_path: str, terraformer_path: str, output_path: str, force_update=False) -> None:

        try:

            monitor_folder = self.get_monitor_folder(monitor_path)
            monitorContent = self.get_monitor_content_ids(monitor_folder, monitor_path)
            monitor_folders_dict = monitorContent[0]
            monitor_folder_ids = monitorContent[1]
            root_monitor_folder_id = monitor_folder["parentId"]

            # Ensure the "resources" folder exists, create it if not
            resources_path = os.path.join(output_path, "resources")
            os.makedirs(resources_path, exist_ok=True)

            self.terraformize_monitors(terraformer_path, monitor_folder_ids, output_path, monitor_folders_dict, monitor_folder["id"], force_update)

            monitor_folders_tf_path = os.path.join(output_path, "resources", "monitor_folders.tf")
            monitors_tf_path = os.path.join(output_path, "resources", "monitors.tf")
            output_path_tf_path = os.path.join(output_path, "resources", "output.tf")
            folder_path_tf_path = os.path.join(output_path, "resources", "folders.tf")
            config_file_path = os.path.join(output_path, "config.yaml")
            app_name = self.get_app_name(output_path)
            config_parameters = ConfigGenerator(output_path).process_monitor_folder_queries(app_name=app_name)
            num_config_parameters = len(config_parameters.get("parameters", []))

            if num_config_parameters > 0:
                yaml_output = yaml.dump(config_parameters, sort_keys=False)
                with open(config_file_path, "w") as yaml_file:
                    yaml_file.write(yaml_output)

            # as per discussion with platform team we should not be creating empty folders within the customers folder hierarchy when an App is installed https://sumologic.slack.com/archives/C054JKY4Y00/p1715288505971829?thread_ts=1713821763.602029&cid=C054JKY4Y00

            if self.create_monitor_folder:
                folders_tf = self.generate_monitor_folders_tf(monitor_folders_dict, monitor_folder['id'], root_monitor_folder_id)
                monitor_folders_tf_text = "".join(folders_tf.values())

                if self.file_contains_text(os.path.join(output_path, "resources", "folders.tf"), r'\bsumologic_monitor_folder\b'):
                    # deleting sumologic_monitor_folder from folders.tf if exists
                    self.delete_monitor_folder_resource(folder_path_tf_path, "sumologic_monitor_folder")
                    utils.warn("Remove older sumologic_monitor_folder from folders.tf file and paste the output in monitor_folders.tf")

                # overwriting monitor folders in folders.tf
                with open(folder_path_tf_path, 'a', encoding='utf-8') as file:
                    file.write("\n" + monitor_folders_tf_text)

            # delete the old monitors from output.tf if already present
            if self.file_contains_text(os.path.join(output_path, "resources", "output.tf"), r'\bmonitors\b'):
                self.delete_code_block(output_path_tf_path, "monitors")

            # appending monitor output
            monitor_output_tf_text = self.generate_output_tf(monitors_tf_path, monitor_folders_tf_path)
            if os.path.isfile(output_path_tf_path):
                with open(output_path_tf_path, 'a', encoding='utf-8') as file:
                    file.write("\n" + monitor_output_tf_text)
            else:
                with open(output_path_tf_path, 'w', encoding='utf-8') as file:
                    file.write(monitor_output_tf_text)

            generated_files = "\n".join([filepath for filepath in [monitor_folders_tf_path, monitors_tf_path, output_path_tf_path, config_file_path] if os.path.isfile(filepath)])

            utils.info(f"{monitor_folder['name']} folder successfully exported! generated below files: \n{generated_files}")

        except Exception as e:
            utils.error(f"Error occurred during monitor export error: {e} traceback: {traceback.format_exc()}")

    def terraformize_monitors(self, terraform_path: str, monitor_folder_ids: List[str], output_path: str, monitor_folders_dict: Dict[str, Dict[str, Any]], monitor_folder_id: str, force_update: bool) -> None:
        try:
            dst_path = os.path.join(output_path, "resources", "monitors.tf")
            if (not os.path.exists(dst_path)) or force_update:
                terraformer_flags = f"import sumologic -v --resources=monitor --filter 'Name=id;Value={':'.join(monitor_folder_ids)}' -o '{output_path}'"
                # Print the exact command being run
                command_str = f"{terraform_path} {terraformer_flags}"
                utils.debug(command_str)
                # Ensure that flags are passed correctly
                access_id, access_key = utils.get_deployment_keys(self.deployment)
                new_environ = copy.copy(os.environ)
                new_environ["SUMOLOGIC_ACCESS_ID"] = access_id
                new_environ["SUMOLOGIC_ACCESS_KEY"] = access_key
                # Provider needs slash at the end
                # https://github.com/SumoLogic/terraform-provider-sumologic/blob/6064499b2268f2856a9937a032718767d679dd4c/sumologic/sumologic_client.go#L34
                new_environ["SUMOLOGIC_BASE_URL"] = utils.get_endpoint(self.deployment) + "/"
                if "SUMOLOGIC_ENVIRONMENT" in new_environ:
                    # SUMOLOGIC_ENVIRONMENT is set to stag then terraformer gives error
                    # for both stag and prod base url works
                    del new_environ["SUMOLOGIC_ENVIRONMENT"]
                p = subprocess.run(command_str, check=True, text=True, shell=True, capture_output=True, env=new_environ)
                utils.debug(p.stdout)
                # After successful translation, monitors are saved in `output_path/sumologic/monitor/monitor.tf
                src_path = os.path.join(output_path, "sumologic", "monitor", "monitor.tf")
                generated_folder_path = os.path.join(output_path, "sumologic")
                shutil.move(src_path, dst_path)
                shutil.rmtree(generated_folder_path)

                if self.create_monitor_folder:
                    self.replace_parameter_in_monitor_tf_file(monitor_folders_dict, dst_path, monitor_folder_id)
                self.fix_monitors(dst_path)
                fields_file_path = os.path.join(output_path, "collection", "fields.tf")
                ExportFields.add_depends_on(dst_path, lookforward_pattern="queries", fields_file_path=fields_file_path)
            else:
                utils.warn(f"Skipping monitor export {dst_path} already exists")

        except subprocess.CalledProcessError as cpe:
            utils.error(f"Error: Terraform process failed with return code {cpe.returncode}. Error message: {cpe.stderr}")

        except Exception as e:
            utils.error(f"Error: An unexpected error occurred this: {e}")

    def replace_parameter_in_monitor_tf_file(self, monitor_folders_dict: Dict[str, Dict[str, Any]], file_path: str, monitor_folder_id: str, parameter="parent_id") -> None:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()

        # Define a regex pattern to match the folder_id line
        pattern = r'(%s\s*=\s*)(")([0-9A-Za-z]+)(")' % (parameter)

        def replace_id(match):
            original_id = match.group(3)
            real_id = f"sumologic_monitor_folder.{slugify(monitor_folders_dict[original_id]['name'], '_')}_folder.id"
            return f'{match.group(1)}{real_id}'

        # Replace the matched IDs using the re.sub() method
        updated_content = re.sub(pattern, replace_id, content)

        # Save the updated content to the file
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(updated_content)

    def fix_monitors(self, file_path: str) -> None:
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()
            skipped_lines_patterns = list(map(lambda x: re.compile(x), [r'\bcreated_at\b', r'\bcreated_by\b', r'\bmodified_at\b', r'\bmodified_by\b', r'\bis_locked\b', r'\bis_mutable\b', r'\bis_system\b', r'\bis_disabled\b', r'status\s*=\s*\[', r'\btime_zone\b', r'\bversion\b']))
            if not self.create_monitor_folder:
                skipped_lines_patterns.append(re.compile(r'\bparent_id\b'))
            min_data_points_pattern = re.compile(r'\bmin_data_points\s*=\s*"0"')
            monitor_resource_pattern = re.compile(r'\bresource\s*"sumologic_monitor"')
            processed_lines = []
            for line in lines:
                # removing tfer and suffix from resources names in monitor.tf
                if monitor_resource_pattern.search(line):
                    line = re.sub(r'tfer--', '', line)
                    line = re.sub(r'-[a-zA-Z0-9]*(?=" {)', '', line)

                # removing created_at / created_by and other hardcoded values in monitor.tf
                is_skipped_line = False
                for pattern in skipped_lines_patterns:
                    if pattern.search(line):
                        utils.debug(f"Skipping line: {line} in file: {file_path}")
                        is_skipped_line = True
                        break
                if not is_skipped_line:
                    processed_lines.append(line)

                if min_data_points_pattern.search(line):
                    utils.warn("min_data_points should be greater than 0")

            with open(file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred while fixing sumologic_monitor resource names: {e}")

    def generate_monitor_folders_tf(self, folders: Dict[str, Dict[str, str]], root_folder_id: str, root_monitor_folder_id: str) -> Dict[str, str]:
        folders_tf = dict()

        for folder_id, folder in folders.items():
            folder_text = ""
            folder_name = slugify(folder["name"], "_")
            # not creating create variables for folder name and description
            if folder_id == root_folder_id:
                # assuming if no parent id then monitor folder is installed in /Monitor path
                parent_id = None
            else:
                # child folders of the folders in monitor folder
                parent_id = f'sumologic_monitor_folder.{slugify(folders[folder["parentId"]]["name"], "_")}_folder.id'

            folder_text += f'resource "sumologic_monitor_folder" "{folder_name}_folder" {{\n'
            folder_text += f'  name        = "{folder["name"]}"\n'
            folder_text += f'  description = "{folder["description"]}"\n'
            if parent_id:
                folder_text += f'  parent_id   = {parent_id}\n'
            folder_text += '}\n\n'

            folders_tf[folder_id] = folder_text

        return folders_tf

    def generate_output_tf(self, monitors_tf_path: str, monitor_folders_tf_path: str) -> str:
        def extract_resource_names(file_path, resource_type):
            resource_names = []

            # Regular expression to match the desired pattern
            pattern = re.compile(fr'resource "{resource_type}" "(.+)" {{')

            # Open the file and read its lines
            with open(file_path, 'r') as file:
                for line in file.readlines():
                    # Search for the pattern in the current line
                    match = pattern.search(line)

                    # If a match is found, extract the resource name and add it to the list
                    if match:
                        resource_name = match.group(1)
                        resource_names.append(resource_name)

            return resource_names

        def generate_output_text(output_name, resource_type, object_names, name_attribute_name):
            output_text = f'output "{output_name}" {{\n'
            output_text += f'  description = "all the {output_name}"\n'
            output_text += '  value       = [\n'

            for name in object_names:
                output_text += f'    {{\n'
                output_text += f'      "id" = {resource_type}.{name}.id,\n'
                output_text += f'      "name" = {resource_type}.{name}.{name_attribute_name},\n'
                output_text += f'    }},\n'

            # Remove the extra comma and close the brackets
            output_text = output_text[:-2] + "\n"
            output_text += '  ]\n'
            output_text += '}\n\n'

            return output_text

        if os.path.isfile(monitor_folders_tf_path):
            monitor_folder_resource_names = extract_resource_names(monitor_folders_tf_path, "sumologic_monitor_folder")
        else:
            monitor_folder_resource_names = []
        if os.path.isfile(monitors_tf_path):
            monitor_resource_names = extract_resource_names(monitors_tf_path, "sumologic_monitor")
        else:
            monitor_resource_names = []
        output_tf = ""

        if monitor_folder_resource_names:
            output_tf += generate_output_text("monitor_folders", "sumologic_monitor_folder", monitor_folder_resource_names, "name")
        if monitor_resource_names:
            output_tf += generate_output_text("monitors", "sumologic_monitor", monitor_resource_names, "name")

        return output_tf
