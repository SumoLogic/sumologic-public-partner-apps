import json
import os

from sumoapputils.appdev.actions.translate_app import TranslateApp
from sumoapputils.appdev import utils
from sumoapputils.common.utils import get_sanitized_app_name


class TranslateAppBatch:
    def get_v1_app_folder_paths(self, scr_file_path):
        app_folders = []

        content_dir_path = utils.apps_v1_repo_path()
        with open(scr_file_path, "r") as all_apps:
            app_list = all_apps.readlines()

        for line in app_list:
            _, manifestfile = line.split(":")
            manifestfile = os.path.join(content_dir_path, "src", "main", "app-package", manifestfile)
            app_folders.append(os.path.dirname(manifestfile))

        return app_folders

    def execute(self, tf_path: str, output_path: str, scr_file_path: str, force_update=False, use_existing_appfolder=False):

        translateApp = TranslateApp()
        app_folders = self.get_v1_app_folder_paths(scr_file_path)

        utils.info(f"Found {len(app_folders)} folders containing v1 ap definition.Attempting to translate all of them...")

        for v1_app_folder_path in app_folders:
            manifest_file_path = translateApp.get_manifest_file_path(v1_app_folder_path)
            manifestjson = json.load(open(manifest_file_path))
            output_folder_path = os.path.join(output_path, get_sanitized_app_name(manifestjson['name']))
            utils.info(f"Translating v1 app located in {v1_app_folder_path} to v2. Output path: {output_folder_path}")

            try:
                translateApp.execute(v1_app_folder_path, tf_path, output_folder_path, force_update, use_existing_appfolder)
            except Exception as e:
                utils.error(f"Error while translating app located in {v1_app_folder_path}. Reason: {e}.")
