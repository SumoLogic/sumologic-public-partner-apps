import os
import sys
import yaml
from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.list_apps import ListAction
from sumoapputils.appdev.actions.find_uuid import FindUuidAction


class VerifyUploadAction:

    def __init__(self, version=None):
        self.app_dir = utils.find_app_directory(state.app_name)

        if not version:
            utils.info("Verifying App Upload using version from apps repo!")
            self.app_version = self.get_latest_app_version_from_repo(self.app_dir)
        else:
            utils.info("Verifying App Upload using user passed version!")
            self.app_version = version

    def find_uuid(self):
        if not state.app_uuid:
            utils.debug(f"No uuid given. Attempting to find uuid for app {state.app_name}")
            app_uuid, _ = FindUuidAction().execute()
            if app_uuid is None:
                utils.debug(f"No existing app with name {state.app_name} was found in any deployment.")
                sys.exit(1)
            else:
                utils.debug(f"Using existing uuid: {app_uuid} for verifying app: {state.app_name}")
                state.app_uuid = app_uuid

    @classmethod
    def get_latest_app_version_from_repo(cls, app_dir):
        '''returns {uuid: version}'''
        manifestfile_path = os.path.join(utils.get_default_apps_directory(), app_dir, 'manifest.yaml')
        if not os.path.isfile(manifestfile_path):
            utils.error(f"{manifestfile_path} doesn't exists")
            sys.exit(1)

        try:
            with open(manifestfile_path, "r") as f:
                manifestobj = yaml.safe_load(f.read())
            return manifestobj['version']
        except yaml.YAMLError as exc:
            utils.error(f"Error in reading {manifestfile_path} yaml {exc}")
            sys.exit(1)

    def execute(self):
        self.find_uuid()
        uploaded_deployments = []
        apps_by_dep = ListAction().execute()
        for dep, apps in apps_by_dep.items():
            if apps is not None:
                for app in apps.apps:
                    if app.name == state.app_name and app.uuid == state.app_uuid and app.latestVersion == self.app_version:
                        uploaded_deployments.append(dep)
        uploaded_deployments = ",".join(uploaded_deployments) if uploaded_deployments else "Not Available in any deployments"
        return f"{state.app_name:30}{state.app_uuid:40}{self.app_version:20}{uploaded_deployments:56}"
