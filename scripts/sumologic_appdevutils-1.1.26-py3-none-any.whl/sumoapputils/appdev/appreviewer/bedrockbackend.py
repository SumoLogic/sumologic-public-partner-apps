from boto3 import client
from botocore.config import Config
from langchain_aws import ChatBedrock
from sumoapputils.appdev.appreviewer.basereview import BaseModelBackend
from langchain_core.prompts import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate,
)
from langchain_core.rate_limiters import InMemoryRateLimiter
# from langchain.callbacks.tracers import ConsoleCallbackHandler
# from langchain.globals import set_debug
# set_debug(True)
# config={'callbacks': [ConsoleCallbackHandler()]}

config = Config(read_timeout=1000)
client = client(service_name='bedrock-runtime',
                config=config, region_name="us-west-2")


class BedrockBackend(BaseModelBackend):

    def __init__(self, appfolder, template_name, **kwargs):
        self.template_name = template_name
        self.model_id: str = kwargs.get('model_id', "anthropic.claude-3-5-sonnet-20240620-v1:0")
        self.set_model_params()

    def set_model_params(self, **params):

        self.model_params: dict = {
            "max_tokens": 8192,
            "temperature": 0,  # Using 0 to get reproducible results
            "stop_sequences": ["\n\nHuman:"]
        }
        self.model_params.update({k:v for k, v in params.items() if k in self.model_params})

    def get_model(self):
        rate_limiter = InMemoryRateLimiter(
            requests_per_second=10,
            check_every_n_seconds=1,
            max_bucket_size=10,
        )

        llm = ChatBedrock(
            model_id=self.model_id,
            model_kwargs=self.model_params,
            # rate_limiter=rate_limiter,
            region_name="us-west-2",
            client=client
        )

        return llm

    def get_body(self, prompt_param):
        human_prompt, system_prompt = self.get_prompts(self.template_name)
        if isinstance(human_prompt, str):
            human_template = HumanMessagePromptTemplate.from_template(human_prompt)
        else:
            human_template = HumanMessagePromptTemplate.from_template(template=human_prompt)

        if system_prompt:
            chat_template = ChatPromptTemplate.from_messages(
                [
                    SystemMessagePromptTemplate.from_template(system_prompt),
                    human_template
                ]
            )
        else:
            chat_template = ChatPromptTemplate.from_messages([
                human_template
            ])
        body = chat_template.format_messages(**prompt_param)
        print(f"Finished generating request body for model: {self.model_id}.")
        return body

    def invoke_model(self, prompt_params):

        try:
            llm = self.get_model()
            body = self.get_body(prompt_params)
            response = llm.invoke(body)
            print(f"Invoke model output for {self.__class__.__name__} Metadata: {response.response_metadata} Response Len: {len(response.content)}")
        except Exception as err:
            print("Error in model invocation: ")
            print(err)
            # print model related reasons
            raise err
        else:
            print(f"Finished invoking model: {self.model_id}.")

        return response

    def invoke_model_batch(self, prompt_params_batch, structured_obj=None):

        try:
            if structured_obj:
                llm = self.get_model().with_structured_output(structured_obj)
            else:
                llm = self.get_model()

            entries = [self.get_body(prompt_params) for prompt_params in prompt_params_batch]
            all_responses = llm.batch(entries, config={"max_concurrency": 3})

        except Exception as err:
            print("Error in model invocation: ")
            print(err)
            # print model related reasons
            raise err
        else:
            print(f"Finished invoking model: {self.model_id}.")

        return all_responses
