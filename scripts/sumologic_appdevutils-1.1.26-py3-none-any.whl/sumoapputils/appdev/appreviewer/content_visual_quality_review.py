from sumoapputils.appdev.appreviewer.basereview import BaseReviewGenerator
from sumoapputils.appdev.appreviewer.bedrockbackend import BedrockBackend
from sumoapputils.appdev.appreviewer.outputbackend import ExcelOutput
import os
import base64
from mimetypes import guess_type


class ContentImageQualityReviewGenerator(BaseReviewGenerator):
    template_name = "content_visual_quality_anthropic_v1.py"
    headers = ["Type", "DashboardName", "PanelName", "Review"]

    def __init__(self, appfolder, **kwargs):
        self.model_backend = BedrockBackend(appfolder, self.template_name, **kwargs)
        self.model_output = ExcelOutput(appfolder, **kwargs)
        self.appfolder = appfolder
        self.set_app_artifacts()

    def get_reviews(self, response):
        return response.splitlines()

    # Function to encode a local image into data URL
    @classmethod
    def local_image_to_data_url(self, image_path):
        mime_type, _ = guess_type(image_path)
        # Default to png
        if mime_type is None:
            mime_type = 'image/png'

        # Read and encode the image file
        with open(image_path, "rb") as image_file:
            base64_encoded_data = base64.b64encode(image_file.read()).decode('utf-8')

        # Construct the data URL
        return f"data:{mime_type};base64,{base64_encoded_data}"

    def generate_review(self):
        screenshot_location = os.path.join(self.appfolder, "assets", "images", "preview")
        dir_list = os.listdir(screenshot_location)
        output_data = []
        for screenshot_file_name in dir_list:
            screenshot_file_path = os.path.join(screenshot_location, screenshot_file_name)
            prompt_params = self.get_prompt_params(screenshot_file_path)
            response = self.model_backend.invoke_model(prompt_params)
            rows = self.get_reviews(response.content)
            for row in rows:
                if row != "":
                    output_data.append(row.split("|"))
            # self.model_output.generate_output(self.headers, output_data, "visual_review")
        return self.headers, output_data

    def get_prompt_params(self, screenshot_file_path) -> dict:
        return {
            "encoded_image_url": self.local_image_to_data_url(f"{screenshot_file_path}")
        }
