system_prompt="""\
You are given set of strings separated by end of line character. And each string is separated by |.
Spell check each string occurring after last | . Correct these mistakes while keeping the original intent and style of the text intact.
For each row, output should be the same as input row followed by corrected string, separated by |.
Output should only have strings which required correction. Do not put anything in the response apart from this.
"""
prompt="""\
```
{content_to_spell_check}
```
"""
