from typing import Union, List
from sumoapputils.appdev.appreviewer.basereview import BaseReviewGenerator
from sumoapputils.appdev.appreviewer.bedrockbackend import BedrockBackend
from pydantic import BaseModel, Field
from langchain.output_parsers import PydanticOutputParser


class QueryResponse(BaseModel):

    location: str = Field(None, description="Location of the Sumo Logic query string inside <location> tag")
    original_query_string: str = Field(None, description="Original input Sumo Logic query string inside <query> tag")
    optimized_query_string: str = Field(None, description="Optimized Sumo Logic query string, if no optimization is required then the value becomes NOCHANGE")
    review: str = Field(None, description="Explanations of optimizations performed in the optimized query, if no optimization is required then the value becomes NOCHANGE")
    priority: int = Field(default=0, description="rewards score")


class QueryResponseArray(BaseModel):

    query_response: List[QueryResponse] = Field(None, description="Json object response for each query")


parser = PydanticOutputParser(pydantic_object=QueryResponseArray)


class QueryReviewGenerator(BaseReviewGenerator):
    template_name = "query_review_anthropic_v2.py"
    headers = ["Location", "ExistingQuery", "OptimizedQuery", "ReviewComments", "Priority"]

    def __init__(self, appfolder, **kwargs):

        self.model_backend = BedrockBackend(appfolder, self.template_name, **kwargs)
        self.appfolder = appfolder
        self.model_backend.set_model_params(max_tokens=4000, temperature=0.2, top_k=50, top_p=0.2)
        self.set_app_artifacts()

    def get_reviews(self, response) -> list[list]:
        rows = []
        for query_obj in response.query_response:
            rows.append([
                query_obj.location,
                query_obj.original_query_string,
                query_obj.optimized_query_string,
                query_obj.review,
                query_obj.priority
            ])
        return rows

    def generate_review(self) -> Union[list[str], list[list]]:
        prompt_params = self.get_prompt_params()
        all_responses = self.model_backend.invoke_model_batch(prompt_params, structured_obj=QueryResponseArray)
        rows = []
        for idx, response in enumerate(all_responses):
            if response.query_response:
                rows.extend(self.get_reviews(response))
        return self.headers, rows

    def get_prompt_params(self) -> list[dict]:
        '''
            Todo: In future return list of prompt params
            In future response evaluator should verify the correctness of query
            It should also check whether input query string and it's id are correctly returned
        '''
        prompt = []
        self.query_map = []
        for query_string, panel_name, dash_name, query_key, _, _ in self.log_queries:
            location = f"Dashboard: {dash_name} Panel: {panel_name} QueryKey: {query_key}"""
            self.query_map.append((location, query_string))
            prompt.append(f"<location>{location}</location><query>{query_string}</query>")

        num_queries = len(prompt)
        print(f"Total Dashboard Queries : {num_queries}")
        for query_string, search_name, _, _ in self.saved_search_queries:
            location = f"SavedSearch: {search_name}"
            self.query_map.append((location, query_string))
            prompt.append(f"<location>{location}</location><query>{query_string}</query>")

        print(f"Total SavedSearch Queries : {len(prompt) - num_queries}")

        self.batch_size = 8  # so that all 1 dashboard query in one batch
        batched_prompts = []
        for i in range(0,len(prompt), self.batch_size):
            batch_prompt = prompt[i: i + self.batch_size]
            batch_prompt_str = "\n".join(batch_prompt)
            batched_prompts.append({
                "sumologic_query_string": {batch_prompt_str},
                "format_instructions": parser.get_format_instructions()
            })
        return batched_prompts
