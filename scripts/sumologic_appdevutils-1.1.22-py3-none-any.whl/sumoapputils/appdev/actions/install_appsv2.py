import requests
from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.common import Common
import json
import os
import time
from sumoapputils.common.utils import slugify, ALL_V2_APPS_FILENAME, load_yaml_to_json, get_scope_key_variable_value, get_scope_key_variable_default_value


class InstallAction(Common):

    def __init__(self):
        self.params = {}
        self.app_install_errors = {}

    @classmethod
    def get_config_mapping(cls, app_config_json):
        input_app_source_mapping = app_config_json["demo_input_mapping"]
        if not input_app_source_mapping:
            input_app_source_mapping = []
            config_yaml_path = os.path.join(utils.get_default_apps_directory(), app_config_json["relativeFolderPath"], "config.yaml")
            # compare length with what is present in the config yaml
            if not os.path.isfile(config_yaml_path):
                config_json_source_mapping = []
            else:
                config_json = load_yaml_to_json(config_yaml_path)
                config_json_source_mapping = config_json["parameters"]
            if len(config_json_source_mapping) > 0:
                full_apps_filepath = os.path.join(utils.apps_v2_repo_path(), "scripts", ALL_V2_APPS_FILENAME)
                if os.path.isfile(full_apps_filepath):
                    all_app_config = load_yaml_to_json(os.path.join(utils.apps_v2_repo_path(), "scripts", ALL_V2_APPS_FILENAME))
                else:
                    all_app_config = {"apps":[]}

                full_app_list_app_config_json = next(filter(lambda x: x["name"] == app_config_json["name"], all_app_config["apps"]), None)

                if full_app_list_app_config_json and full_app_list_app_config_json["demo_input_mapping"]:
                    input_app_source_mapping = full_app_list_app_config_json["demo_input_mapping"]
                else:
                    utils.warn(f"App: {app_config_json['name']} expects {len(config_json_source_mapping)} sources to be present in the yaml file. Generating random config parameter values...")

                    for idx, param_config in enumerate(config_json_source_mapping):
                        input_name = get_scope_key_variable_value(param_config)
                        scope_key_variable_default_value = get_scope_key_variable_default_value(param_config, silent=True)
                        if param_config["componentType"] == "scope":
                            input_app_source_mapping.append({
                                "input_name": input_name,
                                "input_name_value": "_sourceCategory"
                            })
                            input_app_source_mapping.append({
                                "input_name": scope_key_variable_default_value,
                                "input_name_value": f"Labs/{slugify(app_config_json['name'], replace_char='_')}/{slugify(param_config['label'], replace_char='_')}/{param_config['keyTfVar']}"
                            })
                        else:
                            input_app_source_mapping.append({
                                "input_name": input_name,
                                "input_name_value": scope_key_variable_default_value or "randomtext"
                            })

        return input_app_source_mapping

    def execute(self, app_source_mapping):
        self.find_uuid(self.params)
        for dep in state.deployments:
            auth = utils.auth(dep)
            if auth is None:
                utils.warn(f"No auth found for {dep}. Skipping it.")
            else:
                if state.app_version is None:
                    app_version="latest"
                else:
                    app_version=state.app_version
                utils.info(f"Installing app: {state.app_name} with version : {app_version} on deployment: {dep}")
                has_app_installed = False
                status, response_json = self.__install(dep, self.params, auth, app_source_mapping,app_version)
                if status == "Success":
                    has_app_installed = True
                else:
                    if "errors" in response_json and response_json["errors"][0]['code'] == "apps:app_already_installed":
                        utils.debug("App already installed. Uninstalling it!")
                        status, response_json = self.__uninstall(dep, self.params, auth)
                        if status == "Success":
                            time.sleep(5)
                            status, response_json = self.__install(dep, self.params, auth, app_source_mapping,app_version)
                            if status == "Success":
                                has_app_installed = True
                error_msg = ""
                if has_app_installed:
                    utils.success(f"Installation succeeded for app name - {state.app_name} with version : {app_version} and UUID - {state.app_uuid} in deployment - {dep}")
                else:
                    error_msg = f"Installation failed for app name - {state.app_name} with version : {app_version} and UUID - {state.app_uuid} in deployment - {dep} with response {response_json}"
                    utils.error(error_msg)
                    self.app_install_errors[dep] = error_msg
        return self.app_install_errors

    def __install(self, dep: str, params: dict, auth, app_source_mapping: list, version: str):
        response_json = ''
        try:
            payload = {"version": version}
            source_params = {}
            for parameter in app_source_mapping:
                source_params.update({
                    parameter["input_name"]: parameter["input_name_value"]
                })
            if source_params:
                payload["parameters"] = source_params
            response = requests.post(
                url=f"{utils.endpoint(dep)}/{self.params['uuid']}/install",
                auth=auth,
                headers={'Content-Type': 'application/json'},
                data=json.dumps(payload),
                timeout=300
            )
            response_json = response.json()
            response.raise_for_status()
            jobId = response_json["jobId"]
            return self._wait_for_job_completion(f"{utils.endpoint(dep)}/install", jobId, auth)
        except Exception as e:
            return 'Failed', response_json

    def __uninstall(self, dep: str, params: dict, auth):
        return self.uninstall(dep, self.params, auth)
