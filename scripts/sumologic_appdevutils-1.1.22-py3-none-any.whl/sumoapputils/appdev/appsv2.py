import json
import os
import click
import sys
import re
import semver
from sumoapputils.appdev import state
from sumoapputils.appdev.actions.list_apps import ListAction
from sumoapputils.appdev.actions.register import RegisterAction
from sumoapputils.appdev.actions.translate_app import TranslateApp
from sumoapputils.appdev.actions.translate_app_batch import TranslateAppBatch
from sumoapputils.appdev.actions.translate_manifest import TranslateManifest
from sumoapputils.appdev.actions.export_monitor import ExportMonitor
from sumoapputils.appdev.actions.upload import UploadAction
from sumoapputils.appdev.actions.exportV2app import ExportV2App
from sumoapputils.appdev.actions.delete import DeleteAction
from sumoapputils.appdev.actions.install_appsv2 import InstallAction
from sumoapputils.appdev.actions.uninstall_appsv2 import UninstallAction
from sumoapputils.appdev.actions.verify_upload import VerifyUploadAction
from sumoapputils.appdev.actions.update_changelog import UpdateChangelog
from sumoapputils.appdev.actions.release_changelog import ReleaseChangelog
from sumoapputils.appdev import utils
from sumoapputils.common.utils import load_yaml_to_json, dump_jsondata_to_yaml, GracefulKiller, get_sanitized_app_name


@click.group()
def appsv2():
    pass


@appsv2.command(help="For uploading the local copy of a v2 app to the specified deployments.")
@click.option('--deployments', '-d', required=True, multiple=True, help="Deployments to run the command over")
@click.option('--name', '-n', required=True, help="App name (as defined in the manifest)")
@click.option('--uuid', '-id', required=False, help="App UUID (received when registering the app)")
@click.option('--version', '-v', required=False, help="App version (must match the manifest and be greater than previously uploaded version")
@click.option('--private', is_flag=True, help="Whether app is private")
def upload_v2_app(deployments: list, name: str, uuid: str, version: str, private: bool):
    """
    Uploads the local copy of an app to the specified deployments.
    If the app is not registered in any deployment, it first registers it (see register command for details).
    """
    state.initialize(deployments, name, uuid, version, private)
    UploadAction().execute()


@appsv2.command(help="For registering a v2 app on the given deployments")
@click.option('--deployments', '-d', required=False, multiple=True, help="Deployments to run the command over")
@click.option('--name', '-n', required=True, help="App name (as defined in the manifest)")
@click.option('--uuid', '-id', required=False, help="App UUID (received when registering the app)")
@click.option('--private', is_flag=True, help="Whether app is private")
def register_v2_app(deployments: list, name: str, uuid: str, private: bool):
    """
    Registers the app on the given deployments.
    For each deployment, if the app is already registered, it skips that deployment.
    To decide what UUID to use, it first attempts to find a deployment where the app is registered.
    If it finds one, it uses the UUID of the registered apps for all other deployments.
    If it doesn't find one, it uses the first UUID it receives when registering on the deployments.
    """
    state.initialize(deployments, name, uuid, private=private)
    RegisterAction().execute()


@appsv2.command(help="For listing existing v2 apps on the given deployments")
@click.option('--deployments', '-d', required=False, multiple=True, help="Deployments to run the command over")
@click.option('--name', '-n', required=False, help="App name (as defined in the manifest)")
def list_v2_app(deployments: list, name: str):
    """
    Lists the existing apps
    If an app name is provided, it only lists details for that particular app.
    If a list of deployments is provided, it lists apps only for those deployments.
    """
    state.initialize(deployments, name)
    for dep, apps in ListAction().execute().items():
        if apps is not None:
            apps_as_json = json.dumps(apps, cls=utils.ns_encoder, indent=4)
            utils.success(f"Existing apps in deployment {dep}:\n\n{apps_as_json}\n\n")


@appsv2.command(help="For translating v1 app manifest (json) to v2 app manifest")
@click.option('--manifest_path', '-mp', type=click.Path(exists=True), required=True, multiple=False, help="Path to a v1 app manifest (json)")
@click.option('--content_path', '-cp', type=click.Path(exists=True), required=True, multiple=False, help="Path to a v1 app content definition (json)")
@click.option('--output_path', '-o', type=click.Path(exists=True), required=True, multiple=False,
              help="Path where a v2 manifest (yaml) will be saved")
def translate_manifest(manifest_path, content_path, output_path):
    TranslateManifest().execute(manifest_path, content_path, output_path)


@appsv2.command(help="For exporting v1 app content to V2 app content")
@click.option('--name', '-n', "app_folder_name", required=True, multiple=False, help="Name of the v1 app folder to be translated")
@click.option('--appfolderpath', '-pf', required=True, type=click.Choice(["Personal", "Installed Apps"]), help='Provide parent folder where app folder is present in sumo logic content library')
@click.option('--tf_path', '-tp', required=True, type=click.Path(exists=True), multiple=False, help="Path to the terraformer executable")
@click.option('--output_path', '-o', type=click.Path(exists=True), required=False, multiple=False,
              help="Path where a v2 content (terraform) will be saved")
@click.option('--deployment', '-d', required=True, help="Sumo Logic deployment name where app needs to be exported from.")
@click.option('--force-update', is_flag=True, default=False, help="Use force update for updating existing dashboard.tf/logssearches.tf files and screenshots")
def export_v2_app(app_folder_name, tf_path, output_path, appfolderpath, deployment, force_update):
    if not output_path:
        # assuming sumo logic app folder name is same as folder name in src github repo
        app_directory = os.path.join(utils.get_default_apps_directory(), get_sanitized_app_name(app_folder_name))
        if os.path.exists(app_directory):
            output_path = app_directory
        else:
            raise Exception(f"Please specify output_path. The default path {output_path} does not exists.")
    state.initialize(deployment, app_folder_name)
    ExportV2App().execute(app_folder_name, tf_path, output_path, appfolderpath, force_update)


@appsv2.command(help="For exporting monitors into terraform content")
@click.option('--monitor_path', '-mp', required=True, multiple=False, help='Path to monitor folder in the monitors library structure')
@click.option('--tf_path', '-tp', required=True, type=click.Path(exists=True), multiple=False, help="Path to the terraformer executable")
@click.option('--output_path', '-o', type=click.Path(exists=True), required=True, multiple=False,
              help="Path where a monitor.tf file will be saved")
@click.option('--deployment', '-d', required=True, help="Sumo Logic deployment name where monitors needs to be exported from.")
@click.option('--force-update', is_flag=True, default=False, help="Use force update for updating existing monitors.tf")
def export_monitors(monitor_path, tf_path, output_path, deployment, force_update):
    state.initialize(input_deps=deployment)
    ExportMonitor().execute(monitor_path, tf_path, output_path, force_update)


@appsv2.command(help="For translating v1 app (json) to v2 app content (terraform)")
@click.option('--app_path', '-ap', type=click.Path(exists=True),required=True, multiple=False,
              help="Path to the folder containing v1 app definition")
@click.option('--tf_path', '-tp', type=click.Path(exists=True), required=True, multiple=False, help="Path to the terraformer executable")
@click.option('--output_path', '-o', type=click.Path(exists=True), required=False, multiple=False,
              help="Path where a v2 app will be saved")
@click.option('--deployment', '-d', required=True, help="Sumo Logic deployment name where app needs to be exported from.")
@click.option('--force-update', is_flag=True, default=False, help="Use force update for updating existing monitors.tf")
@click.option('--use-existing-appfolder', is_flag=True, default=False, help="Use this flag to use existing app folder for migration")
def translate_v1_app(app_path, tf_path, output_path, deployment, force_update, use_existing_appfolder):
    state.initialize(input_deps=deployment)
    TranslateApp().execute(app_path, tf_path, output_path, force_update, use_existing_appfolder)


@appsv2.command(help="For translating v1 apps (json) to v2 app content (terraform)")
@click.option('-f', '--scr_file_path', required=True, type=click.Path(exists=True), help='Set filepath for scr file with format /path to appjson:/path to manifestfile')
@click.option('--tf_path', '-tp', type=click.Path(exists=True), required=True, multiple=False, help="Path to the terraformer executable")
@click.option('--output_path', '-o', type=click.Path(exists=True), required=True, multiple=False,
              help="Path where a v2 apps will be saved")
@click.option('--deployment', '-d', required=True, help="Sumo Logic deployment name where app needs to be exported from.")
@click.option('--force-update', is_flag=True, default=False, help="Use force update for updating existing monitors.tf")
@click.option('--use-existing-appfolder', is_flag=True, default=False, help="Use this flag to use existing app folder for migration")
def translate_v1_app_batch(tf_path, output_path, scr_file_path, deployment, force_update, use_existing_appfolder):
    state.initialize(input_deps=deployment)
    TranslateAppBatch().execute(tf_path, output_path, scr_file_path, force_update, use_existing_appfolder)


@appsv2.command(help="For removing v2 terraform based app from app catalog")
@click.option('--deployments', '-d', required=False, multiple=True, help="Deployments to run the command over")
@click.option('--name', '-n', required=True, help="App name (as defined in the manifest)")
@click.option('--uuid', '-id', required=True, help="App UUID (received when registering the app)")
@click.option('--private', is_flag=True, help="Whether app is private")
def delete_v2_app(deployments: list, name: str, uuid: str, private: bool):
    """
    For each deployment, it deletes that app if the app with same uuid exists else prints the error
    """
    state.initialize(deployments, name, uuid, private=private)
    DeleteAction().execute()


def validate_v2_app_config_file(ctx, param, value):
    all_app_config = load_yaml_to_json(value)
    if "apps" not in all_app_config:
        raise click.BadOptionUsage(option_name=param.name, message=''' Config file should follow below format
            apps:
                - demo_input_mapping: null
                  name: <app name(required)> (Ex Apache)
                  relativeFolderPath: <relative folderpath from src/ (required)> (Ex Apache)
                  uuid: null
                  version: <app version (required with form x.x.x)> (Ex 1.0.0)
                  installable: true or false
        ''', ctx=ctx)
    if not all_app_config["apps"]:
        raise click.BadOptionUsage(option_name=param.name, message="no apps found in the config", ctx=ctx)

    if not isinstance(all_app_config["apps"], list):
        raise click.BadOptionUsage(option_name=param.name, message="apps should contain list of app configurations", ctx=ctx)

    if not all(["name" in app_config and isinstance(app_config["name"], str) and app_config["name"].strip() for app_config in all_app_config["apps"]]):
        raise click.BadOptionUsage(option_name=param.name, message="name is mandatory parameter and should be non empty string", ctx=ctx)

    return all_app_config


@appsv2.command(help="For installing v2 terraform based app from app catalog")
@click.option('--deployments', '-d', required=True, multiple=True, help="Deployments to run the command over")
@click.option('--name', '-n', required=True, help="App name (as defined in the manifest)")
@click.option('--uuid', '-id', required=False, default=None, help="App UUID (received when registering the app)")
def install_v2_app(deployments: list, name: str, uuid):
    """
    For each deployment, it installs that app if the app with same uuid exists else prints the error

    """
    app_config_json = {}
    try:
        all_app_config_json = generate_v2_app_config_scr(deployment=deployments[0], app_name=[name])
        if not all_app_config_json["apps"]:
            utils.error(f"Not able to generate app config json for app: {name}")
        else:
            app_config_json = all_app_config_json["apps"][0]

        uuid = app_config_json.get("uuid")
        state.initialize(deployments, name, uuid)
    except ValueError:
        utils.error(f"Please ensure the app config for app: {name} is present in the yaml file")
        sys.exit(1)
    InstallAction().execute(app_config_json["demo_input_mapping"])


@appsv2.command(help="For uninstalling v2 terraform based app from app catalog")
@click.option('--deployments', '-d', required=True, multiple=True, help="Deployments to run the command over")
@click.option('--name', '-n', required=True, help="App name (as defined in the manifest)")
@click.option('--uuid', '-id', required=True, help="App UUID (received when registering the app)")
def uninstall_v2_app(deployments: list, name: str, uuid: str):
    """
    For each deployment, it uninstalls that app if the app with same uuid exists else prints the error

    """
    state.initialize(deployments, name, uuid)
    UninstallAction().execute()


@appsv2.command(help="For returning deployments where app version is not present")
@click.option('--deployments', '-d', required=True, multiple=True, help="Deployments to run the command over")
@click.option('--name', '-n', required=True, help="App name (as defined in the manifest)")
@click.option('--uuid', '-id', required=True, help="App UUID (received when registering the app)")
@click.option('--version', '-v', required=False, help="App Version (as defined in the manifest)")
def verify_upload_v2_app(deployments: list, name: str, uuid: str, version: str):
    """
    For all deployments, it returns in which deployment the app version of app is present and not present
    """

    state.initialize(deployments, name, uuid)
    output = VerifyUploadAction(version).execute()
    utils.info(f"{'app_name':30}{'uuid':40}{'version':20} {'deployments':56}")
    utils.info(output)


def update_version_in_v2_manifest(file_path, old_version, new_version):
    content = ''
    with open(file_path, "r") as fp:
        content = fp.read()

    new_content = re.sub(r'version:\s*' + re.escape(old_version), "version: " + new_version, content)

    with open(file_path, "w") as fp:
        fp.write(new_content)


def generate_v2_app_config_scr(outputfilepath=None, app_name=None, applistfilepath=None, deployment=None, bump_version=None, update_full_app_list=False):

    apps_already_deployed = {}
    if deployment:
        state.initialize([deployment])
        apps = ListAction().execute()[deployment]
        if apps is not None:
            apps_already_deployed = {app.name: {"uuid": app.uuid, "version": app.latestVersion, "installable": app.installable} for app in apps.apps}
    else:
        utils.debug("Deployment not provided.")

    app_names = set()
    if applistfilepath:
        with open(applistfilepath, 'r') as f:
            app_names = set([line.strip() for line in f.readlines() if not (line.startswith("//") or line.startswith("#")) and line.strip()])
    elif app_name:
        app_names = set(app_name)

    app_full_app_list_mapping = {}
    full_app_list_path = os.path.join(utils.apps_v2_repo_path(), "scripts", "full_app_list.yaml")
    if os.path.isfile(full_app_list_path):
        full_app_list_json = load_yaml_to_json(full_app_list_path)
        app_full_app_list_mapping = {app["name"]: {"uuid": app["uuid"], "installable": app["installable"], "version": app["version"], "prevVersions": app["prevVersions"]} for app in full_app_list_json["apps"]}
    else:
        raise Exception(f"full_app_list.yaml does not exist in the path {full_app_list_path}")

    all_app_config = {"apps": []}
    all_app_directories = next(os.walk(utils.get_default_apps_directory()))[1]
    if len(app_names) > 0:
        for app_dir in all_app_directories:
            manifest_path = os.path.join(utils.get_default_apps_directory(), app_dir, "manifest.yaml")
            if not os.path.isfile(manifest_path):
                utils.warn(f"ignoring folder {app_dir} with no manifest")
                continue

            manifest_json = load_yaml_to_json(manifest_path)

            if app_names and manifest_json['name'] not in app_names:  # ignore apps if name doesn't match input app name
                utils.debug(f"excluding app: {manifest_json['name']}")
                continue

            app_name = manifest_json['name']
            manifest_app_version = manifest_json['version']

            if "installable" in manifest_json:
                is_installable_app = manifest_json["installable"]
            elif "installable" in apps_already_deployed.get(app_name, {}):
                is_installable_app = apps_already_deployed[app_name]["installable"]
            elif "installable" in app_full_app_list_mapping.get(app_name, {}):
                is_installable_app = app_full_app_list_mapping[app_name]["installable"]
            else:
                is_installable_app = True
            prev_version_list = []
            if app_full_app_list_mapping.get(app_name) is not None and app_full_app_list_mapping.get(app_name).get("prevVersions"):
                prev_version_list = app_full_app_list_mapping.get(app_name).get("prevVersions")
                full_app_list_current_version = app_full_app_list_mapping.get(app_name).get("version")
                if full_app_list_current_version not in prev_version_list and semver.compare(manifest_app_version,full_app_list_current_version) > 0:
                    prev_version_list.append(full_app_list_current_version)
            all_app_config["apps"].append({
                "name": app_name,
                "version": manifest_app_version,
                "uuid": apps_already_deployed.get(app_name, {}).get("uuid") or app_full_app_list_mapping.get(app_name, {}).get("uuid"),
                "relativeFolderPath": str(app_dir),
                "demo_input_mapping": None,
                "installable": is_installable_app,
                "prevVersions": prev_version_list
            })
            demo_input_mapping = InstallAction.get_config_mapping(all_app_config["apps"][-1])
            if demo_input_mapping:
                all_app_config["apps"][-1]["demo_input_mapping"] = demo_input_mapping

            if bump_version:
                manifest_app_version_obj = semver.Version.parse(manifest_app_version)
                bump_operation = getattr(manifest_app_version_obj, f"bump_{bump_version}")
                new_version = str(bump_operation())
                all_app_config["apps"][-1]["version"] = new_version
                utils.info(f"Bumping version of {app_name} to {new_version} in manifest.yaml")
                update_version_in_v2_manifest(manifest_path, manifest_app_version, new_version)
                if manifest_app_version not in all_app_config["apps"][-1]["prevVersions"]:
                    all_app_config["apps"][-1]["prevVersions"].append(manifest_app_version)

            if app_name in apps_already_deployed:
                deployed_version = apps_already_deployed[app_name]["version"]
                manifest_app_version = all_app_config["apps"][-1]["version"]
                if semver.compare(manifest_app_version, deployed_version) >= 1:
                    utils.warn(f"Version in manifest {manifest_app_version} does not match {deployed_version} of {app_name} in {deployment}")

    all_app_config["apps"] = sorted(all_app_config["apps"], key=lambda x: x['name'].lower())
    app_count = len(all_app_config["apps"])
    if app_names:
        apps_with_configs = set([app_config["name"] for app_config in all_app_config["apps"]])
        apps_without_configs = app_names - apps_with_configs
        if apps_without_configs:
            utils.warn(f"Not able to generate config for below apps: {','.join(apps_without_configs)}")

    if app_count == 0:
        utils.warn("No app found! Empty config generated")
    else:
        utils.success(f"Generated config for {app_count} apps using deployment {deployment} successfully!")
        # write to full_app_list
        if update_full_app_list:
            for app in all_app_config["apps"]:
                app_found = False
                for app_full_list in full_app_list_json["apps"]:
                    if app["name"]==app_full_list["name"]:
                        app_found = True
                        app_full_list["prevVersions"]=app["prevVersions"]
                        app_full_list["version"]=app["version"]
                if not app_found:
                    full_app_list_json.update(app)
            dump_jsondata_to_yaml(full_app_list_json, full_app_list_path)

    if outputfilepath:
        dump_jsondata_to_yaml(all_app_config, outputfilepath)
    else:
        return all_app_config


@appsv2.command(help="For generating deployment config of v2 apps using the specified deployment.")
@click.option('--deployment', '-d', required=True, help="Deployment to fetch the uuid.")
@click.option('--name', '-n', required=False, help="App name (as defined in the manifest)")
@click.option('-f', '--applisttxtfilepath', required=False, type=click.Path(exists=True), help='Path to file containing app list')
@click.option('--outputfilepath', '-o', required=False, default="app_list.yaml", help="Output file name")
@click.option('--bump_version', '-b', required=False, default=None, type=click.Choice(["major", "minor", "patch"]), help="Specify version to bump (major,minor or patch)")
@click.option('-uf', "--update_full_app_list", is_flag=True, required=False, default=False)
def generate_v2_app_config(deployment: str, name: str, applisttxtfilepath:str, outputfilepath: str, bump_version, update_full_app_list):
    """
        Generates v2 app config yaml by iterating over each app folder.
        It doesn't include uuid if app is not present in deployment
        If name and applisttxtfilepath containing app names are specified it generates config only for those apps
    """
    generate_v2_app_config_scr(outputfilepath=outputfilepath, deployment=deployment, app_name=name, applistfilepath=applisttxtfilepath, bump_version=bump_version, update_full_app_list=update_full_app_list)


@appsv2.command(help="For deploying multiple V2 apps to the specified deployment.")
@click.option('--deployment', '-d', required=True, help="Sumo Logic deployment name where app needs to be deployed.")
@click.option('-f', '--applistfilepath', "all_app_config", required=True, callback=validate_v2_app_config_file, type=click.Path(exists=True), help='Path to app list deployment config file')
@click.option('--force-upload', is_flag=True, help="Use force upload only when you want to deploy existing version on stag.")
def batch_upload_v2_apps(deployment, all_app_config, force_upload):
    """
    Uploads the local copy of an app to the specified deployments.
    If the app is not registered in any deployment, it first registers it (see register command for details).
    """
    if force_upload and deployment != "stag":
        utils.warn("You can use force upload only on stag deployment")
        sys.exit(1)
    process_killer = GracefulKiller()
    success_app_count = failed_app_count = 0
    for app_config in all_app_config["apps"]:
        linestrip = '*' * 40
        utils.info(f"{linestrip} Deploying {app_config['name']} {linestrip}\n")
        if process_killer.kill_now:
            utils.info("Aborting gracefully!")
            sys.exit(1)
        state.initialize(deployment, app_config["name"], app_config["uuid"], app_config["version"])
        error_msgs = UploadAction().execute()
        if error_msgs and "new_version_not_greater" in error_msgs.get(deployment, '') and deployment == "stag" and force_upload:
            utils.info(f"New version not greater retrying by deleting app on stag")
            DeleteAction().execute()
            error_msgs = UploadAction().execute()
        if error_msgs:
            failed_app_count += 1
        else:
            success_app_count += 1
    utils.success(f"Successfully deployed: {success_app_count} Failed to deploy: {failed_app_count} apps on deployment {deployment} !")


@appsv2.command(help="For removing v2 terraform based app from app catalog")
@click.option('--deployment', '-d', required=True, help="Sumo Logic deployment name where app needs to be deleted.")
@click.option('-f', '--applistfilepath', "all_app_config", required=True, callback=validate_v2_app_config_file, type=click.Path(exists=True), help='Path to app list deployment config file')
def batch_delete_v2_apps(deployment: str, all_app_config):
    """
    For each deployment, it deletes that app if the app with same uuid exists else prints the error
    """
    process_killer = GracefulKiller()
    success_app_count = failed_app_count = 0
    for app_config in all_app_config["apps"]:
        linestrip = '*' * 40
        utils.info(f"{linestrip} Deleting {app_config['name']} {linestrip}\n")
        if process_killer.kill_now:
            utils.info("Aborting gracefully!")
            sys.exit(1)
        state.initialize(deployment, app_config["name"], app_config["uuid"], app_config["version"])
        error_msgs = DeleteAction().execute()
        if error_msgs:
            failed_app_count += 1
        else:
            success_app_count += 1
    utils.success(f"Successfully deleted: {success_app_count} Failed to delete: {failed_app_count} apps on deployment {deployment} !")


@appsv2.command(help="For installing v2 terraform based app from app catalog")
@click.option('--deployment', '-d', required=True, help="Sumo Logic deployment name where app needs to be installed.")
@click.option('-f', '--applistfilepath', "all_app_config", callback=validate_v2_app_config_file, required=True, type=click.Path(exists=True), help='Path to app list deployment config file')
def batch_install_v2_apps(deployment: str, all_app_config):
    """
    For each deployment, it installs that app if the app with same uuid exists else prints the error

    """
    process_killer = GracefulKiller()
    success_app_count = failed_app_count = 0
    for app_config in all_app_config["apps"]:
        linestrip = '*' * 40
        utils.info(f"{linestrip} Installing {app_config['name']} {linestrip}\n")
        if process_killer.kill_now:
            utils.info("Aborting gracefully!")
            sys.exit(1)
        if app_config["installable"]:
            state.initialize(deployment, app_config["name"], app_config["uuid"], app_config["version"])
            app_source_mapping = InstallAction.get_config_mapping(app_config)
            error_msgs = InstallAction().execute(app_source_mapping)
            if error_msgs:
                failed_app_count += 1
            else:
                success_app_count += 1
        else:
            utils.warn(f"ignoring doc only app: {app_config['name']}")
    utils.success(f"On deployment {deployment} successfully installed {success_app_count} apps. failed to install {failed_app_count} apps !")


@appsv2.command(help="For uninstalling v2 terraform based app from app catalog")
@click.option('--deployment', '-d', required=True, help="Sumo Logic deployment name where app needs to be installed.")
@click.option('-f', '--applistfilepath', "all_app_config", callback=validate_v2_app_config_file, required=True, type=click.Path(exists=True), help='Path to app list deployment config file')
def batch_uninstall_v2_apps(deployment: str, all_app_config):
    """
    For each deployment, it uninstalls that app

    """
    process_killer = GracefulKiller()
    success_app_count = failed_app_count = 0
    for app_config in all_app_config["apps"]:
        linestrip = '*' * 40
        utils.info(f"{linestrip} UnInstalling {app_config['name']} {linestrip}\n")
        if process_killer.kill_now:
            utils.info("Aborting gracefully!")
            sys.exit(1)
        if app_config["installable"]:
            state.initialize(deployment, app_config["name"], app_config["uuid"], app_config["version"])
            error_msgs = UninstallAction().execute()
            if error_msgs:
                failed_app_count += 1
            else:
                success_app_count += 1
        else:
            utils.warn(f"ignoring doc only app: {app_config['name']}")
    utils.success(f"On deployment {deployment} successfully uninstalled {success_app_count} apps. failed to uninstall {failed_app_count} apps !")


@appsv2.command(help="For returning deployments where app version is not present")
@click.option('--deployments', '-d', required=True, multiple=True, help="Deployments to run the command over")
@click.option('-f', '--applistfilepath', "all_app_config", callback=validate_v2_app_config_file, required=True, type=click.Path(exists=True), help='Path to app list deployment config file')
def batch_verify_upload_v2_apps(deployments: list, all_app_config):
    """
    For all deployments, it returns in which deployment the app version of app is present and not present
    """
    process_killer = GracefulKiller()
    verified_results = []
    for app_config in all_app_config["apps"]:
        if process_killer.kill_now:
            utils.info("Aborting gracefully!")
            sys.exit(1)
        state.initialize(deployments, app_config["name"], app_config["uuid"], app_config["version"])
        output = VerifyUploadAction(app_config["version"]).execute()
        verified_results.append(output)
    utils.success(f"Verified {len(verified_results)} apps successfully!")
    utils.info(f"{'app_name':30}{'uuid':40}{'version':20} {'deployments':56}")
    for output in verified_results:
        utils.info(output)


@appsv2.command(help="for batch updating changelog")
@click.option('-f', '--scr_file_path', required=True, type=click.Path(exists=True), help='Set filepath for scr file with format /path to appjson:/path to manifestfile')
@click.option('--target-branch', '-t', type=str, required=False, multiple=False, help="Target branch to pull logs from", default='master')
def batch_update_changelog(scr_file_path, target_branch):
    apps = load_yaml_to_json(scr_file_path)
    UpdateChangelog().execute(apps["apps"], target_branch)


@appsv2.command(help="for batch releasing changelog")
@click.option('-f', '--scr_file_path', required=True, type=click.Path(exists=True), help='Set filepath for scr file with format /path to appjson:/path to manifestfile')
def batch_release_changelog(scr_file_path):
    apps = load_yaml_to_json(scr_file_path)
    ReleaseChangelog().execute(apps["apps"])
