from sumoapputils.appdev.appreviewer.basereview import BaseReviewGenerator
from sumoapputils.appdev.appreviewer.bedrockbackend import BedrockBackend
from sumoapputils.appdev.appreviewer.outputbackend import ExcelOutput


class ContentTextQualityReviewGenerator(BaseReviewGenerator):
    template_name = "content_text_quality_anthropic_v2.py"
    headers = ["FileName", "Type", "Location", "OriginalText", "CorrectedText"]

    def __init__(self, appfolder, **kwargs):
        self.model_backend = BedrockBackend(appfolder, self.template_name, **kwargs)
        self.model_output = ExcelOutput(appfolder, **kwargs)
        self.appfolder = appfolder
        self.set_app_artifacts()

    def get_reviews(self, response):
        return response.splitlines()

    def generate_review(self):
        prompt_params = self.get_prompt_params()
        response = self.model_backend.invoke_model(prompt_params)
        rows = self.get_reviews(response.content)
        output_data = []
        for row in rows:
            row = row.replace("<text>", "").replace("</text>", "")
            output_data.append(row.split("|"))
        return self.headers, output_data

    def get_prompt_params(self):
        '''
            Todo: In future return list of prompt params
            Todo: readme, changelog
            Todo: app description
            Todo: monitor title + description
            Todo: saved search name + description
            Another prompt to suggest short alter native for panel title
        '''
        prompt = StringAppender()
        text_panel_content = []
        for dash in self.dashboards:
            dashboard_title = dash["title"]
            new_line = f"dashboard.tf|dashboard_title|X|<text>{dashboard_title}</text>"
            prompt.add_new_line(new_line)
            dashboard_description = dash.get("description")
            if dashboard_description:
                new_line = f"dashboard.tf|dashboard_description|X|<text>{dashboard_description}</text>"
                prompt.add_new_line(new_line)
            panels = dash["panel"]
            allPanels = [panels] if isinstance(panels, dict) else panels
            for panel in allPanels:
                paneltype = list(panel.keys())[0]
                if paneltype == "text_panel":
                    text_panel_title = panel["text_panel"].get("title")
                    if text_panel_title:
                        new_line = f"dashboard.tf|text_panel_title|{dashboard_title}|<text>{text_panel_title}</text>"
                        prompt.add_new_line(new_line)

                    text_panel_content = panel["text_panel"].get("text")
                    if text_panel_content:
                        new_line = f"dashboard.tf|text_panel_content|{dashboard_title}-{text_panel_title}|<text>{text_panel_content}</text>"
                        prompt.add_new_line(new_line)
                    continue
                panel_title = panel["sumo_search_panel"]["title"]
                new_line = f"dashboard.tf|panel_title|{dashboard_title}|<text>{panel_title}</text>"
                prompt.add_new_line(new_line)

        app_description = self.manifestjson["description"]
        new_line = f"manifest.yaml|app_description|Manifest File|<text>{app_description}</text>"
        prompt.add_new_line(new_line)

        prompt_str = prompt.to_string()
        return {
            "content_to_spell_check": {prompt_str}
        }


class StringAppender:

    def __init__(self):
        self.content = ""
        self.input_seperator = "|"

    def add_new_line(self, new_string):
        if self.content:
            self.content += "\n"  # Add a newline if there's already content
        self.content += new_string

    def to_string(self):
        return self.content
