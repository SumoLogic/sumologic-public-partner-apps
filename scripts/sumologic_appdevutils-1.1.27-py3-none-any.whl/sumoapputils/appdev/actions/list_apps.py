import json
from types import SimpleNamespace as Namespace

import requests

from sumoapputils.appdev import utils, state


class ListAction:

    def __init__(self):
        self.apps_by_deployment = {}

    def execute(self):
        for dep in state.deployments:
            apps = self.__list_for_dep(dep)
            if apps:
                self.apps_by_deployment[dep] = apps
        return self.apps_by_deployment

    def __list_for_dep(self, dep: str):
        auth = utils.auth(dep)
        if auth is None:
            utils.warn(f"No auth found for {dep}. Skipping it.")
            return None
        else:
            apps_api_url = utils.endpoint(dep)
            try:
                response = requests.get(
                    url=apps_api_url,
                    auth=auth,
                    headers={'Content-Type': 'application/json'},
                    timeout=120
                )
            except requests.exceptions.ConnectionError as e:
                utils.warn(f"Connection error reaching {dep} ({apps_api_url}): {e}. Skipping deployment.")
                return None
            except requests.exceptions.Timeout as e:
                utils.warn(f"Request to {dep} ({apps_api_url}) timed out: {e}. Skipping deployment.")
                return None
            except requests.exceptions.RequestException as e:
                utils.warn(f"Network error reaching {dep} ({apps_api_url}): {e}. Skipping deployment.")
                return None
            if response.ok:
                apps = json.loads(response.content, object_hook=self.__hook)
                filtered = [app for app in getattr(apps, 'apps', []) if state.app_name is None or app.name == state.app_name]
                utils.debug(f"Found {len(filtered)} app after filtering.")
                apps = Namespace(**{'apps': filtered})
                return apps
            else:
                utils.error(f"Error in get {apps_api_url} API: status={response.status_code} reason={response.reason} text={response.text}")
                return None

    def list_for_all_dep(self):
        apps_by_deployment = {}
        for dep in state.all_authorized_deployments:
            apps_by_deployment[dep] = self.__list_for_dep(dep)
        return apps_by_deployment

    def __hook(self, d):
        if not d:
            return None
        else:
            return Namespace(**d)
