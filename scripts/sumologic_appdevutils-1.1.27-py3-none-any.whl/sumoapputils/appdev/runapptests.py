#!/usr/bin/env python
import os
import sys
from unittest import TestLoader
import click
import json

from sumoapputils.common.testutils import run_test
from sumoapputils.common.utils import EXCLUDED_APP_PREFIXES, ENVIRONMENT, get_test_logger, get_normalized_path, load_yaml_to_json
from sumoapputils.common.testapp import TestClassicDashboardsV2, TestTfDashboards
from sumoapputils.appdev.utils import apps_v1_repo_path, get_default_apps_directory
from sumoapputils.appdev import utils
logger = get_test_logger()


def test_all_apps(deployment_name, access_id, access_key,
                  test_names, all_app_config, base_dir=None):
    cnt = 0
    failed_tests_cnt = warning_tests_cnt = 0
    failed_apps = []
    warning_apps = []
    app_files = []

    app_dir = apps_v1_repo_path() if base_dir is None else base_dir

    with open(all_app_config) as fp:
        app_files = fp.readlines()

    filtered_app_files = filter(lambda x: x and x.strip() and not (
        x.startswith(EXCLUDED_APP_PREFIXES)), app_files)

    for row in filtered_app_files:
        appfile, manifestfile = row.strip().split(":")
        appfile = os.path.join(app_dir, "src", "main", "app-package", appfile)
        manifestfile = os.path.join(app_dir, "src", "main", "app-package", manifestfile)
        cnt += 1
        has_failures, has_warnings = run_test(manifestfile, appfile,
                                              deployment_name, access_id,
                                              access_key, test_names)

        if has_failures:
            failed_tests_cnt += 1
            failed_apps.append(row.strip())
        elif has_warnings:
            warning_tests_cnt += 1
            warning_apps.append(row.strip())

    logger.info("Tests Results=> Total Apps Tested: %d Total Apps Failing Tests: %d Total Apps Passed With Warnings: %d \nFiles with Failures: %s \nFiles with Warnings: %s" % (cnt, failed_tests_cnt, warning_tests_cnt, failed_apps, warning_apps))
    with open("failed_apps.txt", "w") as fp:
        fp.write("\n".join(failed_apps))

    has_any_warnings = True if warning_tests_cnt > 0 else False
    has_any_failures = True if failed_tests_cnt > 0 else False

    return has_any_failures, has_any_warnings


def test_all_v2_apps(deployment_name, access_id, access_key,
                     test_names, all_app_config):
    cnt = 0
    failed_tests_cnt = warning_tests_cnt = 0
    failed_apps = []
    warning_apps = []
    apps_dir_path = get_default_apps_directory()

    data = load_yaml_to_json(all_app_config)

    if 'apps' in data:
        for line in data['apps']:
            relative_folder_path = line.get('relativeFolderPath', 'N/A')
            manifestfile = os.path.join(apps_dir_path, relative_folder_path, "manifest.yaml")
            sourceappfile = os.path.join(apps_dir_path, relative_folder_path, "resources", "dashboards.tf")
            cnt += 1
            has_failures, has_warnings = run_test(manifestfile, sourceappfile,
                                                  deployment_name, access_id,
                                                  access_key, test_names, True)
            if has_failures:
                failed_tests_cnt += 1
                failed_apps.append(line.get('name'))
            elif has_warnings:
                warning_tests_cnt += 1
                warning_apps.append(line.get('name'))

    logger.info("Tests Results=> Total V2 Apps Tested: %d Total V2 Apps Failing Tests: %d Total V2 Apps Passed With Warnings: %d \nFiles with Failures: %s \nFiles with Warnings: %s" % (cnt, failed_tests_cnt, warning_tests_cnt, failed_apps, warning_apps))
    with open("failed_v2_apps.txt", "w") as fp:
        fp.write("\n".join(failed_apps))

    has_any_warnings = True if warning_tests_cnt > 0 else False
    has_any_failures = True if failed_tests_cnt > 0 else False

    return has_any_failures, has_any_warnings


def get_test_names(includetests=None, excludetests=None, isTfApp=False):
    test_loader = TestLoader()
    if isTfApp:
        test_names = test_loader.getTestCaseNames(TestTfDashboards)
    else:
        test_names = test_loader.getTestCaseNames(TestClassicDashboardsV2)
    if includetests:
        includetests = [test.strip() for test in includetests]
        test_names = includetests
    if excludetests:
        excludetests = [test.strip() for test in excludetests]
        test_names = filter(lambda x: x not in excludetests, test_names)

    test_names = list(test_names)

    DEPLOYMENT_TEST = "test_is_deployable"
    V2_TEST_INSTALLABLE = "test_tfApp_installable"
    V2_TEST_UPDATE = "test_update_v2_app"

    if not os.environ.get("ENABLE_PARTNER_CICD_COMMANDS", None) and not isTfApp:
        EXCLUDE_PARTNER_ONLY_TESTS = ("test_folder_structure", "test_uuid_matches_stored_value")
    elif isTfApp:
        EXCLUDE_PARTNER_ONLY_TESTS = ("test_uuid_matches_stored_value",)
    else:
        EXCLUDE_PARTNER_ONLY_TESTS = ()

    test_names = list(filter(lambda x, testset=EXCLUDE_PARTNER_ONLY_TESTS: x not in testset, test_names))

    if DEPLOYMENT_TEST in test_names:
        # putting deployment test in last
        test_names.remove(DEPLOYMENT_TEST)
        test_names.append(DEPLOYMENT_TEST)
        # putting app installation test at last if running deployment test.
    if V2_TEST_INSTALLABLE in test_names:
        test_names.remove(V2_TEST_INSTALLABLE)
        test_names.append(V2_TEST_INSTALLABLE)
    if V2_TEST_UPDATE in test_names:
        test_names.remove(V2_TEST_UPDATE)
        test_names.append(V2_TEST_UPDATE)
    return test_names


def validate_sumo_secrets(ctx, param, value):

    if not value:
        deployment = ctx.params.get('deployment')
        if not deployment:
            # if deployment not passed then sumo secrets are not required
            return value
        path = os.environ.get('SUMO_ACCESS_KEYS_FILE_PATH')
        if not path:
            utils.error("Access keys file path must be provided via environment variable SUMO_ACCESS_KEYS_FILE_PATH !")
            sys.exit(1)

        path = get_normalized_path(path)
        if not os.path.isfile(path):
            utils.error(f"Access keys file path: {path} does not exists!")
            sys.exit(1)

        with open(path) as file:
            keys_map = json.load(file)
            auth_for_dep = keys_map.get(deployment)
            if auth_for_dep:
                value = auth_for_dep.get(param.name, "")

        if not value:
            utils.error(f"Access keys not found for deployment {deployment}!")

    return value


def validate_testnames(ctx, param, value):

    ''' cannot be moved to common because get_test_names function is different in both appdev and partner modules'''
    testnames = []
    if value:
        all_test_names = get_test_names()
        testnames = [c.strip() for c in value.split(',')]
        for c in testnames:
            if c not in all_test_names:
                raise click.BadOptionUsage(option_name=param.name, message="%s is not an available test name." % c, ctx=ctx)

    return testnames


def validate_v2testnames(ctx, param, value):

    ''' cannot be moved to common because get_test_names function is different in both appdev and partner modules'''
    testnames = []
    if value:
        all_test_names = get_test_names(isTfApp=True)
        testnames = [c.strip() for c in value.split(',')]
        for c in testnames:
            if c not in all_test_names:
                raise click.BadOptionUsage(option_name=param.name, message="%s is not an available test name." % c, ctx=ctx)

    return testnames


@click.group()
def apptestcmd():
    pass


@apptestcmd.command(help="For running unit tests for multiple apps using config file")
@click.option('-i', '--includetests', default=','.join(get_test_names()), show_default=True, is_flag=False, metavar='<testnames>', type=click.STRING, help="specify testnames separated by comma ex: test_not_using_default_lookup, test_file_path_exists_in_applist", callback=validate_testnames)
@click.option('-e', '--excludetests', default='', show_default=False, is_flag=False, metavar='<testnames>', type=click.STRING, help="specify testnames separated by comma ex: test_not_using_default_lookup, test_file_path_exists_in_applist", callback=validate_testnames)
@click.option('-f', '--filepath', required=True, type=click.Path(exists=True), help='Set filepath for file containing list of apps in following format appjsonfile:manifestfile')
@click.option('-b', '--basedirectory', default=None, type=click.Path(exists=True), help='Set directory path from where appjson:manifestfile entries are accessible')
@click.option('-d', "--deployment", required=False, default=lambda: ENVIRONMENT.SUMO_DEPLOYMENT, type=click.Choice(['stag', 'long']), help="deployment_name nite/stag/long.")
@click.option("-k", "--access_id", help="access_id for deployment(required)", callback=validate_sumo_secrets)
@click.option("-c", "--access_key", help="access_key for deployment(required)", callback=validate_sumo_secrets)
def run_all_app_tests(includetests, excludetests, filepath, basedirectory=None, deployment='', access_id='', access_key=''):
    test_names = get_test_names(includetests, excludetests)
    has_failures, _ = test_all_apps(deployment, access_id,
                                    access_key, test_names, filepath, basedirectory)

    exit_status = 1 if has_failures else 0
    sys.exit(exit_status)


@apptestcmd.command(help="For running unit tests for multiple v2 apps using config file")
@click.option('-i', '--includetests', default=','.join(get_test_names(isTfApp=True)), show_default=True, is_flag=False, metavar='<testnames>', type=click.STRING, help="specify testnames separated by comma ex: test_not_using_default_lookup, test_file_path_exists_in_applist", callback=validate_v2testnames)
@click.option('-e', '--excludetests', default='', show_default=False, is_flag=False, metavar='<testnames>', type=click.STRING, help="specify testnames separated by comma ex: test_not_using_default_lookup, test_file_path_exists_in_applist", callback=validate_v2testnames)
@click.option('-f', '--filepath', required=True, type=click.Path(exists=True), help='Set filepath for scr_app_list.yaml file containing list of apps')
@click.option('-d', "--deployment", required=False, default=lambda: ENVIRONMENT.SUMO_DEPLOYMENT, type=click.Choice(['stag', 'long']), help="deployment_name nite/stag/long.")
@click.option("-k", "--access_id", help="access_id for deployment(required)", callback=validate_sumo_secrets)
@click.option("-c", "--access_key", help="access_key for deployment(required)", callback=validate_sumo_secrets)
def run_all_app_tests_v2(includetests, excludetests, filepath, deployment='', access_id='', access_key=''):
    test_names = get_test_names(includetests, excludetests)
    has_failures, _ = test_all_v2_apps(deployment, access_id,
                                       access_key, test_names, filepath)
    exit_status = 1 if has_failures else 0
    sys.exit(exit_status)


@apptestcmd.command(help="For running app unit tests")
@click.option('-i', '--includetests', default=','.join(get_test_names()), show_default=True, is_flag=False, metavar='<testnames>', type=click.STRING, help="specify testnames separated by comma ex: test_not_using_default_lookup, test_file_path_exists_in_applist", callback=validate_testnames)
@click.option('-e', '--excludetests', default='', show_default=False, is_flag=False, metavar='<testnames>', type=click.STRING, help="specify testnames separated by comma ex: test_not_using_default_lookup, test_file_path_exists_in_applist", callback=validate_testnames)
@click.option("-m", "--manifestfile", required=True, type=click.Path(exists=True), help="manifest file path Ex: src/<path to json>")
@click.option("-s", "--sourceappfile", required=True, type=click.Path(exists=True), help="appjson file path Ex: src/<path to json>")
@click.option('-d', "--deployment", required=False, default=lambda: ENVIRONMENT.SUMO_DEPLOYMENT, type=click.Choice(['stag', 'long']), help="deployment_name nite/stag/long.")
@click.option("-k", "--access_id", help="access_id for deployment(required)", callback=validate_sumo_secrets)
@click.option("-c", "--access_key", help="access_key for deployment(required)", callback=validate_sumo_secrets)
def run_app_tests(includetests, excludetests, manifestfile, sourceappfile, deployment='', access_id='', access_key=''):
    print("run_app_test")
    test_names = get_test_names(includetests, excludetests)
    has_failures, _ = run_test(manifestfile, sourceappfile,
                               deployment, access_id,
                               access_key, test_names,False)

    exit_status = 1 if has_failures else 0
    sys.exit(exit_status)


@apptestcmd.command(help="For running app unit tests for v2 Apps")
@click.option('-i', '--includetests', default=','.join(get_test_names(isTfApp=True)), show_default=True, is_flag=False, metavar='<testnames>', type=click.STRING, help="specify testnames separated by comma ex: test_not_using_default_lookup, test_file_path_exists_in_applist", callback=validate_v2testnames)
@click.option('-e', '--excludetests', default='', show_default=False, is_flag=False, metavar='<testnames>', type=click.STRING, help="specify testnames separated by comma ex: test_not_using_default_lookup, test_file_path_exists_in_applist", callback=validate_v2testnames)
@click.option("-f", "--appfolder", required=True, help="app folder name under env variable SUMO_APPS_V2_REPO_PATH")
@click.option('-d', "--deployment", required=False, default=lambda: ENVIRONMENT.SUMO_DEPLOYMENT, type=click.Choice(['stag', 'long']), help="deployment_name stag/long.")
@click.option("-k", "--access_id", help="access_id for deployment(required)", callback=validate_sumo_secrets)
@click.option("-c", "--access_key", help="access_key for deployment(required)", callback=validate_sumo_secrets)
def run_app_tests_v2(includetests, excludetests, appfolder, deployment='', access_id='', access_key=''):
    test_names = get_test_names(includetests, excludetests,True)
    manifestfile = os.path.join(get_default_apps_directory(),appfolder,"manifest.yaml")
    sourceappfile = os.path.join(get_default_apps_directory(),appfolder,"resources","dashboards.tf")
    has_failures, _ = run_test(manifestfile, sourceappfile,
                               deployment, access_id,
                               access_key, test_names, True)

    exit_status = 1 if has_failures else 0
    sys.exit(exit_status)
