import sys

from sumoapputils.appdev import utils

this = sys.modules[__name__]

this.input_deployments: list = None
this.all_authorized_deployments: list = None
this.deployments: list = None
this.app_name: str = None
this.app_uuid: str = None
this.app_version: str = None
this.is_private = None
this.uuid_by_dep: dict = {}


def initialize(input_deps=None, name=None, uuid=None, version=None, private=False):
    this.app_name = name
    this.app_uuid = uuid
    this.app_version = version
    this.is_private = private

    utils.info(f"App name: {this.app_name}, App uuid: {this.app_uuid}")

    this.input_deployments = [input_deps] if isinstance(input_deps, str) else input_deps
    this.all_authorized_deployments = utils.get_all_authorized_deployments()
    if not this.input_deployments:
        this.input_deployments = this.all_authorized_deployments
    this.deployments = utils.filter_deployments(this.input_deployments)

    excluded = [d for d in this.input_deployments if d not in this.deployments]
    utils.debug(f"Limiting command to deployments: {this.deployments}")

    if len(excluded) > 0:
        utils.warn(f"Excluding deployments {excluded} since no access keys was found for them!")

    if not this.deployments:
        utils.error("No authorized deployment. Exiting!")
        sys.exit(1)
