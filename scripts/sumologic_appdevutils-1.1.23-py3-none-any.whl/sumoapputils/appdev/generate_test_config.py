from collections import OrderedDict
import json
import os

from sumoapputils.common.testapp import TestApp
from sumoapputils.common.utils import get_content_dirpath, ALL_V1_APPS_FILENAME, EXCLUDED_APP_PREFIXES, load_tf_to_json, load_yaml_to_json, account_type_mapping
from sumoappclient.common.utils import get_normalized_path


def get_json_file():
    manifestjsonfile = appjsonfile = None
    for fname in os.listdir(os.getcwd()):
        if fname.endswith("manifest.json"):
            if not manifestjsonfile:
                manifestjsonfile = fname
            else:
                raise Exception("Multiple manifest file")
        elif fname.endswith(".json"):
            if not appjsonfile:
                appjsonfile = fname
            else:
                raise Exception("Multiple app json file")

    return manifestjsonfile, appjsonfile


def get_content_count(folder, stats):
    for dash in folder["children"]:
        if dash["type"] not in stats["contentType"]:
            continue
        stats["contentType"][dash["type"]] += 1
        if dash["type"] in ("DashboardSyncDefinition", "MewboardSyncDefinition", "Dashboard",
                            "DashboardV2SyncDefinition"):
            panels = dash["rootPanel"]["panels"] if dash.get("rootPanel") else dash.get("panels", [])
            panelData = [{"name": panel["title"] if TestApp.is_mew_board(dash) else panel["name"],
                          "verifyData": False} for panel in panels]
            num_panels = len(panels)
            linked_dashboard = [panel["title"] for panel in dash["panels"] if len(panel.get("linkedDashboards", [])) > 0]
            if linked_dashboard:
                stats["linking"][dash["name"]] = linked_dashboard
            dashboardData = {"name": dash["name"], "panelData": panelData, "panelsCount": num_panels}
            stats["contentType"]["TotalPanel"] += num_panels  # includes title/text panels
            if not TestApp.is_mew_board(dash):
                for panel in panels:
                    propjson = json.loads(panel["properties"])
                    target = propjson.get("common", {}).get("configuration", {}).get("drilldown", {}).get(
                        "fallback", {}).get("target", {})
                    if (target.get("id", None)):
                        stats["linking"][panel["name"]] = [dash["name"], target["name"]]
            stats["dashboardData"].append(dashboardData)
        elif dash["type"] in ("Folder", "FolderSyncDefinition"):
            print("Found folder inside folder", dash["name"])
            get_content_count(dash, stats)


def get_v2_app_content_count(dashboardjson, stats):
    for _, dashboard_data in dashboardjson["resource"]["sumologic_dashboard"].items():
        panels = dashboard_data.get("panel", [])
        if isinstance(panels, dict):
            panels=[panels]
        panelcount = len(panels)
        dashboard_entry = {"name": dashboard_data.get("title"), "panelData": [], "panelsCount": panelcount}
        linked_dashboard = []
        for panel in panels:
            _, panel_data = panel.popitem()
            panel_entry = {"name": panel_data.get("title", ""), "verifyData": False}
            dashboard_entry["panelData"].append(panel_entry)
            if panel_data.get("linked_dashboard"):
                linked_dashboard.append(panel_data.get("title", ""))
        if len(linked_dashboard)>0:
            stats["linking"][dashboard_data.get("title")]=linked_dashboard
        stats["contentType"]["TotalPanel"] += panelcount

        stats["dashboardData"].append(dashboard_entry)


def get_v2_app_config(screenshotfolder, logsearchfile, folderfile, dashboardfile, manifestfile, configfile, withpaneldata=False):
    stats = {"dashboardData": []}
    dashboardjson = load_tf_to_json(dashboardfile)
    manifestjson = load_yaml_to_json(manifestfile)
    folderjson = load_tf_to_json(folderfile)
    stats["contentType"] = {"TotalPanel": 0,
                            "TotalDashboards": len(dashboardjson.get("resource", {}).get("sumologic_dashboard", [])),
                            "Search": 0,
                            "Folder": len(folderjson.get("resource", {}).get("sumologic_folder", [])) - 1}
    if os.path.isfile(logsearchfile):
        logsearchjson = load_tf_to_json(logsearchfile)
        stats["contentType"]["Search"] = len(logsearchjson.get("resource", {}).get("sumologic_log_search", []))
    if not os.path.isfile(configfile):
        stats["log_sources"]=0
        stats["metric_sources"]=0
    else:
        configjson = load_yaml_to_json(configfile)
        stats["log_sources"] = len([param for param in configjson.get("parameters", []) if "Log" in param["label"]])
        stats["metric_sources"] = len([param for param in configjson.get("parameters", []) if "Metric" in param["label"]])
    stats['appname'] = manifestjson["name"]
    stats['categories'] = sorted(manifestjson['attributes']['category'])
    stats["linking"] = {}
    stats["accountTypes"]= sorted(manifestjson.get("accountTypes", ["Free", "Trial", "Essentials", "EnterpriseOps", "EnterpriseSec", "EnterpriseSuite"]))
    stats["hasMultipleSources"] = (stats["log_sources"] + stats["metric_sources"]) > 1
    stats['screenshots'] = len([f for f in os.listdir(screenshotfolder) if os.path.isfile(os.path.join(screenshotfolder, f)) and f.lower().endswith('.png')])
    get_v2_app_content_count(dashboardjson,stats)
    stats["dashboardData"] = sorted(stats["dashboardData"], key=lambda x: x["name"].lower())
    for app in stats.get("dashboardData", []):
        app["panelData"] = sorted(app.get("panelData", []), key=lambda x: x.get("name", "").lower())
    # stats=sort_report_data(stats)

    stats = OrderedDict({key: value for key, value in sorted(stats.items())})

    # check if version is 1.0.0 for migrated apps
    version = manifestjson.get("version")
    if version != '1.0.0':
        print(stats['appname'], " : Current version: ", version)
    return stats


def get_app_config(manifestfile, appfile, withpaneldata=False):
    # Todo will change for mewboards and v2 json
    stats = {"dashboardData": []}
    appjson = json.load(open(appfile))
    manifestjson = json.load(open(manifestfile))
    stats['appname'] = manifestjson["name"]
    stats['categories'] = sorted(manifestjson['categories'])
    stats["log_sources"] = len([param for param in manifestjson.get("parameters", []) if param["dataSourceType"] == "LOG"])
    stats["metric_sources"] = len([param for param in manifestjson.get("parameters", []) if param["dataSourceType"] == "METRICS"])
    stats['screenshots'] = len(manifestjson['screenshotURLs'])
    stats["hasMultipleSources"] = (stats["log_sources"] + stats["metric_sources"]) > 1
    stats["linking"] = {}
    stats["contentType"] = {"TotalPanel": 0,
                            "TotalDashboards": 0,
                            "Search": 0,
                            "Folder": 0,
                            "MewboardSyncDefinition": 0,
                            "DashboardV2SyncDefinition": 0,
                            "Dashboard": 0,
                            "FolderSyncDefinition": 0,
                            "DashboardSyncDefinition": 0,
                            "SavedSearchWithScheduleSyncDefinition": 0}
    get_content_count(appjson, stats)

    if not withpaneldata and "dashboardData" in stats:
        stats.pop("dashboardData")

    accountTypes= manifestjson.get("accountTypes", ["free", "trial", "essentials", "enterprise_ops", "enterprise_sec", "enterprise_suite"])
    stats["accountTypes"]=sorted([account_type_mapping.get(account_type.lower(), account_type.upper()) for account_type in accountTypes])

    stats["contentType"]["Search"] += stats["contentType"].pop(
        "SavedSearchWithScheduleSyncDefinition")  # saved search new
    stats["contentType"]["TotalDashboards"] += stats["contentType"].pop("DashboardSyncDefinition")  # classic new
    stats["contentType"]["TotalDashboards"] += stats["contentType"].pop("Dashboard")  # mewboard old
    stats["contentType"]["TotalDashboards"] += stats["contentType"].pop("MewboardSyncDefinition")  # mewboard new
    stats["contentType"]["TotalDashboards"] += stats["contentType"].pop("DashboardV2SyncDefinition")  # mewboard new
    stats["contentType"]["Folder"] += stats["contentType"].pop("FolderSyncDefinition")  # folder new
    stats["dashboardData"] = sorted(stats["dashboardData"], key=lambda x: x["name"].lower())
    for app in stats.get("dashboardData", []):
        app["panelData"] = sorted(app.get("panelData", []), key=lambda x: x.get("name", "").lower())
    # stats=sort_report_data(stats)
    stats = OrderedDict({key: value for key, value in sorted(stats.items())})
    return stats


def generate_partner_app_config(unique_file_suffix):
    manifestfile, appfile = get_json_file()
    data = get_app_config(manifestfile, appfile)

    app_config_file = "app-config-%s.json" % unique_file_suffix
    changed_app_file = "changed-apps.txt"

    # file for running unit tests
    with open(changed_app_file, "w") as cfg:
        line = "%s:%s" % (appfile, manifestfile)
        print(line)
        cfg.write("%s\n" % line)

    # file for app metadata for running API & UI tests
    with open(app_config_file, "w") as cfg:
        json_data = json.dumps([data], indent=4)
        print(json_data)
        cfg.write("%s\n" % json_data)


def generate_all_partner_app_config(unique_file_suffix, changed_files_path):
    with open(changed_files_path, "r") as fp:
        changed_app_files = fp.readlines()
        filtered_app_files = set()

        for filepath in changed_app_files:
            filepath = filepath.strip()
            if filepath and filepath.endswith(".json"):
                filename = os.path.basename(filepath)
                if filename.endswith(".manifest.json"):
                    appfile = get_normalized_path(filepath.replace(".manifest", ""))
                    manifestfile = get_normalized_path(filepath)
                else:
                    appfile = get_normalized_path(filepath)
                    manifestfile = get_normalized_path(filepath.replace(".json", ".manifest.json"))
                if os.path.isfile(appfile) and os.path.isfile(manifestfile):
                    filtered_app_files.add("%s:%s" % (appfile, manifestfile))
                else:
                    print("Skipping line %s appfile: %s manifestfile: %s doesn't exists" % (
                        filepath, appfile, manifestfile))
            else:
                print("Skipping line  %s" % filepath)

    app_config_filepath = "app-config-%s.json" % unique_file_suffix
    changed_app_filepath = "changed-apps.txt"
    if filtered_app_files:
        all_data = []
        with open(changed_app_filepath, "w") as cfg:
            for line in filtered_app_files:
                appfile, manifestfile = line.split(":")
                all_data.append(get_app_config(manifestfile, appfile))
                cfg.write("%s\n" % line)

        with open(app_config_filepath, "w") as cfg:
            json_data = json.dumps(all_data, indent=4)
            print(json_data)
            cfg.write("%s\n" % json_data)
        print("generated files %s %s" % (changed_app_filepath, app_config_filepath))
    else:
        # generating empty files
        open(changed_app_filepath, 'a').close()
        open(app_config_filepath, 'a').close()
        print("No app file changes found")


def filter_app_files(changed_app_files, all_app_config):
    # this script generates array of apps which needs to be tested

    filtered_full_app_list = set()

    file_mapper = {}
    with open(all_app_config) as fp:
        app_files = fp.readlines()

    for line in app_files:
        line = line.strip()
        # filters apps which are commented + PS apps
        if line and not line.startswith(EXCLUDED_APP_PREFIXES):
            appfile, manifestfile = line.split(":")
            file_mapper[appfile] = line
            file_mapper[manifestfile] = line
        else:
            print("Skipping line from full_app_list.txt: %s" % line)

    for filepath in changed_app_files:
        filepath = filepath.replace("src/main/app-package/", "").strip()
        # filters files using full_app_list.txt to filter deprecated json files
        if filepath in file_mapper:
            filtered_full_app_list.add(file_mapper[filepath])
        else:
            print("Changed File: %s Does not exist in full_app_list.txt: %s" % (filepath, filepath in file_mapper))

    return list(filtered_full_app_list)


def generate_appdev_app_config(unique_file_suffix, changed_files_path=None):
    content_dir_path = get_content_dirpath()
    if changed_files_path is not None:
        with open(changed_files_path, "r") as fp:
            changed_app_files = fp.readlines()
        filtered_app_files = filter_app_files(changed_app_files, os.path.join(get_content_dirpath(),
                                                                              "bin", ALL_V1_APPS_FILENAME))
    else:
        # if not filepath is specified config is generated for all apps
        all_app_config = os.path.join(content_dir_path,
                                      "bin", ALL_V1_APPS_FILENAME)
        with open(all_app_config, "r") as all_apps:
            app_list = all_apps.readlines()

        filtered_app_files = filter(lambda x: x and x.strip() and not (
            x.startswith(EXCLUDED_APP_PREFIXES)), app_list)
        for line in app_list:
            if line.startswith(EXCLUDED_APP_PREFIXES):
                print("Skipping line from full_app_list.txt: %s" % line)

        filtered_app_files = map(lambda x: x.strip(), filtered_app_files)

    changed_apps_file = "changed-apps-%s.txt" % unique_file_suffix
    changed_app_filepath = os.path.join(content_dir_path, "test", changed_apps_file)
    app_config_file = "app-config-%s.json" % unique_file_suffix
    app_config_filepath = os.path.join(content_dir_path, "test", app_config_file)
    all_data = []
    with open(changed_app_filepath, "w") as cfg:
        for line in filtered_app_files:
            appfile, manifestfile = line.split(":")
            appfile = os.path.join(content_dir_path, "src", "main", "app-package", appfile)
            manifestfile = os.path.join(content_dir_path, "src", "main", "app-package", manifestfile)
            all_data.append(get_app_config(manifestfile, appfile))
            cfg.write("%s\n" % line)

    with open(app_config_filepath, "w") as cfg:
        json_data = json.dumps(all_data, indent=4)
        print(json_data)
        cfg.write("%s\n" % json_data)
    print("generated files %s %s" % (changed_app_filepath, app_config_filepath))
