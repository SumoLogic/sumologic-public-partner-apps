import os
import re
import six
import click
from sumoappclient.common.logger import get_logger
from sumoapputils.common.utils import get_sanitized_app_name
from sumoapputils.appdev import utils
from sumoappclient.common.utils import get_normalized_path

from sumoapputils.common.appmanifest import APP_CATEGORIES, APP_CATEGORY_NUM_CHOICES, AppManifestV2SchemaV2AppOnly, AppManifestV2SchemaV2DocOnly, validate_url

logger = get_logger(__name__, LOG_FILEPATH="/tmp/sumoapptestutils.log", LOG_LEVEL=os.environ.get("LOG_LEVEL", "INFO"))

if six.PY2:
    input = raw_input


@click.group()
def createappcmd():
    pass


def validate_folder(ctx, param, value):
    app_folder = os.path.basename(get_normalized_path(value))
    if re.match(r'^[a-zA-Z0-9_]+$', app_folder):
        return value
    else:
        raise click.BadOptionUsage(option_name=param.name, message="Folder name: %s should contain only upper and lowercase letters, numbers, and underscores." % value, ctx=ctx)


def get_screenshots_directory(target_directory):
    return os.path.join(target_directory, "assets", "images", "preview")


def create_app_directory(target_directory, appname):
    if not target_directory:
        target_directory = os.path.join(utils.get_default_apps_directory(), get_sanitized_app_name(appname))
    app_folder = get_normalized_path(target_directory)
    if not os.path.isdir(app_folder):
        utils.info("Creating app directory: %s" % app_folder)
        os.mkdir(app_folder)
        return app_folder
    else:
        raise Exception(f"app folder: {app_folder} already exists")


def get_categories(value):
    values = [c.strip() for c in value.split(',')]
    num_values = map(lambda nv: int(nv), values)
    categories = list(map(lambda idx: APP_CATEGORIES[idx], num_values))
    return categories


def validate_category(ctx, param, value):
    try:
        get_categories(value)
        return value
    except IndexError:
        # If the index does not exist.
        click.echo('Please select a valid index.')

    except (TypeError, ValueError):
        # If the value is of a different type, for example, String.
        click.echo('Please select a valid value from the choices. \n\n{}\n\n'.format(APP_CATEGORY_NUM_CHOICES))

    # Prompt the user for an input.
    value = click.prompt(param.prompt)
    return validate_category(ctx, param, value)


@createappcmd.command(help="For generating skeleton for v2 apps")
@click.option('-n', '--name', 'appname', required=True, help='Sets app name')
@click.option('-t', '--target-directory', type=click.Path(dir_okay=True, file_okay=False), default=None, required=False, help='Sets dir name inside which skeleton will be created')
@click.option('-d', '--doc-only', is_flag=False, help="Setting this flag generates skeleton for doc only app")
@click.option('-ct', '--collection', default="Hosted", type=click.Choice(["Hosted", "OpenTelemetry", "Installed"]), required=True, help='Set collection attribute')
@click.option('-c', '--categories', metavar='<category_id>', is_flag=False, required=True, prompt='\nPlease enter the comma separated numerical value corresponding to the app category name.\n\n{}\n\n'.format(APP_CATEGORY_NUM_CHOICES), type=click.STRING, help='Set app category', callback=validate_category)
@click.option('-a', '--author', help="Set author of the app", default="Sumo Logic")
@click.option('-u', '--docurl', required=True, prompt='\nPlease enter the documentation page url.', help="Set doc url of the app", callback=validate_url)
@click.option('-s', '--supporturl', default="https://support.sumologic.com/", help="Set support url of the app Ex https://support.sumologic.com/", callback=validate_url)
@click.option('-hu', '--homeurl', default="https://www.sumologic.com/", help="Set home url of the app Ex https://www.sumologic.com/", callback=validate_url)
def create_v2_app(appname, target_directory, doc_only, collection, categories, author, docurl, supporturl, homeurl):
    categories = get_categories(categories)
    manifestClass = AppManifestV2SchemaV2DocOnly if doc_only else AppManifestV2SchemaV2AppOnly
    app_folder = create_app_directory(target_directory, appname)
    manifestObj = manifestClass()
    manifest_filepath = manifestObj.create_manifest(appname, app_folder, author, categories, docurl, supporturl, homeurl)
    changelog_filepath = manifestObj.create_changelog(appname, app_folder)
    readme_filepath = manifestObj.create_readme(appname, app_folder, f"The {appname} is a unified logs and metrics app.")
    assets_folderpath = manifestObj.create_assets(app_folder)
    utils.info(f"Successfully created following: \n{manifest_filepath}\n{changelog_filepath}\n{readme_filepath}\n{assets_folderpath}")

    if collection == "OpenTelemetry":
        # Todo in future if other collection mechanisms are supported change this condition
        manifestObj.create_collection(app_folder)
