import json
import os
from columnar import columnar
from datetime import datetime
from sumoapputils.appdev.appreviewer.basereview import BaseReviewOutput
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font

class ConsoleOutput(BaseReviewOutput):

    def __init__(self, appfolder, **kwargs) -> None:
        super().__init__()

    def generate_output(self, headers: list[str], rows: list[list]):
        # table = columnar(rows, headers, no_borders=True, max_column_width=None)
        # print(table)
        for row in rows:
            obj = dict(zip(headers, row))
            print(json.dumps(obj, indent=True))


class ExcelOutput(BaseReviewOutput):
    # Todo Fix col width and wrap text

    def __init__(self, appfolder, **kwargs) -> None:
        super().__init__()
        self.filepath = kwargs.get("filepath")
        if not self.filepath:
            self.filepath = appfolder
        current_date = datetime.now().strftime("%d-%m-%y-%H-%M-%S")
        self.sheetpath = os.path.join(self.filepath, f"appreviewoutput-{current_date}.xlsx")
        self.review_generation_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.mandatory_columns = ["Status","Review Date","Accept/Reject/No Change Needed"]

    def generate_output(self, headers: list[str], rows: list[list], sheet_name: str):

        headers.extend(self.mandatory_columns)

        rows = [row+["",self.review_generation_date,""] for row in rows]
        if os.path.isfile(self.sheetpath):
            workbook = load_workbook(filename=self.sheetpath)
        else:
            workbook = Workbook()
            print(f"Created workbook: {self.sheetpath}")

        if sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
        else:
            sheet = workbook.create_sheet(sheet_name, index=0)

        workbook.active = workbook[sheet_name]
        # if sheet.max_row == 1 and sheet.max_column == 1 and sheet['A1'].value == None:
        bold_font = Font(bold=True, italic=True)
        sheet.append(headers)
        sheet.freeze_panes = "A2"
        for cell in sheet["1:1"]:
            cell.font = bold_font

        for row in rows:
            sheet.append(row)

        workbook.save(self.sheetpath)
        print(f"Created sheet: {sheet_name} in workbook")
