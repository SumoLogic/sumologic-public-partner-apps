from abc import abstractmethod, ABCMeta
import os
from typing import Union
import six
from bs4 import BeautifulSoup
from sumoapputils.appdev.appreviewer import prompt_templates
from sumoapputils.common.testapp import TestTfDashboards
from sumoapputils.common.utils import load_tf_to_json, load_yaml_to_json
from importlib import import_module

@six.add_metaclass(ABCMeta)
class BaseModelBackend(object):

    # @property
    # @abstractmethod
    # def model_id(self):
    #     pass

    # @property
    # @abstractmethod
    # def model_params(self):
    #     pass

    @abstractmethod
    def set_model_params(self, **params) -> dict:
        '''
        model_params:
        '''
        raise NotImplementedError()

    @abstractmethod
    def get_model(self):
        '''
        model_client:
        '''
        raise NotImplementedError()

    @abstractmethod
    def invoke_model(self):
        '''
        headers:
        rows:
        '''
        raise NotImplementedError()

    @classmethod
    def get_prompts(self, template_name, **kwargs):
        template_path = os.path.join(prompt_templates.__path__[0], template_name)
        module_name = prompt_templates.__package__+f".{template_name.split(".")[0]}"
        if os.path.isfile(template_path):
            template_obj = import_module(module_name)
            human_prompt = getattr(template_obj, "prompt")
            if not human_prompt:
                raise ValueError("prompt variable should be defined in template file.")
            system_prompt = getattr(template_obj, "system_prompt", None)
        else:
            raise ValueError(f"Prompt Template file: {template_path} does not exists.")
        return human_prompt, system_prompt

@six.add_metaclass(ABCMeta)
class BaseReviewOutput(object):

    @abstractmethod
    def generate_output(self, headers: list[str], rows: list[list]):
        '''
        headers:
        rows:
        '''

        raise NotImplementedError()


@six.add_metaclass(ABCMeta)
class BaseReviewGenerator(object):

    # @property
    # @abstractmethod
    # def model_backend(self):
    #     pass

    # @property
    # @abstractmethod
    # def model_output(self):
    #     pass

    # @property
    # @abstractmethod
    # def appfolder(self):
    #     pass

    @abstractmethod
    def get_reviews(self) -> list[list]:
        '''
        headers:
        rows:
        '''
        raise NotImplementedError()

    @abstractmethod
    def generate_review(self):
        raise NotImplementedError()


    @abstractmethod
    def get_prompt_params(self):
        raise NotImplementedError()

    def set_app_artifacts(self):
        manifestFile = os.path.join(self.appfolder, "manifest.yaml")
        self.manifestjson = load_yaml_to_json(manifestFile)

        monitorFile = os.path.join(self.appfolder, "resources", "monitors.tf")
        monitorsjson = load_tf_to_json(monitorFile) if os.path.exists(monitorFile) else {}
        self.monitors = TestTfDashboards.get_monitor_content(monitorsjson)
        self.monitor_log_queries, self.monitor_metric_queries = TestTfDashboards.get_monitor_queries(self.monitors)

        logSearchFile = os.path.join(self.appfolder, "resources", "logSearches.tf")
        logsearchjson = load_tf_to_json(logSearchFile) if os.path.exists(logSearchFile) else {}
        dashboardFile = os.path.join(self.appfolder, "resources", "dashboards.tf")
        dashboardjson = load_tf_to_json(dashboardFile)
        self.dashboards, self.searches = TestTfDashboards.get_content(dashboardjson, logsearchjson)
        self.saved_search_queries = TestTfDashboards.get_saved_search_queries(self.searches)

        # single panel case
        for dash in self.dashboards:
            panels = dash["panel"]
            dash["panel"] = [panels] if isinstance(panels, dict) else panels

        self.log_queries, self.metric_queries = TestTfDashboards.extract_queries(self.dashboards)

    @classmethod
    def extract_by_tag(self, response: str, tag: str, extract_all=False) -> str | list[str] | None:
        soup = BeautifulSoup(response)
        results = soup.find_all(tag)
        if not results:
            return

        texts = [res.get_text() for res in results]
        if extract_all:
            return texts
        return texts[-1]
