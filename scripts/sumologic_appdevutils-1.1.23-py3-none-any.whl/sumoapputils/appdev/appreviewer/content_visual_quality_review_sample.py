import base64
from datetime import datetime
from mimetypes import guess_type
from sumoapputils.appdev.appreviewer.basereview import BaseReviewGenerator
from sumoapputils.appdev.appreviewer.bedrockbackend import BedrockBackend
from sumoapputils.appdev.appreviewer.outputbackend import ConsoleOutput


class ContentImageQualityReviewGenerator(BaseReviewGenerator):
    template_name = "visual_quality_sonnet_v1.py"
    headers = ["DashboardName",	"PanelName", "ExistingQuery", "OptimizedQuery",	"ReviewComments", "Status", "ReviewDate", "Accept/Reject/NoChangeNeeded","Priority"]

    def __init__(self, appfolder, **kwargs):

        self.model_backend = BedrockBackend(appfolder, self.template_name, **kwargs)
        self.appfolder = appfolder
        self.set_app_artifacts()

    # Function to encode a local image into data URL
    def local_image_to_data_url(self, image_path):
        mime_type, _ = guess_type(image_path)
        # Default to png
        if mime_type is None:
            mime_type = 'image/png'

        # Read and encode the image file
        with open(image_path, "rb") as image_file:
            base64_encoded_data = base64.b64encode(image_file.read()).decode('utf-8')

        # Construct the data URL
        return f"data:{mime_type};base64,{base64_encoded_data}"

    def get_prompt_params(self) -> dict:

        return {
            "encoded_image_url": self.local_image_to_data_url("/Users/hpal/Downloads/MySQL - Performance and Resource Metrics.png")
        }

    def get_reviews(self, response) -> list[list]:
        print(response.content)
        # optimized_query = self.extract_by_tag(response.content, "query")
        return [[
            "Dashboard A",
            "Panel A",
            "sumologic_query",
            "optimized_query",
            "",
            "",
            datetime.now().strftime("%d-%m-%y"),
            "",
            "P0"
        ]]

    def generate_review(self):
        prompt_params = self.get_prompt_params() # list of params
        response = self.model_backend.invoke_model(prompt_params)
        rows = self.get_reviews(response) # list of reviews
        return self.headers, rows





