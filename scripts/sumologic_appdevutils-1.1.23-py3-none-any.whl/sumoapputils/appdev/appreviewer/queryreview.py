
from datetime import datetime
from typing import Union
from sumoapputils.appdev.appreviewer.basereview import BaseReviewGenerator
from sumoapputils.appdev.appreviewer.bedrockbackend import BedrockBackend
from sumoapputils.appdev.appreviewer.outputbackend import ConsoleOutput
from langchain_core.messages import SystemMessage
from langchain_core.prompts import HumanMessagePromptTemplate


class QueryReviewGenerator(BaseReviewGenerator):
    template_name = "optimize_query_anthropic_v1.py"
    headers = ["DashboardName",	"PanelName", "ExistingQuery", "OptimizedQuery",	"ReviewComments", "Status", "ReviewDate", "Accept/Reject/NoChangeNeeded","Priority"]

    def __init__(self, appfolder, **kwargs):

        self.model_backend = BedrockBackend(appfolder, self.template_name, **kwargs)
        self.appfolder = appfolder
        self.set_app_artifacts()

    def get_prompt_params(self) -> dict:
        sumologic_query = '''\
tenant_name=* location=* subscription_id=* resource_group=* provider_name="Microsoft.Storage" resource_type="storageAccounts" resource_name=* *STORAGE*
| json "callerIpAddress" as callerIpAddress
| where !isblank(callerIpAddress) and _raw matches "*fail*"
| split callerIpAddress delim=':' extract 1 as src_ip, 2 as port
| lookup latitude, longitude from geo://location on ip = src_ip
| count as ip_count by src_ip
| where !isNull(latitude)
| sum(ip_count) as count by latitude, longitude
'''
        return {
            "sumologic_query": sumologic_query
        }

    def get_reviews(self, response) -> list[list]:
        optimized_query = self.extract_by_tag(response.content, "query")
        return [[
            "Dashboard A",
            "Panel A",
            self.get_prompt_params()["sumologic_query"],
            optimized_query,
            "",
            "",
            datetime.now().strftime("%d-%m-%y"),
            "",
            "P0"
        ]]

    def generate_review(self):
        prompt_params = self.get_prompt_params() # list of params
        response = self.model_backend.invoke_model(prompt_params)
        rows = self.get_reviews(response) # list of reviews
        return self.headers, rows


