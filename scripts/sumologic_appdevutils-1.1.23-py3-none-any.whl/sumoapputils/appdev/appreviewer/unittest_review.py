from unittest import TestSuite
from sumoapputils.appdev.appreviewer.basereview import BaseReviewGenerator
from sumoapputils.common.basetestrunner import CustomTextTestRunner
import os
import json
from sumoapputils.common.testapp import TestTfDashboards, TestApp


class UnitTestReviewGenerator(TestTfDashboards, BaseReviewGenerator):
    headers = ["Location", "TestName", "Review", "Priority"]

    def __init__(self, appfolder):
        self.appfolder = appfolder
        manifestfile = os.path.join(appfolder, "manifest.yaml")
        sourceappfile = os.path.join(appfolder, "resources", "dashboards.tf")
        super().__init__(manifestfile, sourceappfile, deployment_name="", access_id="",access_key="", isTfApp=True,)
        self.rows = []

    def isTestMethod(self, attr_name, test_class=TestTfDashboards, prefix="test"):
        return attr_name.startswith(prefix) and \
            hasattr(getattr(test_class, attr_name), '__call__')


    def assertTrue(self, expr, msg=None, warning=False):
        try:
            super(TestApp, self).assertTrue(expr, msg)
        except AssertionError as e:
            test_function_name = self.get_test_function_name()
            if warning or (self.appname in self.test_config_map and self.test_config_map[self.appname].get(
                    "skip_errors") and test_function_name in self.test_config_map[self.appname]["skip_errors"]):
                self.rows.append([self.appname, test_function_name, msg, "WARNING"])
            else:
                self.rows.append([self.appname, test_function_name, msg, "ERROR"])

    def assertFalse(self, expr, msg=None, warning=False):
        try:
            super(TestApp, self).assertFalse(expr, msg)
        except AssertionError as e:
            test_function_name = self.get_test_function_name()
            if warning or (self.appname in self.test_config_map and self.test_config_map[self.appname].get(
                    "skip_errors") and test_function_name in self.test_config_map[self.appname]["skip_errors"]):
                self.rows.append([self.appname, test_function_name, msg, "WARNING"])
            else:
                self.rows.append([self.appname, test_function_name, msg, "ERROR"])


    def generate_review(self):
        exclude_tests = ["test_tfApp_installable","test_is_deployable","test_sumo_query","test_threatintel_query","test_update_v2_app", "test_terraform_validate"]
        test_func_names = filter(self.isTestMethod, dir(TestTfDashboards))
        non_deploy_test_func_names = list(filter(lambda x: x not in exclude_tests, test_func_names))
        print(f"Running {len(non_deploy_test_func_names)} AppStandardsTests")
        for test_func in non_deploy_test_func_names:
            getattr(self, test_func)()
        return self.headers, self.rows

    def get_prompt_params(self):
        pass

    def get_reviews(self):
        pass
