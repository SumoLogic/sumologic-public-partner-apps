from unittest import TestSuite
from sumoapputils.appdev.appreviewer.basereview import BaseReviewGenerator
from sumoapputils.common.basetestrunner import CustomTextTestRunner
import os
from sumoapputils.common.testapp import TestTfDashboards, skip_test_wrapper


class UnitTestReviewGenerator(TestTfDashboards, BaseReviewGenerator):

    @skip_test_wrapper
    def test_background_color(self):
        print("Inside test background")
        for dash in self.dashboards:
            if isinstance(dash, dict) and 'title' in dash:
                print("Dashboard: %s " % dash["title"])
                panels = dash["panel"]
                allPanels = [panels] if isinstance(panels, dict) else panels
                for panel in allPanels:
                    panel_resource = panel["sumo_search_panel"]
                    print("Panel: %s" % (panel_resource["title"]))


if __name__ == "__main__":

    apps_dir_path = "/Users/hpal/git/apps"
    relative_folder_path = "src/Apache"
    suite = TestSuite()
    manifestfile = os.path.join(apps_dir_path, relative_folder_path, "manifest.yaml")
    sourceappfile = os.path.join(apps_dir_path, relative_folder_path, "resources", "dashboards.tf")
    suite.addTest(UnitTestReviewGenerator(manifestfile, sourceappfile, "", "","", "True", "test_background_color"))
    result = CustomTextTestRunner().run(suite)
    manifestfile = os.path.join(apps_dir_path, relative_folder_path, "manifest.yaml")
    sourceappfile = os.path.join(apps_dir_path, relative_folder_path, "resources", "dashboards.tf")
