import base64
from bdb import set_trace
from mimetypes import guess_type
import json
import os
from sumoapputils.appdev.appreviewer.basereview import BaseReviewGenerator
from sumoapputils.appdev.appreviewer.bedrockbackend import BedrockBackend
from sumoapputils.appdev.appreviewer.outputbackend import ConsoleOutput
        
class UsecaseReviewGenerator(BaseReviewGenerator):
    template_name = "usecase_anthropic_v1.py"
    headers = ["DashboardName",	"PanelName", "isExistingPanel", "Recommendation"]

    def __init__(self, appfolder, **kwargs):

        self.model_backend = BedrockBackend(appfolder, self.template_name, **kwargs)
        self.model_backend.set_model_params(max_tokens=4000)
        self.appfolder = appfolder
        self.set_app_artifacts()

    # Function to encode a local image into data URL
    def local_image_to_data_url(self, image_path):
        mime_type, _ = guess_type(image_path)
        # Default to png
        if mime_type is None:
            mime_type = 'image/png'

        # Read and encode the image file
        with open(image_path, "rb") as image_file:
            base64_encoded_data = base64.b64encode(image_file.read()).decode('utf-8')

        # Construct the data URL
        return f"data:{mime_type};base64,{base64_encoded_data}"

    def get_prompt_params(self,dashboardname, screenshot_file_path) -> dict:
        return {
            "dashboard_name": dashboardname,
            "encoded_image_url": self.local_image_to_data_url(screenshot_file_path)
        }

    def get_reviews(self,response) -> list[list]:
        response_obj = self.extract_by_tag(response.content, "json")
        recommendations_data =json.loads(response_obj)
        all_recommendations = []
        for recommendation in recommendations_data:
            dashboard_name = recommendation.get("dashboard_name", "")
            panel_name = recommendation.get("panel_name", "")
            isExistingPanel = recommendation.get("isExistingPanel", False)
            feedback = recommendation.get("feedback", "")
            recommendation_list = [dashboard_name, panel_name, isExistingPanel, feedback]
            all_recommendations.append(recommendation_list)
        return all_recommendations


    def generate_review(self):
        screenshot_location = os.path.join(os.environ['SUMO_APPS_V2_REPO_PATH'], self.appfolder)
        app_media= self.manifestjson.get("appMedia",[])
        output_data = []
        for app_artifact in app_media:
            dashboardname= app_artifact["title"]
            screenshot_file_path= screenshot_location + app_artifact["location"][1:]
            prompt_params = self.get_prompt_params(dashboardname,screenshot_file_path)
            response = self.model_backend.invoke_model(prompt_params)
            rows = self.get_reviews(response)
            output_data.extend(rows)
        return self.headers,output_data