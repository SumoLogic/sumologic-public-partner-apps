from sumoapputils.common.utils import run_cmd
from sumoapputils.appdev import utils
from sumoapputils.appdev.actions.keepachangelog_handler import KeepachangelogHandler


class UpdateChangelog:
    def execute(self, apps: list, target_branch: str):

        update_to_all_apps = False
        current_branch = run_cmd("git rev-parse --abbrev-ref HEAD")[1].decode("utf-8").strip()
        changes_by_change_type = {}
        for app in apps:
            changelog_handler = KeepachangelogHandler(app)

            if not update_to_all_apps:
                print(f"Changelog for {app['name']} >")
                cmd_code, cmd_response = run_cmd(
                    f"git log --pretty=oneline {current_branch}...{target_branch} --all -- src/{app['relativeFolderPath']}"
                )

                if cmd_code != 0:
                    utils.error(
                        f"There was an error fetching commits for app {app['name']} with source branch {current_branch} and target branch {target_branch}"
                    )
                    break
                if not cmd_response:
                    utils.warn(f"No commits found for app {app['name']} with source branch {current_branch} and target branch {target_branch}")
                    continue

                commits = {str(i + 1): parts[1] for i, line in enumerate(cmd_response.decode("utf-8").strip().split("\n")) if (parts := line.split(None, 1))[1]}

                changelog_handler.show_changelog()

                print(f"\n\nNew commits with difference from {current_branch} to {target_branch} for {app['name']}:\n\n")
                for key, value in commits.items():
                    print(f"{key} - {value}")

                changes_by_change_type = self.input_commit_choices(commits)
                changelog_handler.update_changelog(
                    changelog_handler.ChangeType.ADDED, changes_by_change_type[changelog_handler.ChangeType.ADDED], version="unreleased", write=False
                )
                changelog_handler.update_changelog(
                    changelog_handler.ChangeType.FIXED, changes_by_change_type[changelog_handler.ChangeType.FIXED],
                    version="unreleased", write=True
                )

                update_to_all_apps = input("Do you want to add the same changelog for the rest of the apps? (y/n) > ").lower() == 'y'
            else:
                utils.warn(f"Updating same changelog for all remaining apps...")
                changelog_handler.update_changelog(
                    changelog_handler.ChangeType.ADDED, changes_by_change_type[changelog_handler.ChangeType.ADDED],
                    version="unreleased", write=False
                )
                changelog_handler.update_changelog(
                    changelog_handler.ChangeType.FIXED, changes_by_change_type[changelog_handler.ChangeType.FIXED],
                    version="unreleased", write=True
                )

    @staticmethod
    def input_commit_choices(commits) -> dict:
        def get_user_choices(choice_type):
            choices = input(f"Which commits to include in the changelog for {choice_type} updates? > ")
            choices = [choice.strip() for choice in choices.split(',') if choice.strip()]
            return [commits.get(choice, choice) for choice in choices if commits.get(choice) or not choice.isnumeric()]

        return {
            KeepachangelogHandler.ChangeType.ADDED: get_user_choices(KeepachangelogHandler.ChangeType.ADDED),
            KeepachangelogHandler.ChangeType.FIXED: get_user_choices(KeepachangelogHandler.ChangeType.FIXED)
        }
