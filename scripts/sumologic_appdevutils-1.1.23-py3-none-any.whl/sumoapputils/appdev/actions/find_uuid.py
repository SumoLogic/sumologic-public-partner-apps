from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.list_apps import ListAction


class FindUuidAction:

    def execute(self):
        '''
        To decide what UUID to use,
        if the uuid is not passed as input
            It first attempts to find a deployment where the app is registered.
            If it finds one, it uses the UUID of the registered apps for all other deployments.
            If it doesn't find one, it uses the first UUID it receives when registering on the deployments.
        else
            it finds whether the passed uuid is present in any one of the deployments
            if not it throws exception if yes then it passes the deployment where it is present
        '''
        apps_by_dep = ListAction().list_for_all_dep()
        uuid_by_dep = {}
        app_uuid = None
        for dep, apps in apps_by_dep.items():
            if apps is not None:
                for app in apps.apps:
                    if app.name == state.app_name:
                        if state.app_uuid:
                            if app.uuid == state.app_uuid:
                                # if uuid is already passed as input and matches the one available in list api
                                # this verifies the passed uuid is valid
                                uuid_by_dep.update({dep: app.uuid})
                            else:
                                raise Exception(f"User Passed uuid: {state.app_uuid} didn't matched {app.uuid} for app {state.app_name} on {dep}!")
                        else:
                            uuid_by_dep.update({dep: app.uuid})

        uuid_set = set([uuid_by_dep[dep] for dep in state.all_authorized_deployments if dep in uuid_by_dep])
        uuids_found = len(uuid_set)
        if uuids_found == 1:
            app_uuid = uuid_set.pop()
            deployments = ",".join(uuid_by_dep.keys())
            utils.debug(f"User passed uuid found for app {state.app_name} and uuid {app_uuid} on deployments {deployments}")
        elif uuids_found == 0:
            if state.app_uuid:
                utils.warn(f"No uuid found for app {state.app_name} and uuid {state.app_uuid} on any deployments!")
            else:
                utils.warn(f"No uuid found for app {state.app_name} on any deployments!")
        elif uuids_found > 1:
            raise Exception(f"Multiple uuids found for same app {state.app_name} across deployments {uuid_by_dep}!")

        return app_uuid, uuid_by_dep
