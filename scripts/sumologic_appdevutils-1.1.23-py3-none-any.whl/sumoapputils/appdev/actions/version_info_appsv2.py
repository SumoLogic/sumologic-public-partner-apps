import requests
from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.common import Common


class AppsVersionInfo(Common):

    def __init__(self):
        self.params = {}
        self.status_by_deployment = {}

    def getVersionInfoByDep(self,dep,uuid,version):
        auth = utils.auth(dep)
        if auth is None:
            utils.warn(f"No auth found for {dep}. Skipping it.")
            self.status_by_deployment[dep] = None
            return 'Failure', "No auth found"
        else:
            utils.info(f"Checking availability of app with uuid: {uuid} with version : {version} on deployment: {dep}")
        try:
            response = requests.get(
                url=f"{utils.endpoint(dep)}/{uuid}/details?version={version}",
                auth=auth
            )
            response_json = response.json()
            if (response.status_code==200):
                utils.info(f"version found for uuid: {uuid} and version: {version}")
                return "Success", response_json
            else:
                utils.info(f"Details api failed with status code {response.status_code} for uuid: {uuid} and version: {version}")
                return "Failure", response_json

        except Exception as e:
            print("Exception Occured on calling details api")
            return 'Failure', str(e)

    def execute(self,app_name,app_uuid,app_version):
        for dep in state.deployments:
            app_found = False
            status, response = self.getVersionInfoByDep(dep, app_uuid, app_version)
            if status == "Success":
                app_found = True
            else:
                app_found = False
            error_msg = ""
            if app_found:
                utils.success(f"App name - {app_name} with version : {app_version} and UUID - {app_uuid} in deployment - {dep} is available")
            else:
                error_msg = f"App not found. App name - {app_name} with version : {app_version} and UUID - {app_uuid} in deployment - {dep}"
                utils.error(error_msg)
            self.status_by_deployment[dep] = (status,response)
            return self.status_by_deployment
