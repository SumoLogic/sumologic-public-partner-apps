from sumoapputils.appdev.actions.translate_manifest import TranslateManifest


class TranslateManifestPartner(TranslateManifest):
    @staticmethod
    def get_help_url(data: str):
        help_url = None
        if "helpURL" in data:
            if "https://github.com/SumoLogic/sumologic-public-partner-apps/tree/master/" in data["helpURL"]:
                help_url = data["helpURL"].replace(
                    "https://github.com/SumoLogic/sumologic-public-partner-apps/tree/master/",
                    "https://github.com/SumoLogic/sumologic-public-partner-apps/tree/master/src/"
                )
            else:
                help_url = data["helpURL"]

        return help_url
