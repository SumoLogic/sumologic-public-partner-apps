import json

import requests
import yaml
import os
from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.find_uuid import FindUuidAction
from sumoapputils.appdev.utils import get_default_apps_directory


class RegisterAction:

    def __init__(self):
        self.app_dir = utils.find_app_directory(state.app_name)
        self.params = self.read_params_from_manifest()
        self.newly_registered_deps = []

    def execute(self):
        self.find_uuid()
        for dep in state.deployments:
            self.__register_for_dep(dep)
        if not self.newly_registered_deps:
            utils.warn("App was not registered in any new deployment!")
        else:
            utils.success(f"App was registered in deployments {self.newly_registered_deps}")
        return state.app_uuid

    def find_uuid(self):
        app_uuid, uuid_by_dep = FindUuidAction().execute()
        state.uuid_by_dep = uuid_by_dep
        if app_uuid is None:
            if state.app_uuid:
                utils.debug(f"Creating new uuid for app: {state.app_name} using user passed uuid: {state.app_uuid}")
                self.params['uuid'] = state.app_uuid
            else:
                utils.debug(f"Creating new uuid for app: {state.app_name}")
        else:
            utils.debug(f"Using existing uuid for registering app: {state.app_name}")
            state.app_uuid = app_uuid

        self.params['uuid'] = state.app_uuid

    def read_params_from_manifest(self):
        manifestfilepath = os.path.join(get_default_apps_directory(), self.app_dir, 'manifest.yaml')
        with open(manifestfilepath, 'r') as file:
            app_manifest = yaml.safe_load(file)
            return {
                'name': app_manifest['name'],
            }

    def __register_for_dep(self, dep: str):
        utils.info(f"Attempting to register the app on deployment: {dep}")
        state.app_uuid = state.uuid_by_dep.get(dep)
        if state.app_uuid is not None:
            utils.warn(f"App is already registered for deployment {dep} with uuid {state.app_uuid}. Skipping registration.")
            return

        url = f"{utils.endpoint(dep)}/private" if state.is_private else f"{utils.endpoint(dep)}"

        response = requests.post(
            url=url,
            auth=utils.auth(dep),
            headers={'Content-Type': 'application/json'},
            json=self.params
        )
        if response.ok:
            state.app_uuid = json.loads(response.text)['uuid']
            self.newly_registered_deps.append(dep)
        else:
            raise Exception(f"Error in /register API: status={response.status_code} reason={response.reason} text={response.text}")
