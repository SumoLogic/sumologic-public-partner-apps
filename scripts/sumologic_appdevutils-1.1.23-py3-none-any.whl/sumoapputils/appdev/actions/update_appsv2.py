import requests
from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.common import Common
import json


class UpdateAction(Common):

    def __init__(self):
        self.params = {}
        self.app_update_errors = {}

    def execute(self, app_source_mapping,app_version):
        self.find_uuid(self.params)
        for dep in state.deployments:
            auth = utils.auth(dep)
            if auth is None:
                utils.warn(f"No auth found for {dep}. Skipping it.")
            else:
                utils.info(f"Updating app: {state.app_name} from version {state.app_version} to {app_version} on deployment: {dep}")
                has_app_updated = False
                status, response_json = self.__update(dep, auth, app_source_mapping,app_version)
                if status == "Success":
                    has_app_updated = True
                error_msg = ""
                if has_app_updated:
                    utils.success(f"Update succeeded for app name - {state.app_name} and UUID - {state.app_uuid} in deployment - {dep} from version {state.app_version} to {app_version}")
                else:
                    error_msg = f"Update failed for app name - {state.app_name} and UUID - {state.app_uuid} in deployment - {dep} from version {state.app_version} to {app_version} with response {response_json}"
                    utils.error(error_msg)
                    self.app_update_errors[dep] = error_msg
        return self.app_update_errors

    def __update(self, dep: str, auth, app_source_mapping: dict, app_version):
        response_json = ''
        try:
            payload = {"version": f"{app_version}"}
            source_params = {}
            for parameter in app_source_mapping:
                source_params.update({
                    parameter["input_name"]: parameter["input_name_value"]
                })
            if source_params:
                payload["parameters"] = source_params
            response = requests.post(
                url=f"{utils.endpoint(dep)}/{self.params['uuid']}/upgrade",
                auth=auth,
                headers={'Content-Type': 'application/json'},
                data=json.dumps(payload),
                timeout=300
            )
            response_json = response.json()
            response.raise_for_status()
            jobId = response_json["jobId"]
            return self._wait_for_job_completion(f"{utils.endpoint(dep)}/upgrade", jobId, auth)
        except Exception as e:
            return 'Failed', response_json
