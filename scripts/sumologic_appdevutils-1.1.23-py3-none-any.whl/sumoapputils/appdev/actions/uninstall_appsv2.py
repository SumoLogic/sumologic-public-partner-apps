from sumoapputils.appdev import utils, state
from sumoapputils.appdev.actions.common import Common


class UninstallAction(Common):

    def __init__(self):
        self.params = {}
        self.app_install_errors = {}

    def execute(self):
        self.find_uuid(self.params)
        for dep in state.deployments:
            auth = utils.auth(dep)
            if auth is None:
                utils.warn(f"No auth found for {dep}. Skipping it.")
                self.apps_by_deployment[dep] = None
            elif state.app_uuid == "null" or state.app_uuid is None or state.app_uuid == "":
                error_msg = f"Uninstallation warning for app name - {state.app_name} in deployment - {dep}, app not found. Skipping it."
                utils.warn(error_msg)
                self.app_install_errors[dep] = error_msg
            else:
                utils.info(f"Uninstalling app: {state.app_name} on deployment: {dep}")
                status, response_json = self.__uninstall(dep, self.params, auth)
                if status == "Success":
                    utils.success(f"Uninstallation succeeded for app name - {state.app_name} and UUID - {state.app_uuid} in deployment - {dep}")
                else:
                    if "errors" in response_json and response_json["errors"][0]['code'] == "apps:not_found":
                        error_msg = f"Uninstallation warning for app name - {state.app_name} in deployment - {dep}, cannot process uninstall as no installed app found with response {response_json}"
                        utils.warn(error_msg)
                    else:
                        error_msg = f"Uninstallation failed for app name - {state.app_name} and UUID - {state.app_uuid} in deployment - {dep} with response {response_json}"
                        utils.error(error_msg)
                        self.app_install_errors[dep] = error_msg
        return self.app_install_errors

    def __uninstall(self, dep: str, params: dict, auth):
        return self.uninstall(dep, self.params, auth)
