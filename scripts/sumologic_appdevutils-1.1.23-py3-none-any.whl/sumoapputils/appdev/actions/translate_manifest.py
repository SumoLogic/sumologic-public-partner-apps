import json
import os
from typing import List
from urllib.parse import urlsplit
from sumoapputils.appdev import utils
from sumoapputils.common.utils import account_type_mapping
import requests
import yaml
import re
try:
    import Levenshtein
    from scipy.optimize import linear_sum_assignment
    import numpy as np
except (ImportError, ModuleNotFoundError) as err:
    print("Warning: Install below dependencies for using translate-manifest/translate-app/translate-batch commands\n" + "python-Levenshtein~=0.21.1\nscipy~=1.7.3\nnumpy~=1.21.6\nLevenshtein~=0.20.9")


class TranslateManifest:
    def __init__(self):
        # Ordering of keys in the end does not matter - we are introducing this ordering as a part of manifest file
        # "best practices"
        self.all_keys_ordered = ["schemaVersion", "name", "family", "version", "description", "author", "attributes", "accountTypes", "appOverview", "appMedia", "installable", "showOnMarketplace"]
        self.mandatory_keys = ['schemaVersion', 'name', 'version', 'description', 'author', 'appOverview']

        self.mandatory_keys_default_values = {
            'schemaVersion': '2.0',
            'version': '1.0.0',
            'installable': True,
            'showOnMarketplace': True,
            'appOverview': {'overview': "README.md#Overview"},
            'appMedia': [],
            'attributes': {
                "category": [],
                "useCase": [],
                "collection": ["Hosted"]
            }
        }

    def download_files(self, urls: list, output_path: str):
        downloaded_files = []

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        for url in urls:
            try:
                response = requests.get(url, verify=False)
                file_name = os.path.basename(url)
                file_path = os.path.join(output_path, file_name)
                if os.path.isfile(file_path):
                    utils.info(f"File {file_name} already exists")
                else:
                    with open(file_path, "wb") as file:
                        file.write(response.content)
                    utils.info(f"File {file_name} downloaded successfully")
                downloaded_files.append(file_path)
            except Exception as e:
                utils.error(f"Error downloading file from {url}: {e}")

        return downloaded_files

    def get_overview_info_static_resources(self, data: dict, output_path: str):
        file_names = []
        if 'screenshotURLs' in data.keys():
            file_names = self.download_files(data['screenshotURLs'], output_path)

        # Extract file names without paths
        static_resource_names = [os.path.basename(file_name) for file_name in file_names]
        return static_resource_names

    def get_icon_static_resources(self, data: dict, output_path: str):
        def extract_filename_from_url(url):
            parsed_url = urlsplit(url)
            return os.path.basename(parsed_url.path)

        if 'iconURL' in data.keys():
            self.download_files([data['iconURL']], output_path)
            filename = extract_filename_from_url(data['iconURL'])
            os.rename(os.path.join(output_path, filename), os.path.join(output_path, 'icon.png'))

    def translate_manifest(self, data: dict):
        # fill in missing mandatory keys with default values
        for key, default_value in self.mandatory_keys_default_values.items():
            if key not in data:
                data[key] = default_value

        # some manifest files do not have author in V1 app
        if "author" not in data:
            data["author"] = "Sumo Logic"
        # check if all mandatory keys exist
        missing_keys = [key for key in self.mandatory_keys if key not in data]
        if missing_keys:
            raise ValueError(f'Missing mandatory keys: {missing_keys}')

        author = {
            "supportUrl": "https://support.sumologic.com/",
            "homeUrl": "https://sumologic.com"
        }
        if "helpURL" in data:
            author["documentationUrl"] = data["helpURL"]
        if "author" in data:
            author["name"] = data["author"]

        data["author"] = author
        data["attributes"]["category"] = data["categories"]

        if "Compliance and Security" in data["categories"]:
            useCase = ["security"]
        else:
            useCase = ["observability"]
        if "amazon" in data["name"].lower() or "aws" in data["name"].lower():
            data["attributes"]["searchTerms"] = ["amazon", "aws"]
        elif "azure" in data["name"].lower() or "microsoft" in data["name"].lower():
            data["attributes"]["searchTerms"] = ["azure", "microsoft"]
        elif "google" in data["name"].lower() or "gcp" in data["name"].lower():
            data["attributes"]["searchTerms"] = ["google", "gcp"]
        data["attributes"]["useCase"] = useCase

        # We forcefully overwrite version with 2.0.0
        data["version"] = "1.0.0"

        if "accountTypes" in data:
            data["accountTypes"] = [account_type_mapping[account_type.lower()] for account_type in data["accountTypes"]]

        # reorder the keys according to the desired order
        ordered_data = {key: data[key] for key in self.all_keys_ordered if key in data}

        # Returned the ordered data as YAML
        return yaml.dump(ordered_data, sort_keys=False)

    def extract_dict_from_nested_json(self, json_data):
        if isinstance(json_data, dict):
            return {k: self.extract_dict_from_nested_json(v) for k, v in json_data.items()}
        elif isinstance(json_data, list):
            return [self.extract_dict_from_nested_json(elem) for elem in json_data]
        else:
            return json_data

    def extract_dict_from_json(self, json_file_path: str):
        with open(json_file_path, 'r') as json_file:
            json_data = json.load(json_file)
            if isinstance(json_data, dict):
                return self.extract_dict_from_nested_json(json_data)
            else:
                raise TypeError("JSON data is not a dictionary")

    def get_manifest_file(self, folder_path: str):
        for file_name in os.listdir(folder_path):
            if file_name.endswith('.manifest.json'):
                return os.path.join(folder_path, file_name)
        return ""

    def associate_screenshots_to_dashboards(self, dashboard_names, screenshot_names):
        def strip_file_extension(name):
            return os.path.splitext(name)[0]

        def convert_name(name):
            # Remove non-alphanumeric characters and lowercase the name
            return re.sub(r'\W+', '', name).lower()

        # Strip file extensions from screenshot names
        stripped_screenshot_names = [strip_file_extension(name) for name in screenshot_names]

        # Convert dashboard and stripped screenshot names
        converted_dashboard_names = [convert_name(name) for name in dashboard_names]
        converted_screenshot_names = [convert_name(name) for name in stripped_screenshot_names]

        # Compute the Levenshtein distance matrix
        distance_matrix = np.zeros((len(converted_dashboard_names), len(converted_screenshot_names)))
        for i, dashboard_name in enumerate(converted_dashboard_names):
            for j, screenshot_name in enumerate(converted_screenshot_names):
                distance_matrix[i, j] = Levenshtein.distance(dashboard_name, screenshot_name)

        # Use linear_sum_assignment to find the optimal assignment
        row_indices, col_indices = linear_sum_assignment(distance_matrix)

        # Create the association dictionary with original names
        associations = {}
        for dashboard_index, screenshot_index in zip(row_indices, col_indices):
            associations[dashboard_names[dashboard_index]] = screenshot_names[screenshot_index]

        return associations

    def extract_overview_info_items(self, content_dict, relative_screenshot_folder_path: str,
                                    screenshot_names: List[str], assets_images_preview_path: str):
        overview_items = []

        def recursive_search(item):
            if isinstance(item, dict):
                if item.get("type") in ["DashboardV2SyncDefinition", "DashboardSyncDefinition", "Dashboard"]:
                    title = item.get("title", item.get("name"))
                    description = item.get("description")
                    overview_items.append({"title": title, "description": description, "type": "", "location": ""})

                if "children" in item:
                    for child in item["children"]:
                        recursive_search(child)
            elif isinstance(item, list):
                for i in item:
                    recursive_search(i)

        recursive_search(content_dict)

        dashboard_names = [item["title"] for item in overview_items]

        try:
            associations = self.associate_screenshots_to_dashboards(dashboard_names, screenshot_names)

            for item in overview_items:
                if item["title"] in associations:
                    # renaming files if they do not follow screenshot filename convention
                    current_image_filename = associations[item["title"]]
                    file_ext = current_image_filename.split(".")[-1]
                    expected_image_filename = "%s.%s" % (utils.slugify_text(item["title"]), file_ext)
                    os.rename(os.path.join(assets_images_preview_path, current_image_filename), os.path.join(assets_images_preview_path, expected_image_filename))
                    item["location"] = str(relative_screenshot_folder_path + expected_image_filename)
                    item["type"] = "image"
        except Exception as e:
            utils.error("Could not associate screenshots to dashboards. Reason: " + str(e))

        return overview_items

    def execute(self, manifest_path: str, content_file_path: str, output_path: str):
        manifest_dict = self.extract_dict_from_json(manifest_path)
        content_dict = self.extract_dict_from_json(content_file_path)

        assets_images_path = os.path.join(output_path, "assets", "images")
        assets_images_preview_path = os.path.join(output_path, "assets", "images", "preview")

        if not os.path.exists(assets_images_path):
            os.makedirs(assets_images_path)

        if not os.path.exists(assets_images_preview_path):
            os.makedirs(assets_images_preview_path)

        screenshot_names = self.get_overview_info_static_resources(manifest_dict, assets_images_preview_path)
        self.get_icon_static_resources(manifest_dict, assets_images_path)

        # This needs to be done after the static resources are downloaded
        manifest_dict["appMedia"] = self.extract_overview_info_items(content_dict, "./assets/images/preview/", screenshot_names, assets_images_preview_path)

        yaml_output = self.translate_manifest(manifest_dict)

        with open(os.path.join(output_path, "manifest.yaml"), "w") as yaml_file:
            yaml_file.write(yaml_output)

        return manifest_dict
