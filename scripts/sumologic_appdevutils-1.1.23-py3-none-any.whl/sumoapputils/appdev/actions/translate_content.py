import json
import time
import traceback
from typing import Any, Dict, List
import requests

from sumoapputils.appdev import utils
from sumoapputils.appdev.actions.base_content import BaseContent


class TranslateContent(BaseContent):

    def import_app_content(self, content_file_json: Dict[str, Any], dest_folder_id: str) -> None:
        import_endpoint = f"{utils.get_endpoint(self.deployment)}/v2/content/folders/{dest_folder_id}/import"

        response = requests.post(
            url=import_endpoint,
            auth=utils.auth(self.deployment),
            headers={'Content-Type': 'application/json'},
            json=content_file_json
        )
        if response.ok:
            job_id = json.loads(response.content)['id']
            self._wait_for_job_completion(import_endpoint, job_id)
        else:
            raise Exception(f"Failed to import app content Error: {response.content}")

    def install_app_content(self, app_name: str, app_description: str, uuid: str, dest_folder_id: str, source_category: str) -> None:
        install_endpoint = f"{utils.get_endpoint(self.deployment)}/v1/apps/{uuid}/install"
        install_status_endpoint_prefix = f"{utils.get_endpoint(self.deployment)}/v1/apps/install"
        datasources = {}
        if source_category:
            for sc in source_category.split(","):
                key, value = sc.strip().split(":")

                datasources.update({key.strip(): value.strip()})

        response = requests.post(
            url=install_endpoint,
            auth=utils.auth(self.deployment),
            headers={'Content-Type': 'application/json'},
            json={
                'name': app_name,
                'description': app_description[:250],
                'destinationFolderId': dest_folder_id,
                'dataSourceValues': datasources
            }
        )
        if response.ok:
            job_id = json.loads(response.content)['id']
            self._wait_for_job_completion(install_status_endpoint_prefix, job_id)
        else:
            raise Exception(f"Failed to install app content Error: {response.content}")

    def migrate_dashboards_v1_to_v2(self, dashboards_list: List[Dict[str, Any]]) -> None:
        migrate_endpoint = f"{utils.get_endpoint(self.deployment)}/v2/dashboards/migrate"
        dashboard_ids = [item['id'] for item in dashboards_list]
        try:
            response = requests.post(
                url=migrate_endpoint,
                auth=utils.auth(self.deployment),
                headers={'Content-Type': 'application/json'},
                json={
                    'contentIds': dashboard_ids
                }
            )
            if response.ok:
                job_id = json.loads(response.content)['jobId']
                # Todo check why this job api fails
                # self._wait_for_job_completion(migrate_endpoint, job_id)
                time.sleep(120)
            else:
                raise Exception(f"Failed to migrate_dashboards_v1_to_v2  Error: {response.content}")
        except Exception as e:
            raise Exception("Error in getting job_id")

    def clean_up(self, app_folder_id: str) -> None:
        delete_content_endpoint = f"{utils.get_endpoint(self.deployment)}/v2/content/{app_folder_id}/delete"

        requests.delete(
            url=delete_content_endpoint,
            auth=utils.auth(self.deployment),
        )

    def get_v1_dashboards(self, content_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return [item for item in content_list if item['itemType'] == 'Report']

    def execute(self, uuid: str, app_name: str, app_description: str, source_category: str) -> None:
        try:
            pre_personal_folder = self.get_personal_folder()
            app_folder_id = self.get_app_folder_id(app_name, pre_personal_folder)
            if app_folder_id:
                utils.warn(f"{app_name} folder already exists please delete it.")
                return
            personal_folder_id = pre_personal_folder['id']
            self.install_app_content(app_name, app_description, uuid, personal_folder_id, source_category)
            post_install_personal_folder = self.get_personal_folder()
            app_folder = self.get_app_folder(app_name, post_install_personal_folder)
            all_content = self.get_all_content(app_folder['id'])
            v1_dashboards = self.get_v1_dashboards(all_content)
            self.migrate_dashboards_v1_to_v2(v1_dashboards)
            utils.info(f"Successfully migrated app {app_name} from Classic to Mewboards. Please go to sumologic org verify the content and run export-app command")
        except Exception as e:
            utils.error(f"Error occurred during v1 app translation: {e} Traceback: {traceback.format_exc()}")
