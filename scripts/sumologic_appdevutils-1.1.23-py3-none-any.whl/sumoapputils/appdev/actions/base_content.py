import json
import time
from typing import Any, Dict, List
import requests
from sumologic import SumoLogic
from sumoapputils.appdev import utils, state
from sumoapputils.common.utils import ENVIRONMENT


class BaseContent(object):

    def __init__(self):
        if not state.deployments:
            self.deployment = ENVIRONMENT.SUMO_DEPLOYMENT
        else:
            self.deployment = state.deployments[0]

        if not self.deployment:
            raise Exception("Specifiy deployment either by passing -d or using SUMOLOGIC_ENVIRONMENT env variable")

    def _get_global_folder(self, sumocli):
        base_url = "/content/folders/global"
        response = sumocli.get(base_url, version='v2')
        job_id = response.json()["id"]
        retry_count = 30
        while retry_count > 0:
            status = sumocli.get(f'{base_url}/{job_id}/status',
                                 version='v2').json()["status"]
            if status == "Success":
                return sumocli.get(f'{base_url}/{job_id}/result',
                                   version='v2')
            else:
                utils.debug(f"Waiting for {base_url} job... {status}")
            retry_count = retry_count - 1
            time.sleep(5)

    def get_global_folder(self) -> Dict[str, Any]:
        access_id, access_key = utils.get_deployment_keys(self.deployment)
        sumologic = SumoLogic(access_id, access_key, utils.get_endpoint(self.deployment))
        jobResult = self._get_global_folder(sumologic)
        if jobResult.ok:
            jobResultContent = json.loads(jobResult.content)
            for item in jobResultContent["data"]:
                if item["itemType"] == "Folder" and item["name"] == "Installed Apps":
                    return self.get_folder(item["id"])
        else:
            raise Exception("Unable to fetch get global folder")

    def get_personal_folder(self) -> Dict[str, Any]:
        return self.get_folder("personal")

    def get_folder(self, folder_id: str) -> Dict[str, Any]:

        endpoint = f"{utils.get_endpoint(self.deployment)}/v2/content/folders/{folder_id}"

        response = requests.get(
            url=endpoint,
            auth=utils.auth(self.deployment),
        )

        if response.status_code != 200:
            raise Exception(f"Failed to get folder {folder_id} on {self.deployment} status code {response.status_code}: {response.text}")

        return json.loads(response.content)

    def get_monitor_folder(self, monitor_path: str) -> Dict[str, Any]:

        endpoint = f"{utils.get_endpoint(self.deployment)}/v1/monitors/path?path={monitor_path}"

        response = requests.get(
            url=endpoint,
            auth=utils.auth(self.deployment),
        )

        if response.status_code != 200:
            raise Exception(f"Failed to get monitor folder {monitor_path} on {self.deployment} status code {response.status_code}: {response.text}")

        return json.loads(response.content)

    def get_all_content(self, folder_id: str) -> List[Dict[str, Any]]:
        content = []
        folder = self.get_folder(folder_id)

        if folder["itemType"] == "Folder":
            if "children" in folder:
                for child in folder["children"]:
                    if child["itemType"] == "Folder":
                        content.extend(self.get_all_content(child['id']))
                    else:
                        content.append(child)

        return content

    def get_app_folder_id(self, app_name, personal_folder):
        app_folder_id = None
        for child in personal_folder['children']:
            if child['name'] == app_name:
                app_folder_id = child['id']
                break
        return app_folder_id

    def get_app_folder(self, app_name: str, personal_folder: Dict[str, Any]) -> Dict[str, Any]:
        app_folder_id = self.get_app_folder_id(app_name, personal_folder)
        if app_folder_id:
            return self.get_folder(app_folder_id)

        raise Exception(f"App Name: {app_name} not found in folder in {personal_folder['name']} folder")

    def _wait_for_job_completion(self, base_url: str, job_id: str, timeout: int = 180) -> None:
        start_time = time.time()
        utils.info(f"Job for url {base_url} created with jobid: {job_id}")
        while True:
            if time.time() - start_time > timeout:
                raise Exception("Job timed out.")

            status_endpoint = f"{base_url}/{job_id}/status"
            response = None
            try:
                response = requests.get(url=status_endpoint, auth=utils.auth(self.deployment))
                status = response.json()["status"]

                if status.lower() == "success":
                    break
                elif status.lower() == "failed":
                    raise Exception(f"Job encountered an error {response.content}")

                utils.debug(f"Waiting for {base_url} job... {status}")
                time.sleep(1)
            except Exception as e:
                raise Exception(f"Job {job_id} encountered an error {e} response: {response.content if response else response}")

    def __get_dashboards(self, dashboard_content_ids):
        def get_paginated_dashboards(url, headers, next_token=None):
            params = {'token': next_token, "mode": "createdByUser"} if next_token else {}
            response = requests.get(url, headers=headers, auth=utils.auth(self.deployment), params=params)

            if response.status_code != 200:
                raise Exception(f"Failed to fetch dashboards on deployment: {self.deployment} with status code {response.status_code}: {response.text}")

            return response.json()

        base_url = f"{utils.get_endpoint(self.deployment)}/v2/dashboards/"
        headers = {'Content-Type': 'application/json'}
        # all_dashboards = []
        next_token = None
        all_dashboards = []
        expected_dashboard_count = len(dashboard_content_ids)
        page_count = 0
        while len(all_dashboards) < expected_dashboard_count:
            response_json = get_paginated_dashboards(base_url, headers, next_token)
            new_dashboards = [dashboard for dashboard in response_json['dashboards'] if dashboard["contentId"] in dashboard_content_ids]
            page_count += 1
            utils.debug(f"{len(new_dashboards)} matched out of {len(response_json['dashboards'])} in page: {page_count}")
            all_dashboards.extend(new_dashboards)
            if response_json["next"] is not None:
                next_token = response_json["next"]
            else:
                break

        if len(all_dashboards) != expected_dashboard_count:
            raise Exception("Not able to find dashboards. Make sure the app is installed by your user.")

        return all_dashboards

    def get_dashboards_by_contentId(self, dashboard_content_ids):
        return self.__get_dashboards(dashboard_content_ids)

    def get_dashboards_ids_by_contentId(self, dashboard_content_ids: List[str]) -> List[str]:
        all_dashboards = self.__get_dashboards(dashboard_content_ids)
        all_dashboard_ids = [dashboard['id'] for dashboard in all_dashboards]

        return all_dashboard_ids
