import os

from sumoapputils.appdev.actions.translate_content import TranslateContent
from sumoapputils.appdev.apptasks import AppEntry
import yaml
import json
from sumoapputils.appdev import utils


class TranslateContentBatch:
    # remaining_apps_to_migrate = [
    # ]

    def get_json(self, filepath):
        with open(filepath, 'r') as file:
            data = json.load(file)
        return data

    def execute(self, contentdirpath: str, applistfilepath: str):

        with open(applistfilepath, 'r') as f:
            app_list = yaml.load(f, Loader=yaml.FullLoader)['apps']

        for app in app_list:

            app_name = app[AppEntry.NAME_FIELD]
            # if app_name not in self.remaining_apps_to_migrate:
            #     continue
            manifest_file_path = os.path.join(contentdirpath, app[AppEntry.MANIFEST_PATH_FIELD])
            app_file_path = os.path.join(contentdirpath, app[AppEntry.SOURCE_PATH_FIELD])
            utils.info(f"Translating v1 app {app_name} using manifestjson: {manifest_file_path} appjson: {app_file_path}")
            source_mapping = []
            for input in app[AppEntry.DEMO_INPUT_MAPPING_FIELD]:
                source_mapping.append(f"{input[AppEntry.INPUT_NAME_FIELD]}:{input[AppEntry.INPUT_CATEGORY_FIELD]}")

            source_category = ",".join(source_mapping)
            utils.info(f"Found loggen sources:  {source_category}")

            try:
                manifest_json = self.get_json(manifest_file_path)
                TranslateContent().execute(manifest_json["uuid"], manifest_json["name"], manifest_json["description"], source_category)
            except Exception as e:
                utils.error(f"Error while translating app located in {app_name} Reason: {e}")
