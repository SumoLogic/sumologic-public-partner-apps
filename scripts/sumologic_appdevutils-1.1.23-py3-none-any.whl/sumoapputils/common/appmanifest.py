#!/usr/bin/python
import json
import pathlib
from string import Template
import uuid
import os
import re
from abc import ABCMeta, abstractmethod

from sumoappclient.provider.factory import ProviderFactory
from sumoappclient.common.logger import get_logger
import yaml
from sumoapputils.common.testapp import TestApp, TestTfDashboards
from sumoapputils.common.utils import get_file_data, USER, get_app_config_key, load_yaml_to_json, get_scope_key_variable_value
import six
import click
from sumoapputils.common.testutils import get_test_class
from sumoapputils.appdev.utils import slugify_text, copytree
from sumoapputils.appdev import utils


cli_logger = get_logger(__name__, LOG_FILEPATH="/tmp/sumoapptestutils.log", LOG_LEVEL=os.environ.get("LOG_LEVEL", "INFO"))

if six.PY2:
    input = raw_input

APP_CATEGORIES = ["Amazon Web Services", "Compliance and Security", "Database", "DevOps", "Google Cloud Platform", "IT Infrastructure", "Kubernetes", "Microsoft Azure", "Operating System", "Security", "Storage", "Sumo Logic", "Sumo Logic Certified", "Sumo Logic Global Intelligence", "Sumo Logic Solutions", "Tracing", "Web Server", "Work from Home Solution"]
AMAZON_SEARCH_TERMS = ["amazon", "aws"]
MICROSOFT_SEARCH_TERMS = ["microsoft", "azure"]
GOOGLE_SEARCH_TERMS = ["google", "gcp"]
reverse_category_map = {val: i for i, val in enumerate(APP_CATEGORIES)}

APP_CATEGORY_NUM_CHOICES = "\n".join(["[%d] - %s" % (i, val) for i, val in enumerate(APP_CATEGORIES)])

MANDATORY_CATEGORY_FOR_PARTNER_APPS = "Sumo Logic Certified"


@click.group()
def manifestcmd():
    pass


def validate_choice(ctx, param, value):
    try:
        values = [c.strip().strip('[').strip(']') for c in value.split(',')] if isinstance(value, str) else value
        num_values = map(lambda nv: int(nv), values)
        categories = list(map(lambda idx: APP_CATEGORIES[idx], num_values))
        return categories

    except IndexError:
        # If the index does not exist.
        click.echo('Please select a valid index.')

    except (TypeError, ValueError):
        # If the value is of a different type, for example, String.
        click.echo('Please select a valid value from the choices. \n\n{}\n\n'.format(APP_CATEGORY_NUM_CHOICES))

    # Prompt the user for an input.
    value = click.prompt(param.prompt)
    return validate_choice(ctx, param, value)


def validate_url(ctx, param, value):

    regex = re.compile(
        r'^(?:http|ftp)s?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)

    try:
        if not re.match(regex, value):
            raise ValueError(value)
        else:
            return value
    except ValueError as e:
        click.echo('Incorrect url given: {}'.format(e))
        value = click.prompt(param.prompt)
        return validate_url(ctx, param, value)


class DefaultOptionFromManifest(click.Option):
    _value_key = '_default_val'

    def __init__(self, *args, **kwargs):
        # https://stackoverflow.com/questions/51846634/click-dynamic-defaults-for-prompts-based-on-other-options
        self.manifest_key = kwargs.pop('manifest_key', None)
        super(DefaultOptionFromManifest, self).__init__(*args, **kwargs)

    def get_default(self, ctx, *args, **kwargs):
        if "manifestfile" not in ctx.params:
            return super(DefaultOptionFromManifest, self).get_default(ctx, *args, **kwargs)
        if not hasattr(self, self._value_key):
            manifestfile = ctx.params["manifestfile"]
            manifestjson = get_file_data(manifestfile)
            appManifestDict = json.loads(manifestjson)
            key = self.manifest_key if self.manifest_key else self.name
            if not (key in appManifestDict):
                if key == "author":
                    appManifestDict[key] = "Sumo Logic"
                else:
                    raise Exception(f"{key} not found in app manifest")

            value = appManifestDict[key]
            if key == "categories":
                value = list(map(lambda cname: reverse_category_map[cname], value))
            setattr(self, self._value_key, value)
        return getattr(self, self._value_key)


@manifestcmd.command(help="For creating manifest file")
@click.option('-s', '--source', required=True, type=click.Path(exists=True), help='Set filepath for appjson')
@click.option('-c', '--categories', metavar='<category_id>', is_flag=False, required=True, prompt='\nPlease enter the comma separated numerical value corresponding to the app category name.\n\n{}\n\n'.format(APP_CATEGORY_NUM_CHOICES), type=click.STRING, help='Set app category', callback=validate_choice)
@click.option('-a', '--author', required=True, prompt='\nPlease enter the author name.', help="Set author of the app", default="Sumo Logic")
@click.option('-u', '--helpurl', required=True, prompt='\nPlease enter the help url.', help="Set author of the app", callback=validate_url)
def create_manifest(source, categories, author, helpurl):
    # https://stackoverflow.com/questions/33892793/how-to-supply-multiple-options-with-array-validation

    filepath = click.format_filename(source)
    appjson = get_file_data(filepath)
    appjsondic = json.loads(appjson)
    if (appjsondic.get('type', '') not in ('Folder', 'FolderSyncDefinition')) or ('children' not in appjsondic):
        return cli_logger.error("Please export app folder instead of exporting single dashboard. Refer: https://help.sumologic.com/01Start-Here/Library/Export-and-Import-Content-in-the-Library#export-content-in-the-library for more details")
    am = AppManifest(filepath, categories, author, helpurl)
    manifestfile = filepath.replace(".json", ".manifest.json")
    manifest_exists = os.path.isfile(manifestfile)
    force_create = False
    if manifest_exists:
        force_create = input("Manifest already exists.Do you want to continue y/n: ").lower() in ("y", "yes")
    if not manifest_exists or force_create:
        am.prepAppManifest(not USER.is_partner)
        am.set_source_parameters()
        am.set_manifest_parameters()
        am.outputManifestFile()


@manifestcmd.command(help="For updating manifest file")
@click.option('-s', '--sourcefile', required=True, type=click.Path(exists=True), help='Set filepath for appjson')
@click.option('-m', '--manifestfile', required=True, type=click.Path(exists=True), help='Set filepath for manifest json')
@click.option('-c', '--categories', cls=DefaultOptionFromManifest, metavar='<category_id>', is_flag=False, prompt='\nPlease enter the comma separated numerical value corresponding to the app category name, else enter to continue with the default value\n\n -- :\n{}\n\n'.format(APP_CATEGORY_NUM_CHOICES), type=click.STRING, help='Set app category', callback=validate_choice)
@click.option('-a', '--author', cls=DefaultOptionFromManifest, prompt='\nPlease enter the new author name, else enter to continue with the default value', help="Set author of the app")
@click.option('-u', '--helpurl', cls=DefaultOptionFromManifest, prompt='\nPlease enter the new help url, else enter to continue with the default value', help="Set author of the app", callback=validate_url, manifest_key="helpURL")
def update_manifest(sourcefile, manifestfile, categories, author, helpurl):
    # Todo show old category and make it default
    filepath = click.format_filename(sourcefile)
    am = AppManifest(filepath, categories, author, helpurl)
    am.get_manifest(manifestfile)
    am.set_source_parameters()
    am.set_manifest_parameters()
    am.outputManifestFile()


@six.add_metaclass(ABCMeta)
class BaseSubstitutionStrategy(object):

    def __init__(self):
        op_cli = ProviderFactory.get_provider("onprem")
        self.store = op_cli.get_storage("keyvalue", name='sumoapputils', db_dir="~/sumo", logger=cli_logger)
        self.log = get_logger(__name__, LOG_FILEPATH="/tmp/sumoapptestutils.log",
                              LOG_LEVEL=os.environ.get("LOG_LEVEL", "INFO"))

        self.app_config_key = None
        self.param_mapping = None
        self.reverse_param_mapping = None
        self.appended_params = set()

    @abstractmethod
    def set_source_parameters(self):
        raise NotImplementedError()

    @abstractmethod
    def replace_param_callback(self, query_string, location_text, query_type):
        raise NotImplementedError()

    def _createParameter(self, paramName, paramDataSourceType):
        return {
            "parameterType": "DATA_SOURCE",
            "parameterId": paramName.replace("$$", ""),
            "dataSourceType": paramDataSourceType,
            "label": "%s data source" % paramDataSourceType,
            "description": "%s data source" % paramDataSourceType,
            "example": None
        }

    @classmethod
    def _process_dashboard_queries(cls, dash, callback):
        if TestApp.is_mew_board(dash):
            panels = dash["rootPanel"].get("panels", []) if dash.get("rootPanel") else dash.get("panels", [])
            for panel in panels:
                if panel.get("panelType") in ("TextPanel", "EventsOfInterestScatterPanel") or panel.get("Type") == "TextPanel":
                    continue
                for query in panel["queries"]:
                    panel_name = panel.get("title")
                    if query["queryType"] == "Logs":
                        query["queryString"] = callback(query["queryString"], "Panel: %s" % panel_name, "Logs")
                    else:
                        query["queryString"] = callback(query["queryString"], "Panel: %s" % panel_name, "Metrics")

            variables = dash["rootPanel"].get("variables", []) if dash.get("rootPanel") else dash.get("variables", [])

            for variable in variables:
                var_name = variable.get("name")
                definition = variable.get("sourceDefinition", {})
                if definition.get("variableSourceType", "") == "LogQueryVariableSourceDefinition":
                    definition["query"] = callback(definition["query"], "Variable: %s" % var_name, "Logs")
                elif definition.get("variableSourceType", "") == "MetadataVariableSourceDefinition":
                    definition["filter"] = callback(definition["filter"], "Variable: %s" % var_name, "Metrics")

        else:
            for panel in dash["panels"]:
                if panel["viewerType"] in ("title", "text"):
                    continue
                panel_name = panel.get("name")
                if (panel["queryString"] != ""):
                    panel["queryString"] = callback(panel["queryString"], "Panel: %s" % panel_name, "Logs")
                else:
                    for mquery in panel["metricsQueries"]:
                        mquery["query"] = callback(mquery["query"], "Panel: %s" % panel_name, "Metrics")

    @classmethod
    def _processs_saved_search_queries(cls, search, callback):
        if "searchQuery" in search:
            search["searchQuery"] = callback(search["searchQuery"], "SavedSearch: %s" % search['name'], "Logs")
        else:
            search['search']["queryText"] = callback(search['search']["queryText"], "SavedSearch: %s" % search['name'], "Logs")
            if "viewStartTime" in search["search"]:
                search["search"]["viewStartTime"] = None

    @classmethod
    def process_queries(cls, folder, callback):
        for dash in folder["children"]:
            if dash["type"] in ("Report", "Dashboard", "DashboardSyncDefinition", "MewboardSyncDefinition", "DashboardV2SyncDefinition"):
                cls._process_dashboard_queries(dash, callback)
            elif dash["type"] in ("Search", "SavedSearchWithScheduleSyncDefinition"):
                cls._processs_saved_search_queries(dash, callback)
            elif dash["type"] in ("Folder", "FolderSyncDefinition"):
                cls.process_queries(dash, callback)


class WholePrefixParameterSubstitutionMixin(BaseSubstitutionStrategy):

    source_category_regex = r'\b(?P<expr>(?:_sourceCategory)\s*=\s*(?:\"[\w\*\-\/\s]+\"|[\w\*\-\/]+))'
    metric_param = "metricsrc"
    log_param = "logsrc"

    def _get_substition_expressions(self, queryString, regex):
        matched_params = re.findall(regex, queryString, flags=re.IGNORECASE)

        substitution_expr = set()
        for param in matched_params:
            param = param.strip()
            param = re.escape(param)
            expr = param.replace("\\ ", "\s*")
            substitution_expr.add(expr)
            self.log.debug("After replacement with regex: %s result: %s" % (expr, re.sub(expr, "$$logparam ", queryString[: 100], flags=re.I)))

        return substitution_expr

    def _get_param_name(self, text, mapping):
        num = 0
        param_name = "%s%s" % (text, "" if num == 0 else num)
        while (param_name in mapping):
            num += 1
            param_name = "%s%s" % (text, "" if num == 0 else num)

        return param_name

    def replace_param_callback(self, query_string, location_text, query_type):
        self.log.debug("CHECKING %s" % location_text)
        # case if space commes first
        # if \s* comes first

        with_sc = self._get_substition_expressions(query_string, self.source_category_regex)
        for expr in with_sc:
            unique_expr = expr.replace("\s*", "").lower()
            if expr in self.reverse_param_mapping:
                param_name = self.reverse_param_mapping[expr]
                query_string = re.sub(expr, "$$%s " % param_name, query_string, flags=re.IGNORECASE)
            else:
                if unique_expr in self.reverse_param_mapping:
                    param_name = self.reverse_param_mapping[unique_expr]
                else:
                    param_name = self._get_param_name(self.log_param if query_type == "Logs" else self.metric_param, self.param_mapping)
                    self.log.debug("found new params %s: query: %s location: %s" % (expr, query_string, location_text))
                    self.param_mapping[param_name] = [unique_expr]
                    self.reverse_param_mapping[unique_expr] = param_name

                if expr not in self.param_mapping[param_name]:
                    self.param_mapping[param_name].append(expr)
                self.reverse_param_mapping[expr] = param_name
                query_string = re.sub(expr, "$$%s " % param_name, query_string, flags=re.IGNORECASE)
            self.appended_params.add(param_name)

        # existing params
        return query_string

    def set_source_parameters(self):
        self.appManifestDict["parameters"] = []
        self.process_queries(self.appDict, self.replace_param_callback)

        self.appjson = json.dumps(self.appDict, indent=4)
        without_sc_for_jsonstr = r'(?P<expr>(?:_source|_sourceName|_sourceHost|_collector|_sourceCategory)\s*=\s*(?:\\"[\w\*\-\s\/]+\\"|[\w\*\-\/]+)(?:(?i:\s+OR\s+|\s+AND\s+)(?:_source|_sourceName|_sourceHost|_collector|_sourceCategory)\s*=\s*(?:\\"[\w\*\-\/\s]+\\"|[\w\*\-\/]+))*)'
        without_sc_expr = set([e.replace('\s*', " ") for e in
                               re.findall(without_sc_for_jsonstr, self.appjson, flags=re.IGNORECASE)])

        if len(without_sc_expr) > 0:
            self.log.error("Following metadata is not recommended in queries. For best practices on building queries follow this doc https://docs.google.com/document/d/1xfYfruru0RFWOH23GRrRzosSlepJUTcakLFHLHdpEtc/edit#heading=h.62uucfpoixq2. Once fixed, please rerun this command\n %s" % "\n".join(without_sc_expr))

        new_param_mapping = {}
        for param_name, expr_list in self.param_mapping.items():
            if param_name in self.appended_params or param_name in self.appjson:
                param_type = "LOG" if param_name.startswith(self.log_param) else "METRICS"
                # saves mapping
                self.appManifestDict["parameters"].append(self._createParameter(param_name, param_type))
                new_param_mapping[param_name] = expr_list

        self.current_app_config["param_mapping"] = new_param_mapping
        self.app_config[self.app_config_key] = self.current_app_config
        self.store.set("app_config", self.app_config)

    def test_substitution(self):

        self._get_substition_expressions(
            '(_source="kaudit-data*" AND not !_collector="Kaudit Collector") and _sourcecategory="detections" Or _sourcename=labs/aws* mykeywords| json', self.source_category_regex)

        self._get_substition_expressions(
            '_source="kaudit-data" and not _collector="KauditCollector" and  _sourcecategory="detections" kw1 kw2| json', self.source_category_regex)

        self._get_substition_expressions(
            '(_source="kaudit-data" and not _collector="KauditCollector") and  _sourcecategory="detections" | json', self.source_category_regex)

        self._get_substition_expressions(
            'not ( _source="kaudit-data" and _collector="KauditCollector" ) OR  _sourcecategory="detections" | json', self.source_category_regex)

        self._get_substition_expressions('( not _source="kaudit-data" and _collector="KauditCollector" ) OR  _sourcecategory="detections" | json', self.source_category_regex)


class AppManifest(WholePrefixParameterSubstitutionMixin):

    def __init__(self, filepath, categories, author, help_url):
        super(AppManifest, self).__init__()
        # cfg = Config()
        # root_dir = os.path.dirname(os.path.abspath(__file__))
        # base_config_path = os.path.join(root_dir, "metadata.yaml")
        # self.base_config = cfg.read_config(base_config_path)
        self.appjson = get_file_data(filepath)
        self.author = author
        self.help_url = help_url
        self.sourceFilePath = filepath
        self.app_config_key = get_app_config_key(filepath)
        self.categories = categories
        if USER.is_partner and MANDATORY_CATEGORY_FOR_PARTNER_APPS not in self.categories:
            self.categories.append(MANDATORY_CATEGORY_FOR_PARTNER_APPS)
        self.appDict = json.loads(self.appjson)
        dashboard_class = get_test_class(appjson=self.appDict)
        self.dashboards, self.searches = dashboard_class.get_content(self.appDict)
        self.log_queries, self.metric_queries = dashboard_class.extract_queries(self.dashboards)
        self.saved_search_queries = dashboard_class.get_saved_search_queries(self.searches)
        self.app_config = self.store.get("app_config", {})
        self.current_app_config = self.app_config.get(self.app_config_key, {})
        self.param_mapping = self.current_app_config.get("param_mapping", {})  # param name - expr
        self.reverse_param_mapping = {}
        for param, expr_list in self.param_mapping.items():
            for expr in expr_list:
                self.reverse_param_mapping[expr] = param

    def prepAppManifest(self, generate_uuid):
        self.appManifestDict = {
            "name": self.appDict["name"].strip(),
            "description": self.appDict["description"].strip(),
            "version": "1.0",
            "manifestVersion": "0.1",
            "helpURL": "https://help.sumologic.com/?cid=xxxx",
            "hoverText": None,
            "iconURL": "https://s3.amazonaws.com/app_icons/SumoLogic.png",
            "screenshotURLs": [],
            "preview": False,
            "communityURL": "https://support.sumologic.com/hc/en-us/community/topics/200263058-Applications-and-Integrations",
            "requirements": [],
            "requiresInstallationInstructions": False,
            "installationInstructions": None,
            'categories': self.categories,
            "author": "Sumo Logic",
            "parameters": []
        }
        if generate_uuid:
            self.appManifestDict["uuid"] = str(uuid.uuid4())

    def outputManifestFile(self):
        prettyJsonOutput = json.dumps(self.appManifestDict, sort_keys=True, indent=4, separators=(',', ': '))
        manifestFilePath = self.sourceFilePath.replace(".json", ".manifest.json")
        with open(manifestFilePath, 'w') as f:
            f.write(prettyJsonOutput)
        with open(self.sourceFilePath, 'w') as f:
            f.write(self.appjson)
        self.log.info("Manifest file has been generated: %s. You can open and review it." % manifestFilePath)

    def get_manifest(self, filepath):
        manifestjson = get_file_data(filepath)
        self.appManifestDict = json.loads(manifestjson)

    def get_screenshot_urls(self):
        file_ext = "png"
        dest_bucket = "sumologic-app-data-v2"
        screenshot_urls = []
        for dash in self.dashboards:
            appName, dashboard_name = self.appDict["name"].strip(), dash.get("name")
            key = "dashboards/%s/%s.%s" % (slugify_text(appName), slugify_text(dashboard_name), file_ext)
            screenshot_urls.append("https://%s.s3.amazonaws.com/%s" % (dest_bucket, key))

        return screenshot_urls

    def set_manifest_parameters(self):
        manifest_key_mapping = {"help_url": "helpURL"}
        for param in ["categories", "author", "help_url"]:
            new_val = getattr(self, param, None)
            if new_val:
                self.appManifestDict[manifest_key_mapping.get(param, param)] = new_val

        self.appManifestDict["screenshotURLs"] = self.get_screenshot_urls()


class BaseManifestV2(object):

    @classmethod
    def render_template(cls, template_params, input_filepath, output_filepath):
        with open(input_filepath, 'r') as fin:
            src = Template(fin.read())
            result = src.substitute(template_params)
            with open(output_filepath, 'w') as fout:
                fout.write(result)


class AppManifestV2SchemaV2DocOnly(BaseManifestV2):

    schemaVersion = "2.0"
    installable = False
    mandatory_keys = ['schemaVersion', 'name', 'version', 'description', 'author', 'appOverview']

    def create_manifest(self, appname, app_folder, author, categories, docUrl, supporturl, homeurl, description='', force_update=False):
        manifest_filepath = os.path.join(app_folder, "manifest.yaml")
        searchTerms = None
        categories = [categories] if isinstance(categories, (str, bytes)) else categories
        if (not os.path.isfile(manifest_filepath)) or force_update:
            manifest_template_filepath = os.path.join(pathlib.Path(__file__).parent, "templates", "manifest.yaml.v2.tmpl")
            if "Compliance and Security" in categories:
                useCase = ["security"]
            else:
                useCase = ["observability"]
            if "amazon" in appname.lower() or "aws" in appname.lower():
                searchTerms = AMAZON_SEARCH_TERMS
            elif "azure" in appname.lower() or "microsoft" in appname.lower():
                searchTerms = MICROSOFT_SEARCH_TERMS
            elif "google" in appname.lower() or "gcp" in appname.lower():
                searchTerms = GOOGLE_SEARCH_TERMS
            attributes = {}
            attributes["category"] = categories
            attributes["useCase"] = useCase
            attributes["collection"] = ["Hosted"]
            if searchTerms:
                attributes["searchTerms"] = searchTerms
            attributes = yaml.dump(attributes, default_flow_style=False, width=float("inf"))
            manifest_params = {
                "appname": appname,
                "schemaVersion": self.schemaVersion,
                "attributes": attributes,
                "author": author,
                "docUrl": docUrl,
                "supporturl": supporturl,
                "homeurl": homeurl,
                "installable": self.installable,
                "description": description if description else f"The {appname} is a unified logs and metrics app."
            }
            self.render_template(manifest_params, manifest_template_filepath, manifest_filepath)
        return manifest_filepath

    def create_changelog(self, appname, app_folder, force_update=False):
        changelog_filepath = os.path.join(app_folder, "CHANGELOG.md")
        if (not os.path.isfile(changelog_filepath)) or force_update:
            changelog_template_filepath = os.path.join(pathlib.Path(__file__).parent, "templates", "CHANGELOG.md.tmpl")
            changelog_params = {"appname": appname}
            self.render_template(changelog_params, changelog_template_filepath, changelog_filepath)
        return changelog_filepath

    def create_readme(self, appname, app_folder, app_description, force_update=False, **kwargs):
        readme_filepath = os.path.join(app_folder, "README.md")
        if (not os.path.isfile(readme_filepath)) or force_update:
            readme_template_filepath = os.path.join(pathlib.Path(__file__).parent, "templates", "README.md.v2.tmpl")
            readme_params = {
                "appname": appname,
                "appdescription": app_description
            }
            self.render_template(readme_params, readme_template_filepath, readme_filepath)
        return readme_filepath

    def create_assets(self, app_folder):
        assets_folderpath = os.path.join(app_folder, "assets")
        os.mkdir(assets_folderpath)
        assets_template_folderpath = os.path.join(pathlib.Path(__file__).parent, "templates", "assets")
        copytree(assets_template_folderpath, assets_folderpath)
        preview_folder = os.path.join(assets_folderpath, "images", "preview")
        if not os.path.isdir(preview_folder):
            os.mkdir(preview_folder)
        return assets_folderpath


class AppManifestV2SchemaV2AppOnly(AppManifestV2SchemaV2DocOnly):
    schemaVersion = "2.0"
    installable = True

    def create_collection(self, app_folder):
        collection_folderpath = os.path.join(app_folder, "collection")
        resources_folderpath = os.path.join(app_folder, "resources")
        os.mkdir(collection_folderpath)
        os.mkdir(resources_folderpath)
        collection_template_folderpath = os.path.join(pathlib.Path(__file__).parent, "templates", "collection")
        copytree(collection_template_folderpath, collection_folderpath)
        return collection_folderpath


class ConfigGenerator(object):
    # Todo remove older scope variables or replace existing ones
    # Todo check if name is unique already then do not add suffix1
    # assume new variables will be added manually in query itself without variables, ask which variables to add
    source_category_regex = r'\b(?P<expr>(?:_sourceCategory)\s*=\s*(?:\\"[\w\*\-\s\/\{\}]+\\"|[\w\*\-\/\{\}]+))'
    dollar_params_regex = r'(?P<expr>\$\$\w+)'
    param_prefix = "scope_key"
    param_value_prefix = "default_scope_value"

    def __init__(self, output_path):
        self.log = get_logger(__name__, LOG_FILEPATH="/tmp/sumoapptestutils.log",
                              LOG_LEVEL=os.environ.get("LOG_LEVEL", "INFO"))
        self.param_mapping = {}
        self.reverse_param_mapping = {}
        self.param_log_type_mapping = {}
        self.appended_params = set()
        self.app_directory = output_path
        config_file_path = os.path.join(output_path, "config.yaml")
        if os.path.isfile(config_file_path):
            self.existing_configjson = load_yaml_to_json(config_file_path)
            self.existing_params = {get_scope_key_variable_value(mapping): mapping["label"] for mapping in self.existing_configjson['parameters']}
        else:
            self.existing_configjson = {}
            self.existing_params = {}

    def _get_substition_expressions(self, query_string_line, regex):
        matched_params = re.findall(regex, query_string_line, flags=re.IGNORECASE)

        substitution_expr = set()
        for param in matched_params:
            param = param.strip()
            param = re.escape(param)
            expr = param.replace("\\ ", "\s*")
            substitution_expr.add(expr)
            self.log.debug("After replacement with regex: %s result: %s" % (expr, re.sub(expr, "${scope_key}={{${scope_key}}} ", query_string_line[: 100], flags=re.I)))

        return substitution_expr

    def _get_param_name(self, text, mapping):
        num = 0
        param_name = "%s%s" % (text, "" if num == 0 else num)
        while (param_name in mapping):
            num += 1
            param_name = "%s%s" % (text, "" if num == 0 else num)

        if (param_name in self.existing_params):

            new_user_param_name = input("Which of the existing config parameters the above data source expression should map? \n" + '\n'.join(['%s - %s' % (name, label) for name, label in self.existing_params.items()]) + "\n\n If none then press enter >").strip()
            if new_user_param_name:
                param_name = new_user_param_name
        return param_name

    def replace_param_callback(self, query_string_line, location_text, query_type, is_monitor_query=False):
        self.log.debug("CHECKING %s" % location_text)
        # case if space commes first
        # if \s* comes first

        with_sc = self._get_substition_expressions(query_string_line, self.source_category_regex)
        if not with_sc:
            with_sc = self._get_substition_expressions(query_string_line, self.dollar_params_regex)
        for expr in with_sc:
            unique_expr = expr.replace("\s*", "").lower()
            if expr in self.reverse_param_mapping:
                param_name = self.reverse_param_mapping[expr]
            else:
                if unique_expr in self.reverse_param_mapping:
                    param_name = self.reverse_param_mapping[unique_expr]
                else:
                    self.log.info(f"found new data source expression {expr}: query: {query_string_line} query_type: {query_type} location: {location_text}")
                    param_name = self._get_param_name(self.param_prefix, self.param_mapping)
                    self.param_mapping[param_name] = [unique_expr]
                    self.reverse_param_mapping[unique_expr] = param_name

                if expr not in self.param_mapping[param_name]:
                    self.param_mapping[param_name].append(expr)
                self.reverse_param_mapping[expr] = param_name

            self.param_log_type_mapping[param_name] = query_type

            if is_monitor_query:
                default_param_value = self.get_default_scope_value_name(param_name)
                param_name_expression = "${var.%s}=${var.%s} " % (param_name, default_param_value)
            else:
                display_name = self.get_display_name(param_name)
                param_name_expression = "${var.%s}={{${var.%s}}} " % (param_name, display_name)
            query_string_line = re.sub(expr, param_name_expression, query_string_line, flags=re.IGNORECASE)

            self.appended_params.add(param_name)

        return query_string_line

    @classmethod
    def get_display_name(cls, param_name):
        return "%s%s" % (param_name, "_variable_display_name")

    @classmethod
    def get_default_scope_value_name(cls, param_name):
        return param_name.replace(cls.param_prefix, cls.param_value_prefix)

    def set_source_parameters(self):
        configyaml = {}
        self.log.info(f"Total {len(self.appended_params)} config parameters found with mapping: {self.param_mapping}. Map your source categories and label as per above mapping ")
        if len(self.appended_params) > 0:
            configyaml["parameters"] = self.existing_configjson.get("parameters", [])

            for param_name in self.appended_params:
                if not (param_name in self.existing_params):
                    configyaml["parameters"].append(self._createParameter(param_name))

        return configyaml

    def _createParameter(self, param_name):
        return {
            "componentType": "scope",
            "label": "%s data source" % (self.param_log_type_mapping[param_name]),
            "keyTfVar": param_name,  # scope_key1, scope_key2
            "defaultValueTfVar": self.get_default_scope_value_name(param_name)  # default_scope_value1, default_scope_value2
        }

    def get_text_from_lines(self, lines, current_idx, forward_line_num=1, backward_line_num=1, linesep=" "):

        text = ""
        total_num_lines = len(lines)
        # get previous lines
        idx = current_idx - 1
        min_previous_line_offset = current_idx - backward_line_num
        while idx >= 0 and idx < total_num_lines and idx >= min_previous_line_offset:
            text = lines[idx] + linesep + text
            idx -= 1

        # get forward lines
        idx = current_idx + 1
        max_forward_line_offset = current_idx + forward_line_num
        while idx >= 0 and idx < total_num_lines and idx <= max_forward_line_offset:
            text = text + linesep + lines[idx]
            idx += 1

        return text

    def _process_dashboard_queries(self, dashboard_file_path, callback):

        try:
            with open(dashboard_file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            processed_lines = []

            for idx, line in enumerate(lines):
                stripped_line = line.lstrip()
                if re.match("query_string\s*=\s*", stripped_line):
                    # replace scope variables in panel queries
                    previous_four_lines = self.get_text_from_lines(lines, idx, backward_line_num=4)
                    forward_four_lines = self.get_text_from_lines(lines, idx, forward_line_num=4)
                    if re.search("query_type\s*=\s*\"Metrics", previous_four_lines) or re.search("query_type\s*=\s*\"Metrics", forward_four_lines):
                        log_type = "Metrics"
                    else:
                        log_type = "Logs"
                    line = callback(line, "Line no: %d in dashboard.tf for panel" % idx, log_type)
                elif re.match("query\s*=\s*", stripped_line):
                    # replace scope variables in log variable queries
                    line = callback(line, "Line no: %d in dashboard.tf for log_query_variable_source_definition" % idx, "Logs")

                elif re.match("filter\s*=\s*", stripped_line):
                    # replace scope variables in metric variable queries
                    previous_two_lines = self.get_text_from_lines(lines, idx, backward_line_num=2)
                    if re.search("\s*metadata_variable_source_definition\s*", previous_two_lines):
                        line = callback(line, "Line no: %d in dashboard.tf for metadata_variable_source_definition" % idx, "Metrics")
                    else:
                        utils.warn(f"ignoring filter key in line {idx + 1} of dashboards.tf")

                processed_lines.append(line)

            with open(dashboard_file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred while fixing dashboard resource names: {e}")

    def _process_saved_search_queries(self, log_search_file_path, callback):
        # replace scope variables in log search queries
        try:
            with open(log_search_file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            processed_lines = []
            for idx, line in enumerate(lines):
                stripped_line = line.lstrip()
                if re.match("query_string\s*=\s*", stripped_line):
                    line = callback(line, "Line no: %d in logSearches.tf" % idx, "Logs")

                processed_lines.append(line)

            with open(log_search_file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred while fixing log search resource names: {e}")

    def _process_monitor_queries(self, monitor_file_path, callback):
        # replace scope variables in monitor queries
        try:
            with open(monitor_file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            monitor_type = None
            processed_lines = []
            for idx, line in enumerate(lines):
                stripped_line = line.lstrip()
                if re.match("monitor_type\s*=\s*\"Logs\"", stripped_line):
                    monitor_type = "Logs"
                elif re.match("monitor_type\s*=\s*\"Metrics\"", stripped_line):
                    monitor_type = "Metrics"
                elif re.match("monitor_type\s*=\s*\"Slo\"", stripped_line):
                    raise Exception(f"Unsupported monitor type SLO in line num: {idx} in monitors.tf")
                if re.match("query\s*=\s*", stripped_line):
                    line = callback(line, "Line no: %d in monitor.tf" % idx, monitor_type, is_monitor_query=True)

                processed_lines.append(line)

            with open(monitor_file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred while fixing monitor resource names: {e}")

    def create_dashboard_scope_variables(self, config_parameters):
        # add scope dashboard variables in dashboards
        variables_text = ""
        for parameter in config_parameters.get("parameters", []):
            if parameter["componentType"] != "scope":
                continue
            scope_key_variable_display_name = ConfigGenerator.get_display_name(parameter["keyTfVar"])
            default_value_of_scope_key_variable = parameter["defaultValueTfVar"]
            variables_text += f'  variable {{\n'
            variables_text += '    allow_multi_select = "false"\n'
            variables_text += f'    default_value      = var.{default_value_of_scope_key_variable}\n'
            variables_text += f'    display_name = var.{scope_key_variable_display_name}\n'

            variables_text += '    hide_from_ui       = "false"\n'
            variables_text += '    include_all_option = "true"\n'
            variables_text += f'    name = var.{scope_key_variable_display_name}\n'

            variables_text += f'    source_definition {{\n'
            variables_text += f'      csv_variable_source_definition {{\n'
            variables_text += f'        values = "${{var.{default_value_of_scope_key_variable}}}"\n'
            variables_text += '      }\n'
            variables_text += '    }\n'
            variables_text += '  }\n\n'

        return variables_text

    def add_scope_variables(self, dashboard_file_path, config_parameters):
        # add scope query parameter in log searches
        try:
            scope_variable_text = self.create_dashboard_scope_variables(config_parameters)
            with open(dashboard_file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            processed_lines = []
            previous_line_has_metadata_variable_source_definition = False
            for idx, line in enumerate(lines):
                stripped_line = line.lstrip()
                if re.match("layout\s*{", stripped_line):
                    processed_lines.append(scope_variable_text)
                processed_lines.append(line)

            with open(dashboard_file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred while fixing dashboard resource names: {e}")

    def add_scope_query_parameters(self, log_search_file_path, config_parameters):
        try:

            with open(log_search_file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            processed_lines = []
            for idx, line in enumerate(lines):
                stripped_line = line.lstrip()
                if re.match("query_string\s*=\s*", stripped_line):
                    # filtering config parameters so that one does not create all the variables in log search even if it's not used
                    filtered_config_parameters = {
                        "parameters": [parameter for parameter in config_parameters.get("parameters", []) if f"{parameter['keyTfVar']}_variable_display_name" in stripped_line]
                    }
                    query_variable_text = self.create_log_search_scope_query_parameters(filtered_config_parameters)
                    processed_lines.append(query_variable_text)
                processed_lines.append(line)

            with open(log_search_file_path, 'w', encoding='utf-8') as file:
                file.writelines(processed_lines)
        except Exception as e:
            utils.error(f"Error: An unexpected error occurred while fixing log search resource names: {e}")

    def create_log_search_scope_query_parameters(self, config_parameters):
        variables_text = ""
        for parameter in config_parameters.get("parameters", []):
            if parameter["componentType"] != "scope":
                continue
            scope_key_variable = parameter["keyTfVar"]
            scope_key_variable_display_name = ConfigGenerator.get_display_name(scope_key_variable)
            default_value_of_scope_key_variable = parameter["defaultValueTfVar"]
            variables_text += f'  query_parameter {{\n'
            variables_text += '    data_type   = "ANY"\n'
            variables_text += f'    description = "{parameter["label"]}"\n'
            variables_text += f'    name = var.{scope_key_variable_display_name}\n'
            variables_text += f'    value = "${{var.{default_value_of_scope_key_variable}}}"\n'
            variables_text += '  }\n\n'

        return variables_text

    def process_queries(self, app_folder_name):
        # assuming in v2 app folder name is same as app name
        if app_folder_name in TestTfDashboards.APPS_WITHOUT_CONFIG_PARAMS:
            utils.info(f"{app_folder_name} uses hardcoded metadata, no config.yaml required")
            return {}

        dashboard_file_path = os.path.join(self.app_directory, "resources", "dashboards.tf")
        log_search_file_path = os.path.join(self.app_directory, "resources", "logSearches.tf")

        if os.path.isfile(dashboard_file_path):
            self._process_dashboard_queries(dashboard_file_path, self.replace_param_callback)
        if os.path.isfile(log_search_file_path):
            self._process_saved_search_queries(log_search_file_path, self.replace_param_callback)

        # after processing all the queries, need to get the config parameters
        config_parameters = self.set_source_parameters()

        # adding the config parameters in the dashboards and log searches
        if os.path.isfile(dashboard_file_path):
            self.add_scope_variables(dashboard_file_path, config_parameters)
            self.check_metadata_scopes(dashboard_file_path)

        if os.path.isfile(log_search_file_path):
            self.add_scope_query_parameters(log_search_file_path, config_parameters)
            self.check_metadata_scopes(log_search_file_path)

        return config_parameters

    def process_monitor_folder_queries(self, app_name=None):
        if app_name in TestTfDashboards.APPS_WITHOUT_CONFIG_PARAMS:
            utils.info(f"{app_name} uses hardcoded metadata, no config.yaml required")
            return {}

        monitors_tf_path = os.path.join(self.app_directory, "resources", "monitors.tf")

        if os.path.isfile(monitors_tf_path):
            self._process_monitor_queries(monitors_tf_path, self.replace_param_callback)

        # after processing all the queries, need to get the config parameters
        config_parameters = self.set_source_parameters()

        # adding the config parameters in the monitors
        if os.path.isfile(monitors_tf_path):
            self.check_metadata_scopes(monitors_tf_path)

        return config_parameters

    def check_metadata_scopes(self, filepath):
        with open(filepath, 'r', encoding='utf-8') as file:
            file_content = file.read()
        metadata_scope_expr_not_replaced = r'(?P<expr>(?:_source|_sourceName|_sourceHost|_collector|_sourceCategory)\s*=\s*(?:\\"[\w\*\-\s\/]+\\"|[\w\*\-\/]+)(?:(?i:\s+OR\s+|\s+AND\s+)(?:_source|_sourceName|_sourceHost|_collector|_sourceCategory)\s*=\s*(?:\\"[\w\*\-\/\s]+\\"|[\w\*\-\/]+))*)'
        metadata_scope_expr_not_replaced = set([e.replace('\s*', " ") for e in
                                                re.findall(metadata_scope_expr_not_replaced, file_content, flags=re.IGNORECASE)])

        if len(metadata_scope_expr_not_replaced) > 0:
            self.log.error("Following metadata is not recommended in queries %s. For best practices on building queries follow this doc https://docs.google.com/document/d/1xfYfruru0RFWOH23GRrRzosSlepJUTcakLFHLHdpEtc/edit#heading=h.62uucfpoixq2. Once fixed, please rerun this command\n" % "\n".join(metadata_scope_expr_not_replaced))
