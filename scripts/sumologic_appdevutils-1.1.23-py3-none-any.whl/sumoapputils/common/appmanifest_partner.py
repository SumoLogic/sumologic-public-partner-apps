#!/usr/bin/python
import os
import re
from sumoapputils.common.appmanifest import AppManifestV2SchemaV2AppOnly
from sumoapputils.appdev import utils


class AppManifestV2SchemaV2PartnerAppOnly(AppManifestV2SchemaV2AppOnly):
    def create_readme(self, appname, app_folder, app_description, force_update=False, **kwargs):
        output_filepath = os.path.join(app_folder, "README.md")
        if (not os.path.isfile(output_filepath)) or force_update:
            input_filepath = os.path.join(kwargs["input_path"], "README.md")

            output_content = []
            pattern = r"\[[^\]]+\]\s*\((\s*[^)]+\s*)\)"
            patternc = re.compile(pattern)
            replaces_path = f"https://github.com/SumoLogic/sumologic-public-partner-apps/tree/master/src/{app_folder.split('/').pop()}/resources/"
            with open(input_filepath, 'r') as fin:
                for line in fin:
                    pattern_match = patternc.findall(line)
                    if pattern_match:
                        for item in set(pattern_match):
                            item = item.strip()
                            if "resources/" in item:
                                result = item.replace("resources/", replaces_path)
                                line = line.replace(item, result)
                            elif not item.startswith("#"):
                                utils.warn(f"Found relative link: {item} in README.md in line {line}")
                    output_content.append(line)

            with open(output_filepath, 'w') as fout:
                fout.write(''.join(output_content))

        return output_filepath
