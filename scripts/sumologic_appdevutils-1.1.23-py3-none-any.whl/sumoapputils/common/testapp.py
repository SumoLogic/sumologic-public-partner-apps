import importlib
from datetime import datetime, timedelta, timezone
from requests.adapters import HTTPAdapter
from urllib3.util import Retry
import time
import copy
import json
import csv
import xml.etree.ElementTree as ET
import unittest
import requests
import inspect
import six
import os
import re
import base64
import yaml
from collections import defaultdict
from sumologic import SumoLogic
import semver
from PIL import Image
from bs4 import BeautifulSoup
from functools import reduce, wraps
from abc import abstractmethod, ABCMeta
from sumoappclient.provider.factory import ProviderFactory
from sumoapputils.common.utils import EXCLUDED_APPS_WITHOUT_SC_PARAMS, get_test_logger, slugify, load_tf_to_json, \
    load_yaml_to_json, APP_CATEGORIES, account_type_mapping, get_scope_key_variable_value, get_scope_key_variable_default_value
from sumoapputils.appdev.actions.keepachangelog_handler import KeepachangelogHandler
from sumoapputils.appdev.actions.verify_upload import VerifyUploadAction
from sumoapputils.appdev import utils


# to avoid circular import
sumoapputils_module = importlib.import_module("sumoapputils")

logger = get_test_logger()


def skip_test_wrapper(f):
    @wraps(f)
    def wrapper(self, *args, **kwargs):
        test_function_name = f.__name__
        # skip test configuration is available only for v2 apps
        if self.appname and (self.appname in self.test_config_map) and (self.test_config_map[self.appname].get(
                "skip_tests") and f.__name__ in self.test_config_map[self.appname]["skip_tests"]):
            logger.info(f"Skipping test: {test_function_name} for app: {self.appname}")
            return
        return f(self, *args, **kwargs)

    return wrapper


def timeit(func):
    @wraps(func)
    def timeit_wrapper(*args, **kwargs):
        start_time = time.perf_counter()
        try:
            result = func(*args, **kwargs)
            return result
        finally:
            end_time = time.perf_counter()
            total_time = end_time - start_time
            # first item in the args, ie `args[0]` is `self`
            logger.info(f'Function {func.__name__}{args} {kwargs} Took {total_time:.4f} seconds')

    return timeit_wrapper


@six.add_metaclass(ABCMeta)
class TestApp(unittest.TestCase):
    COMMUNITY_URL = "https://support.sumologic.com/hc/en-us/community/topics/200263058-Applications-and-Integrations"
    MAX_FILE_SIZE = 5 * 1000 * 1000
    MIN_LOG_FILE_SIZE = 1000
    CUMULATIVE_MAX_FILE_SIZE = 100 * 1000 * 1000
    datetime_terms = ["week", "previous_week", "month", "previous_month", "relative", "RelativeTimeRangeBoundary",
                      "yesterday", "today", "Last"]
    HARDCODED_PARAM_APPS_FOLDER = (
        "InternalVolume", "Audit", "Artifactory", "Enterprise_Audit_Collector_Data_Forwarding",
        "Enterprise_Audit_Content_Management", "Enterprise_Audit_Security_Management",
        "Enterprise_Audit_User_role_Management")
    EXCLUDED_PANEL_TYPES = ("TextPanel", "EventsOfInterestScatterPanel", "ServiceMapPanel")
    LOG_QUERY_VALIDATION_STATUS = ["GATHERING RESULTS", "DONE GATHERING RESULTS", "GATHERING RESULTS FROM SUBQUERIES"]
    METRIC_QUERY_VALIDATION_STATUS = ["metrics:no_results", "metrics:row_no_results"]
    TEST_CONFIG_PATH = None

    def __init__(self, manifestfile, appfile, deployment_name,
                 access_id, access_key, isTfApp, *args, **kwargs):
        super(TestApp, self).__init__(*args, **kwargs)
        self.HELP_HOME_URL = "https://help.sumologic.com/"
        self.S3_URL_PREFIX = "https://s3.amazonaws.com/"
        self.ICON_URL_PREFIX = (
            "https://app_icons.s3.amazonaws.com", self.S3_URL_PREFIX,
            "https://sumologic-partner-appsdata.s3.amazonaws.com")
        self.SCREENSHOT_URL_PREFIX = ("https://sumologic-app-data.s3.amazonaws.com", self.S3_URL_PREFIX,
                                      "https://sumologic-partner-appsdata.s3.amazonaws.com",
                                      "https://sumologic-app-data-v2.s3.amazonaws.com")
        self.terraform_path = os.environ.get("TERRAFORM_PATH", None)
        self.manifestfile = manifestfile
        self.appfile = appfile
        self.localappfoldername = os.path.basename(os.path.dirname(os.path.dirname(appfile)))
        self.deployment_name = deployment_name
        self.access_id = access_id
        self.access_key = access_key
        self.appdir = os.path.dirname(self.manifestfile)
        self.test_config_map = self.get_test_config_map()
        self.manifestjson = self.get_manifest_json(manifestfile)
        try:
            self.app_description = self.manifestjson["description"]
            self.appname = self.manifestjson["name"]
        except KeyError as e:
            raise Exception("%s: InitError: Required Params %s are missing from json " % (self.appname, e))

        # initialize common variables which will be initialized in derived classes
        self.dashboards = self.searches = self.monitors = []
        self.log_queries = self.metric_queries = self.saved_search_queries = []
        self.monitor_log_queries = self.monitor_metric_queries = []
        self.queryparams = []

        # initialize sumologic client
        self.sumologic_cli = SumoLogic(
            self.access_id,
            self.access_key,
            sumoapputils_module.appdev.utils.get_endpoint(self.deployment_name)
        )
        # adding retry logic in sumologic python client
        RETRIED_STATUS_CODES = [502, 503, 504, 429]
        # including POST in default whitelist
        METHOD_TO_RETRY = ['HEAD', 'GET', 'PUT', 'DELETE', 'OPTIONS', 'TRACE', 'POST']
        MAX_RETRY = 3
        BACKOFF_FACTOR = 1
        retries = Retry(total=MAX_RETRY, backoff_factor=BACKOFF_FACTOR, status_forcelist=RETRIED_STATUS_CODES,
                        allowed_methods=METHOD_TO_RETRY)
        self.sumologic_cli.session.mount('http://', HTTPAdapter(max_retries=retries))
        self.sumologic_cli.session.mount('https://', HTTPAdapter(max_retries=retries))

    #  ***************************************** Common Methods **************************************

    def get_test_config_map(self):
        test_config_map = {}
        test_config_path = self.get_test_config_path()
        if not os.path.isfile(test_config_path):
            return test_config_map
        test_config_json = load_yaml_to_json(test_config_path)
        for app in test_config_json['apps']:
            skipped_errors = [test.strip().lower() for test in app.get("skip_errors", [])]
            skipped_tests = [test.strip().lower() for test in app.get("skip_tests", [])]
            test_config_map[app["name"]] = {
                "skip_tests": skipped_tests,
                "skip_errors": skipped_errors
            }
        return test_config_map

    def get_test_function_name(self):
        all_function_names = [s.frame.f_code.co_name for s in inspect.stack()]
        for funcname in all_function_names:
            if funcname.startswith("test"):
                return funcname

    def assertTrue(self, expr, msg=None, warning=False):
        try:
            super(TestApp, self).assertTrue(expr, msg)
        except AssertionError as e:
            test_function_name = self.get_test_function_name()
            if warning or (self.appname in self.test_config_map and self.test_config_map[self.appname].get(
                    "skip_errors") and test_function_name in self.test_config_map[self.appname]["skip_errors"]):
                logger.info(f"Skipping error for test: {test_function_name} for app: {self.appname}")
                self.add_warning(msg)
            else:
                raise e

    def assertFalse(self, expr, msg=None, warning=False):
        try:
            super(TestApp, self).assertFalse(expr, msg)
        except AssertionError as e:
            test_function_name = self.get_test_function_name()
            if warning or (self.appname in self.test_config_map and self.test_config_map[self.appname].get(
                    "skip_errors") and test_function_name in self.test_config_map[self.appname]["skip_errors"]):
                logger.info(f"Skipping error for test: {test_function_name} for app: {self.appname}")
                self.add_warning(msg)
            else:
                raise e

    def setUp(self):
        self.warnings = []
        self.test_name = self.id().split(".")[-1]

    def add_warning(self, msg):
        self.warnings.append((self, msg))

    def run(self, result):
        obj = super(TestApp, self).run(result)
        result.appname = self.appname
        result.warnings.extend(self.warnings)
        return obj

    def _is_valid_url(self, url, entityname="URL"):
        resp = None
        max_try = 3
        retry = 0
        ssl_verify = True
        while retry < max_try:
            try:
                # using session to avoid 403 forbidden
                # https://stackoverflow.com/questions/38489386/how-to-fix-403-forbidden-errors-when-calling-apis-using-python-requests
                session = requests.Session()
                resp = session.get(url, headers={'User-Agent': 'Mozilla/5.0'}, verify=ssl_verify)
                session.close()
                break
            except requests.exceptions.SSLError as e:
                retry += 1
                ssl_verify = False
            except requests.Timeout as e:
                retry += 1
                logger.error("%s Timeout while getting url %s. retrying...%d" % (
                    self.appname, url, retry))
            except Exception as e:
                self.fail("%s: Invalid %s url: %s error: %s" % (
                    self.appname, entityname, url, e))
                break
        return resp

    def validate_format(self, filepath):
        _, file_extension = os.path.splitext(filepath)
        with open(filepath, 'r') as fp:
            try:
                if file_extension == ".csv":
                    csv.reader(fp)
                    logger.info("%s is a valid %s logfile" % (filepath, file_extension))
                elif file_extension == ".json":
                    try:
                        # whole file is a valid json
                        json.load(fp)
                    except:
                        # each line in the file is a valid json
                        json.loads(fp.readline())
                    logger.info("%s is a valid %s logfile" % (filepath, file_extension))
                elif file_extension == ".xml":
                    ET.parse(filepath)
                    logger.info("%s is a valid %s logfile" % (filepath, file_extension))
                elif file_extension == ".txt":
                    fp.readline()
                    logger.info("%s is a valid %s logfile" % (filepath, file_extension))
                else:
                    return False
            except Exception as e:
                logger.error("Not a valid format", e)
                return False

        return True

    def check_params_in_log_query(self, query_string, location_text):
        if not self.queryparams:
            return True
        func = lambda r, x: r or x in query_string
        has_params_in_query = reduce(func, self.queryparams, False)
        if not has_params_in_query:
            msg = "%s is not using %s" % (
                location_text, ",".join(self.queryparams))
            self.assertTrue(has_params_in_query, msg)

    def check_params_in_metric_query(self, query_string, location_text):
        if not self.queryparams:
            return True
        func = lambda r, x: r or x in query_string
        has_params_in_query = reduce(func, self.queryparams, False) or '#' in query_string
        if not has_params_in_query:
            msg = "%s is not using %s" % (
                location_text, ",".join(self.queryparams))
            self.assertTrue(has_params_in_query, msg)

    def check_default_lookup_in_query(self, query_string, location_text):
        hasgeo = "geo://default" in query_string
        self.assertTrue(not hasgeo, "%s should use geo://location" % location_text)
        hasmetro_code = "metro_code" in query_string
        self.assertTrue(not hasmetro_code, "%s should not use metro_code" % location_text)
        hasarea_code = "area_code" in query_string
        self.assertTrue(not hasarea_code, "%s should not use area_code" % location_text)

    def check_external_lookups(self, query_string, location_text):
        SUMO_LOOKUPS = {"geo://location", "geo://default", "sumo://threat/cs"}
        lookup_regex = r'\s+lookup\s+[\w,\s]+?from\s+(?P<source>.*?)\s+(?=on\s+)'
        matched = re.findall(lookup_regex, query_string, flags=re.IGNORECASE)
        if matched:
            for operator in matched:
                self.assertTrue(operator in SUMO_LOOKUPS, "%s is using external lookup %s" % (location_text, operator),
                                warning=True)

    def check_save_operator(self, query_string, location_text):
        saved_regex = r'\|\s+save\s+(?:append\s+)?(?P<source>.*?)\s?'
        matched = re.findall(saved_regex, query_string, flags=re.IGNORECASE)
        self.assertFalse(matched, "%s is using save operator with files: %s" % (location_text, ",".join(matched)))

    def check_old_threatintel_lookups(self, query_string: str, location_text: str):
        lookup_regex = r'\s*sumo\:\/\/threat\/cs'
        self.assertFalse(re.search(lookup_regex, query_string, flags=re.IGNORECASE),
                         f"Old Threat intel lookup found in {location_text} of query_string: {query_string}")

    def check_threatintel_lookups(self, query_string: str):
        lookup_regex = r'\|\s*threatlookup\s+singleIndicator\s+\w+'
        return re.search(lookup_regex, query_string, flags=re.IGNORECASE)

    def check_threatintel_type_condition(self, query_string: str, location_text: str):
        lookup_regex = [
            r'\|\s*where\s*\(\s*_threatlookup\.type\s*=\s*"ipv4\-addr\:value"\s*or\s*_threatlookup\.type="ipv6\-addr\:value"\s*\)\s*and\s*\!isNull\(\s*_threatlookup\.confidence\s*\)',
            r'\|\s*where\s*_threatlookup\.type\s*=\s*"domain\-name\:value"\s*and\s*\!isNull\(\s*_threatlookup\.confidence\s*\)',
            r'\|\s*where\s*_threatlookup\.type\s*=\s*"url\:value"\s*and\s*\!isNull\(\s*_threatlookup\.confidence\s*\)',
            r'\|\s*where\s*_threatlookup\.type\s*=\s*"email\-add\:value"\s*and\s*\!isNull\(\s*_threatlookup\.confidence\s*\)',
            r'\|\s*where\s*_threatlookup\.type\s*=\s*"file\:hashes\.\'SHA\-256\'"\s*and\s*\!isNull\(\s*_threatlookup\.confidence\s*\)'
        ]
        self.assertTrue(re.search("(" + ")|(".join(lookup_regex) + ")", query_string, flags=re.IGNORECASE),
                        f"Threat intel type condition not found in {location_text} of query_string: {query_string}")

    def check_threatintel_actors_condition(self, query_string: str, location_text: str):
        lookup_regex = r'\|\s*if\s*\(\s*isEmpty\s*\(\s*_threatlookup\.actors\s*\)\s*\,\s*\"Unassigned\"\s*\,\s*_threatlookup\.actors\s*\)'
        self.assertTrue(re.search(lookup_regex, query_string, flags=re.IGNORECASE),
                        f"Threat intel actors condition not found in {location_text} of query_string: {query_string}",
                        warning=True)

    def check_threatintel_confidence_condition(self, query_string: str, location_text: str):
        lookup_regex = r'\|\s*if\s*\(\s*_threatlookup\.confidence\s*>=\s*85\s*\,\s*\"high\"\s*\,\s*if\s*\(\s*_threatlookup\.confidence\s*>=\s*50\s*\,\s*\"medium\"\s*\,\s*if\s*\(\s*_threatlookup\.confidence\s*>=\s*15\s*\,\s*\"low\"\s*\,\s*if\s*\(\s*_threatlookup\.confidence\s*>=\s*0\s*\,\s*\"unverified\"\s*\,\s*\"Unknown\"\s*\)\s*\)\s*\)\s*\)'
        self.assertTrue(re.search(lookup_regex, query_string, flags=re.IGNORECASE),
                        f"Threat intel confidence condition not found in {location_text} of query_string: {query_string}",
                        warning=True)

    def get_docpage_content(self, response):
        content = response.content.decode('utf-8', 'ignore')
        if "window.location.href = \'/docs/integrations" in content:
            soup = BeautifulSoup(content, 'html.parser')
            script = soup.find("script")
            new_url = self.HELP_HOME_URL.strip("/") + script.string.split()[2].strip("'")
            resp = self._is_valid_url(new_url, "HelpURL")
            self.assertTrue(resp.status_code == 200,
                            f"HelpURL: {new_url} throwing {resp.status_code} status_code Reason: {resp.reason}")
            return resp.content.decode('utf-8', 'ignore')
        else:
            return content

    @classmethod
    def get_valid_json(cls, filepath):
        appjson = None
        try:
            with open(filepath) as fp:
                appjson = json.load(fp)
        except BaseException as e:
            raise Exception("InitError: Failed to read json %s" % e)

        return appjson

    @classmethod
    def is_mew_board(cls, dash):
        return dash["type"] in ("Dashboard", "MewboardSyncDefinition", "DashboardV2SyncDefinition")

    @classmethod
    def matchanyterms(cls, terms, text):
        for term in terms:
            if term in text:
                return True
        return False

    @classmethod
    def order_dashboards_by_name(cls, dashboards):
        dashboards = copy.deepcopy(dashboards)
        dashboards = sorted(dashboards, key=lambda x: x.get("name"))
        return dashboards

    @classmethod
    def order_panels_by_name(cls, dashboards):
        dashboards = copy.deepcopy(dashboards)
        for dash in dashboards:
            if cls.is_mew_board(dash):
                if dash.get("rootPanel"):
                    dash["rootPanel"]["panels"] = sorted(dash["rootPanel"]["panels"], key=lambda x: x.get("title"))
                elif "panels" in dash:
                    dash["panels"] = sorted(dash["panels"], key=lambda x: x.get("title"))
            elif "panels" in dash:
                dash["panels"] = sorted(dash["panels"], key=lambda x: x.get("name"))

        return dashboards

    @classmethod
    def order_searches_by_name(cls, searches):
        searches = copy.deepcopy(searches)
        searches = sorted(searches, key=lambda x: x.get("name"))
        return searches

    @timeit
    def run_sumo_log_queries(self, batch_size: int, sleep_duration: int, fromTime: datetime, toTime: datetime):
        num_log_panel_queries = len(self.log_queries)
        if num_log_panel_queries == 0:
            return
        logger.info(f"Running {num_log_panel_queries} panel queries in batch_size: {batch_size}")
        count = 0
        success_count = 0
        for query_batch in [self.log_queries[i:i + batch_size] for i in range(0, num_log_panel_queries, batch_size)]:
            for _, panel_name, dash_name, _, _, query_string_with_variable_replaced in query_batch:
                try:
                    count += 1
                    logger.debug(f"Running panel query_num: {count}")
                    search_job = self.sumologic_cli.search_job(
                        query_string_with_variable_replaced, fromTime.isoformat(timespec="seconds"),
                        toTime.isoformat(timespec="seconds"),
                        timeZone='UTC', autoParsingMode="Manual"
                    )
                    status = self.sumologic_cli.search_job_status(search_job)
                except Exception as err:
                    self.assertTrue(False,
                                    f"Panel: {panel_name} in Dashboard: {dash_name} Failed to run log query: {query_string_with_variable_replaced} error: {err}",
                                    warning=True)
                else:
                    self.assertTrue(status.get("state") in self.LOG_QUERY_VALIDATION_STATUS,
                                    f"Panel: {panel_name}in Dashboard: {dash_name} Failed to run log query: {query_string_with_variable_replaced} status: {status}")
                    success_count += (1 if status.get("state") in self.LOG_QUERY_VALIDATION_STATUS else 0)

            time.sleep(sleep_duration)

        logger.info(
            f"Total panel queries: {num_log_panel_queries} Total failed queries: {num_log_panel_queries - success_count}")

    @timeit
    def run_sumo_saved_search_queries(self, batch_size: int, sleep_duration: int, fromTime: datetime, toTime: datetime):
        num_saved_search_queries = len(self.saved_search_queries)
        if num_saved_search_queries == 0:
            return
        logger.info(f"Running {num_saved_search_queries} saved log search queries in batch_size: {batch_size}")
        count = 0
        success_count = 0
        for query_batch in [self.saved_search_queries[i:i + batch_size] for i in
                            range(0, num_saved_search_queries, batch_size)]:
            for _, search_name, query_string_with_variable_replaced, parsing_mode in query_batch:
                try:
                    count += 1
                    logger.debug(f"Running saved log search query_num: {count}")
                    search_job = self.sumologic_cli.search_job(
                        query_string_with_variable_replaced, fromTime.isoformat(timespec="seconds"),
                        toTime.isoformat(timespec="seconds"),
                        timeZone='UTC', autoParsingMode=parsing_mode
                    )
                    status = self.sumologic_cli.search_job_status(search_job)
                except Exception as err:
                    self.assertTrue(False,
                                    f"SavedSearch {search_name} Failed to run log query: {query_string_with_variable_replaced} error: {err}",
                                    warning=True)
                else:
                    self.assertTrue(status.get("state") in self.LOG_QUERY_VALIDATION_STATUS,
                                    f"SavedSearch {search_name} Failed to run log query: {query_string_with_variable_replaced} status: {status}")
                    success_count += (1 if status.get("state") in self.LOG_QUERY_VALIDATION_STATUS else 0)

            time.sleep(sleep_duration)

        logger.info(
            f"Total saved log search queries: {num_saved_search_queries} Total failed queries: {num_saved_search_queries - success_count}")

    @timeit
    def run_sumo_metric_queries(self):

        if len(self.metric_queries) == 0:
            return

        # Group panel queries together
        metrics_panel_queries = defaultdict(lambda: [])
        for _, panel_name, dash_name, query_key, panel_key, query_string_with_variable_replaced, _ in self.metric_queries:
            metrics_panel_queries[f"{dash_name}-{panel_key}"].append(
                (query_string_with_variable_replaced, query_key, panel_name, dash_name))

        num_metric_panel_queries = len(metrics_panel_queries)
        logger.info(f"Running {num_metric_panel_queries} metric panel queries")
        count = 0
        success_count = 0

        # test panel queries
        for metrics_panel_query_list in list(metrics_panel_queries.values()):
            count += 1
            panel_name = metrics_panel_queries[2]
            dash_name = metrics_panel_queries[3]
            metric_queries_in_panel = [
                {
                    "rowId": query_key,
                    "query": query_string
                } for query_string, query_key, _, _ in metrics_panel_query_list
            ]
            logger.debug(f"Running panel query_num: {count}")
            try:
                metric_query_result = self.run_metric_query(metric_queries_in_panel)
            except Exception as err:
                self.assertTrue(False,
                                f"Panel: {panel_name} in Dashboard: {dash_name} Failed to run metric queries: {metric_queries_in_panel}  error: {err}",
                                warning=True)
            else:
                all_errors = [error for error in metric_query_result.get("errors", {}).get("errors", []) if
                              error.get("code") not in self.METRIC_QUERY_VALIDATION_STATUS]

                self.assertTrue(len(all_errors) == 0,
                                f"Panel: {panel_name} in Dashboard: {dash_name} Failed to run metric queries: {metric_queries_in_panel} error: {all_errors}")
                success_count += (1 if len(all_errors) == 0 else 0)

        logger.info(
            f"Total metric panel queries: {num_metric_panel_queries} Total failed queries: {num_metric_panel_queries - success_count}")

    @timeit
    def run_sumo_monitor_log_queries(self, batch_size: int, sleep_duration: int, fromTime: datetime, toTime: datetime):
        num_monitor_log_queries = len(self.monitor_log_queries)
        if num_monitor_log_queries == 0:
            return

        logger.info(f"Running {num_monitor_log_queries} log monitor queries in batch_size: {batch_size}")
        count = 0
        success_count = 0
        for query_batch in [self.monitor_log_queries[i:i + batch_size] for i in range(0, num_monitor_log_queries, batch_size)]:
            for query_string, monitor_name, _, _, query_string_with_variable_replaced in query_batch:
                try:
                    count += 1
                    logger.debug(f"Running monitor query_num: {count}")
                    search_job = self.sumologic_cli.search_job(
                        query_string_with_variable_replaced, fromTime.isoformat(timespec="seconds"),
                        toTime.isoformat(timespec="seconds"),
                        timeZone='UTC', autoParsingMode="Manual"
                    )
                    status = self.sumologic_cli.search_job_status(search_job)
                except Exception as err:
                    self.assertTrue(False,
                                    f"Monitor: {monitor_name} Failed to run log query: {query_string_with_variable_replaced} error: {err}",
                                    warning=True)
                else:
                    self.assertTrue(status.get("state") in self.LOG_QUERY_VALIDATION_STATUS,
                                    f"Monitor: {monitor_name} Failed to run log query: {query_string} status: {status}")
                    success_count += (1 if status.get("state") in self.LOG_QUERY_VALIDATION_STATUS else 0)
            time.sleep(sleep_duration)
        logger.info(
            f"Total monitor log queries: {num_monitor_log_queries} Total failed queries: {num_monitor_log_queries - success_count}")

    @timeit
    def run_sumo_monitor_metrics_queries(self, batch_size: int, sleep_duration: int, fromTime: datetime, toTime: datetime):
        num_monitor_metric_queries = len(self.monitor_metric_queries)
        if num_monitor_metric_queries == 0:
            return
        metric_monitor_queries = defaultdict(lambda: [])
        for query_string, monitor_name, monitor_triggers, query_key, query_string_with_variable_replaced in self.monitor_metric_queries:
            metric_monitor_queries[f"{monitor_name}"].append((query_string, monitor_name, monitor_triggers, query_key, query_string_with_variable_replaced))

        num_monitor_metric_queries = len(metric_monitor_queries)
        logger.info(f"Running {num_monitor_metric_queries} metric monitor queries in batch_size: {batch_size}")
        count = 0
        success_count = 0
        for metric_monitor_query_list in list(metric_monitor_queries.values()):
            count += 1
            monitor_name = metric_monitor_queries[2]
            query_key = metric_monitor_queries[3]
            metric_query_in_monitor = [
                {
                    "rowId": query_key,
                    "query": query_string_with_variable_replaced
                } for _, _, _, query_key, query_string_with_variable_replaced in metric_monitor_query_list
            ]
            logger.debug(f"Running monitor query_num: {count}")
            try:
                metric_query_result = self.run_metric_query(metric_query_in_monitor)
            except Exception as err:
                self.assertTrue(False,
                                f"Monitor: {monitor_name} Failed to run metric queries: {metric_query_in_monitor}  error: {err}",
                                warning=True)
            else:
                all_errors = [error for error in metric_query_result.get("errors", {}).get("errors", []) if
                              error.get("code") not in self.METRIC_QUERY_VALIDATION_STATUS]
                self.assertTrue(len(all_errors) == 0,
                                f"Monitor: {monitor_name} Failed to run metric queries: {metric_query_in_monitor} error: {all_errors}")
                success_count += (1 if len(all_errors) == 0 else 0)
        logger.info(
            f"Total monitor metric queries: {num_monitor_metric_queries} Total failed queries: {num_monitor_metric_queries - success_count}")

    def run_metric_query(self, metric_queries):
        params = {
            "queries": metric_queries,
            "timeRange": {
                "type": "BeginBoundedTimeRange",
                "from": {
                    "type": "RelativeTimeRangeBoundary",
                    "relativeTime": "-15m"
                }
            }
        }
        r = self.sumologic_cli.post('/metricsQueries', params)
        return json.loads(r.text)

    #  *************************** Abstract Methods **************************

    @abstractmethod
    def get_test_config_path(self):
        raise NotImplementedError()

    @abstractmethod
    def extract_queries(self, dashboards):
        raise NotImplementedError()

    @abstractmethod
    def get_saved_search_queries(self, searches):
        raise NotImplementedError()

    @abstractmethod
    def get_content(self, folder):
        raise NotImplementedError()

    @abstractmethod
    def get_manifest_json(self, folder):
        raise NotImplementedError()

    @abstractmethod
    def remove_text_panels(self, dashboards):
        raise NotImplementedError()

    #  ********************** Abstract Common Test Methods ********************

    @abstractmethod
    @skip_test_wrapper
    def test_is_deployable(self):
        raise NotImplementedError()

    @abstractmethod
    @skip_test_wrapper
    def test_dashboard_description(self):
        raise NotImplementedError()

    @abstractmethod
    @skip_test_wrapper
    def test_has_category(self):
        raise NotImplementedError()

    @abstractmethod
    @skip_test_wrapper
    def test_has_valid_icon(self):
        raise NotImplementedError()

    @abstractmethod
    @skip_test_wrapper
    def test_has_valid_screenshots(self):
        raise NotImplementedError()

    @abstractmethod
    @skip_test_wrapper
    def test_valid_timerange(self):
        raise NotImplementedError()

    @abstractmethod
    @skip_test_wrapper
    def test_has_valid_dashboard_title(self):
        raise NotImplementedError()

    @abstractmethod
    @skip_test_wrapper
    def test_folder_structure(self):
        raise NotImplementedError()

    @abstractmethod
    @skip_test_wrapper
    def test_has_scheduled_searches(self):
        raise NotImplementedError

    @abstractmethod
    @skip_test_wrapper
    def test_has_valid_parseMode(self):
        raise NotImplementedError

    @abstractmethod
    @skip_test_wrapper
    def test_has_helpdoc_url(self):
        raise NotImplementedError

    #  ******************************* Common Tests **************************

    @skip_test_wrapper
    def test_app_description(self):
        self.assertTrue(self.app_description != "", "App description is empty")

    @skip_test_wrapper
    def test_version_preview_consistent(self):
        if self.manifestjson["preview"]:
            self.assertTrue(self.app_version == "BETA", "App version should be BETA", warning=True)
        else:
            self.assertTrue(semver.VersionInfo.isvalid(self.app_version), "App version should follow semantic versioning")

    @skip_test_wrapper
    def test_all_metadata_replaced_in_query(self):
        # apps having hardcoded params
        logger.warning(
            "These tests do not cover multiple metadata(_sourceCategories,_source etc). They may or may not be replaced")

        for query_string, panel_name, dash_name, _, _, _ in self.log_queries:
            self.check_params_in_log_query(query_string, "Log Panel: %s in Dashboard: %s" % (panel_name, dash_name))

        for query_string, panel_name, dash_name, _, _, _, _ in self.metric_queries:
            self.check_params_in_metric_query(query_string,
                                              "Metric Panel: %s in Dashboard: %s" % (panel_name, dash_name))

        for query_string, search_name, _, _ in self.saved_search_queries:
            self.check_params_in_log_query(query_string, "SavedSearch %s:" % search_name)

    @skip_test_wrapper
    def test_not_using_default_lookup_in_query(self):
        for query_string, panel_name, dash_name, _, _, _ in self.log_queries:
            self.check_default_lookup_in_query(query_string, "Panel: %s in Dashboard: %s" % (panel_name, dash_name))

        for query_string, search_name, _, _ in self.saved_search_queries:
            self.check_default_lookup_in_query(query_string, "SavedSearch: %s" % search_name)

        for query_string, monitor_name, _, _, _ in self.monitor_log_queries:
            self.check_default_lookup_in_query(query_string, "Monitor: %s" % monitor_name)

    @skip_test_wrapper
    def test_has_lookup_operator_from_external_files_in_query(self):

        for query_string, panel_name, dash_name, _, _, _ in self.log_queries:
            self.check_external_lookups(query_string, "Panel: %s in Dashboard: %s" % (panel_name, dash_name))

        for query_string, search_name, _, _ in self.saved_search_queries:
            self.check_external_lookups(query_string, "SavedSearch: %s" % search_name)

        for query_string, monitor_name, _, _, _ in self.monitor_log_queries:
            self.check_external_lookups(query_string, "Monitor: %s" % monitor_name)

    @skip_test_wrapper
    def test_has_save_operator_in_query(self):

        for query_string, panel_name, dash_name, _, _, _ in self.log_queries:
            self.check_save_operator(query_string, "Log Panel: %s in Dashboard: %s" % (panel_name, dash_name))

        for query_string, search_name, _, _ in self.saved_search_queries:
            self.check_save_operator(query_string, "SavedSearch: %s" % search_name)

        for query_string, monitor_name, _, _, _ in self.monitor_log_queries:
            self.check_save_operator(query_string, "Monitor: %s" % monitor_name)

    @skip_test_wrapper
    def test_threatintel_query(self):
        # for Log Queries
        for query_string, panel_name, dash_name, _, _, _ in self.log_queries:
            self.check_old_threatintel_lookups(query_string, "Panel: %s in Dashboard: %s" % (panel_name, dash_name))
            if self.check_threatintel_lookups(query_string):
                self.check_threatintel_type_condition(query_string,
                                                      "Panel: %s in Dashboard: %s" % (panel_name, dash_name))
                self.check_threatintel_actors_condition(query_string,
                                                        "Panel: %s in Dashboard: %s" % (panel_name, dash_name))
                self.check_threatintel_confidence_condition(query_string,
                                                            "Panel: %s in Dashboard: %s" % (panel_name, dash_name))

        # for Saved Searches
        for query_string, search_name, _, _ in self.saved_search_queries:
            self.check_old_threatintel_lookups(query_string, "SavedSearch %s:" % search_name)
            if self.check_threatintel_lookups(query_string):
                self.check_threatintel_type_condition(query_string, "SavedSearch %s:" % search_name)
                self.check_threatintel_actors_condition(query_string, "SavedSearch %s:" % search_name)
                self.check_threatintel_confidence_condition(query_string, "SavedSearch %s:" % search_name)

        for query_string, monitor_name, _, _, _ in self.monitor_log_queries:
            self.check_old_threatintel_lookups(query_string, "Monitor %s:" % monitor_name)
            if self.check_threatintel_lookups(query_string):
                self.check_threatintel_type_condition(query_string, "Monitor %s:" % monitor_name)
                self.check_threatintel_actors_condition(query_string, "Monitor %s:" % monitor_name)
                self.check_threatintel_confidence_condition(query_string, "Monitor %s:" % monitor_name)

    @skip_test_wrapper
    def test_sumo_query(self, relative_time_in_minutes=15):
        toTime = datetime.now(timezone.utc)
        fromTime = toTime + timedelta(minutes=-1 * relative_time_in_minutes)
        # rate limit = 4 api requests per second
        # each api call takes 2 requests hence batch_size is 2
        batch_size = 1
        sleep_duration = 1
        self.run_sumo_log_queries(batch_size, sleep_duration, fromTime, toTime)
        self.run_sumo_saved_search_queries(batch_size, sleep_duration, fromTime, toTime)
        self.run_sumo_metric_queries()
        self.run_sumo_monitor_log_queries(batch_size, sleep_duration, fromTime, toTime)
        self.run_sumo_monitor_metrics_queries(batch_size, sleep_duration, fromTime, toTime)


class TestClassicDashboardsV2(TestApp):

    def __init__(self, *args, **kwargs):
        super(TestClassicDashboardsV2, self).__init__(*args, **kwargs)

        appjson = self.get_valid_json(self.appfile)

        app_parameters = self.manifestjson["parameters"]
        self.app_version = self.manifestjson["manifestVersion"]
        self.queryparams = ["$$%s" % param["parameterId"] for param in app_parameters if
                            param['dataSourceType'] == "LOG" or param['dataSourceType'] == "METRICS"]
        self.dashboards, self.searches = self.get_content(appjson)
        self.remove_text_panels(self.dashboards)
        self.log_queries, self.metric_queries = self.extract_queries(self.dashboards)
        self.saved_search_queries = self.get_saved_search_queries(self.searches)

    @classmethod
    def get_test_config_path(cls):
        from sumoapputils.appdev.utils import apps_v1_repo_path
        return os.path.join(apps_v1_repo_path(), "bin", "testConfig.yaml")

    @classmethod
    def get_manifest_json(self, manifestfile):
        return self.get_valid_json(manifestfile)

    @classmethod
    def remove_text_panels(self, dashboards):
        for dash in dashboards:
            if self.is_mew_board(dash):
                if dash.get("rootPanel"):
                    dash["rootPanel"]["panels"] = [panel for panel in dash["rootPanel"]["panels"] if
                                                   not (panel["panelType"] in (
                                                       "TextPanel", "EventsOfInterestScatterPanel", "ServiceMapPanel"))]

                else:
                    dash["panels"] = [panel for panel in dash["panels"] if not (
                        panel["panelType"] in ("TextPanel", "EventsOfInterestScatterPanel", "ServiceMapPanel"))]

            else:
                dash["panels"] = [panel for panel in dash["panels"] if not (panel["viewerType"] in ("title", "text"))]

    @classmethod
    def get_content(self, folder):
        searches = []
        dashboards = []
        for dash in folder["children"]:
            if dash["type"] in ("DashboardSyncDefinition", "MewboardSyncDefinition", "DashboardV2SyncDefinition"):
                dashboards.append(dash)
            elif dash["type"] == "SavedSearchWithScheduleSyncDefinition":
                searches.append(dash)
            elif dash["type"] == "FolderSyncDefinition":
                d, s = self.get_content(dash)
                searches.extend(s)
                dashboards.extend(d)
        return dashboards, searches

    @classmethod
    def extract_queries(self, dashboards):
        log_queries = []
        metric_queries = []
        for dash in dashboards:
            dash_name = dash.get("name")
            panels = dash["rootPanel"]["panels"] if dash.get("rootPanel") else dash.get("panels", [])
            variables = dash.get("variables")
            dash_variables = []
            if variables:
                for variable in variables:
                    dash_variables.append(
                        (variable.get("name"), variable["defaultValue"] if variable.get("defaultValue") else "*"))

            for panel in panels:
                if panel.get("panelType") in self.EXCLUDED_PANEL_TYPES or panel.get(
                        "Type") in self.EXCLUDED_PANEL_TYPES:
                    continue
                panel_name = panel.get("title")
                panel_key = panel.get("key")
                for query in panel["queries"]:
                    query_key = query["queryKey"]
                    query_string = query["queryString"]
                    query_type = query["queryType"]
                    query_string_with_variable_replaced = copy.copy(query_string)
                    try:
                        # replacing variables {{varname}} with default values
                        for variable_name, variable_default_value in dash_variables:
                            query_string_with_variable_replaced = re.sub(r"{{\s*" + variable_name + r"\s*}}",
                                                                         variable_default_value,
                                                                         query_string_with_variable_replaced)

                        # replacing $$param with _sourceCategory=testappquery
                        query_string_with_variable_replaced = re.sub(r"\$\$[\w]+\s+", "_sourceCategory=testappquery ",
                                                                     query_string_with_variable_replaced)

                    except Exception as e:
                        logger.error(
                            f"Error in creating query_string_with_variable_replaced for query_string: {query_string} error: {e}")

                    if query_type == "Logs":
                        log_queries.append((query_string, panel_name, dash_name, query_key, panel_key,
                                            query_string_with_variable_replaced))
                    else:
                        metric_queries.append((query_string, panel_name, dash_name, query_key, panel_key,
                                               query_string_with_variable_replaced,
                                               query.get("metricsQueryMode", "Advanced")))

        return log_queries, metric_queries

    @classmethod
    def get_saved_search_queries(self, searches):
        search_queries = []
        for search in searches:
            query_parameters = []
            for param in search['search'].get("queryParameters", []):
                query_parameters.append((param['name'], param['value'] if param["value"] else "*"))

            query_string = search['search']["queryText"]
            query_string_with_variable_replaced = copy.copy(query_string)
            try:
                # replacing variables {{varname}} with default values
                for variable_name, variable_default_value in query_parameters:
                    query_string_with_variable_replaced = re.sub(r"{{\s*" + variable_name + r"\s*}}",
                                                                 variable_default_value,
                                                                 query_string_with_variable_replaced)

                # replacing $$param with _sourceCategory=testappquery
                query_string_with_variable_replaced = re.sub(r"\$\$[\w]+\s+", "_sourceCategory=testappquery ",
                                                             query_string_with_variable_replaced)

            except Exception as e:
                logger.error(
                    f"Error in creating query_string_with_variable_replaced for query_string: {query_string} error: {e}")
            search_queries.append(
                (query_string, search["name"], query_string_with_variable_replaced, search['search']["parsingMode"]))
        return search_queries

    @classmethod
    def get_variable_queries(self, dashboards):
        log_variable_queries = []
        metric_variable_queries = []
        for dash in dashboards:
            if self.is_mew_board(dash):
                variables = dash.get("variables")
                if variables:
                    for variable in variables:
                        var_name = variable.get("name")
                        definition = variable.get("sourceDefinition", {})
                        if definition.get("variableSourceType") == "LogQueryVariableSourceDefinition":
                            log_variable_queries.append((definition.get("query"), var_name, dash.get("name")))
                        elif definition.get("variableSourceType") == "MetadataVariableSourceDefinition":
                            metric_variable_queries.append((definition.get("filter"), var_name, dash.get("name")))

        return log_variable_queries, metric_variable_queries

    #  ******************************* New Tests ****************************

    @skip_test_wrapper
    def test_uuid_matches_stored_value(self):
        op_cli = ProviderFactory.get_provider("aws")
        store = op_cli.get_storage("keyvalue", 'partner_app_ids', logger=logger)
        app_name_slug = slugify(self.appname)
        self.assertTrue(self.manifestjson["uuid"] == store.get(app_name_slug))

    @skip_test_wrapper
    def test_has_collectiondoc(self):
        helpdocidelelement = self.manifestjson.get("helpDocIdMap", "")
        self.assertTrue(helpdocidelelement, "This app : " + self.appname + " doesn't contain collectionDocUrl.",
                        warning=True)
        if helpdocidelelement:
            helpdocid = helpdocidelelement.get("en", "")
            docurl = "https://help.sumologic.com/@go/page/" + str(helpdocid)
            resp = self._is_valid_url(docurl, "DocURL")
            if hasattr(resp, "status_code"):
                self.assertTrue(resp.status_code == 200,
                                f"collectionDocUrl: {docurl} Throwing {resp.status_code} status_code Reason: {resp.reason}",
                                warning=True)

    @skip_test_wrapper
    def test_has_community_url(self):
        url = self.manifestjson.get("communityURL", "")
        self.assertTrue(url != "", "Community URL is empty")
        self.assertTrue(url == self.COMMUNITY_URL, "Community URL is incorrect")

    #  ******************************* Implement Common Tests *****************

    @skip_test_wrapper
    def test_has_valid_icon(self):
        url = self.manifestjson.get("iconURL", "")
        self.assertTrue(url != "", "iconURL is empty")
        resp = self._is_valid_url(url, "IconURL")
        if hasattr(resp, "status_code"):
            self.assertTrue(resp.status_code == 200,
                            "Icon URL throwing %d status_code Reason: %s" % (resp.status_code, resp.reason))
            self.assertTrue(url.startswith(self.ICON_URL_PREFIX),
                            "Icon URL: %s is not S3 based" % url)

    @skip_test_wrapper
    def test_has_valid_screenshots(self):
        # Todo check first should be overview
        screenshots = self.manifestjson.get("screenshotURLs", [])
        self.assertTrue(len(screenshots) > 0,
                        "Appname: %s Screenshot URLs are not present" % (self.appname))
        for url in screenshots:
            resp = self._is_valid_url(url, "Screenshot URL")
            if hasattr(resp, "status_code"):
                self.assertTrue(resp.status_code == 200, "screenshot url: %s throws status_code: %s Reason: %s" % (
                    url, resp.status_code, resp.reason))
                self.assertTrue(url.startswith(self.SCREENSHOT_URL_PREFIX),
                                "screenshot url: %s is not S3 based" % url)

    @skip_test_wrapper
    def test_dashboard_description(self):
        err = []
        for dash in self.dashboards:
            if not dash.get("description"):
                err.append(dash.get("name"))

        self.assertFalse(err, "No dashboard description in following dashboards %s" % (",".join(err)))

    @skip_test_wrapper
    def test_has_valid_dashboard_title(self):
        err = []
        for dash in self.dashboards:
            if self.appname not in dash["name"]:
                err.append(dash.get("name"))

        self.assertFalse(err, "Following dashboards %s should follow <appname> - <dashboard title>" % ",".join(err),
                         warning=True)

    @skip_test_wrapper
    def test_folder_structure(self):
        app_dir = os.path.dirname(self.appfile)
        # folder exists
        resource_folder = os.path.join(app_dir, "resources")
        self.assertTrue(os.path.isdir(resource_folder), "no resources folder: %s found" % resource_folder)

        for folder_name in ["logs", "icon", "screenshots"]:
            folder = os.path.join(resource_folder, folder_name)
            self.assertTrue(os.path.isdir(folder), "%s folder does not exists" % folder)
            self.assertFalse(folder_name in ["icon", "screenshots"] and os.listdir(folder) == 0,
                             "%s folder is empty" % folder_name, warning=True)

        file_size_sum = 0
        for root, dirs, files in os.walk(resource_folder):
            for filename in files:
                self.assertFalse(" " in filename, "Whitespace in filename: %s" % filename, warning=True)
                filepath = os.path.join(root, filename)
                # non empty
                filesize = os.stat(filepath).st_size
                self.assertTrue(filesize > 0, f"file: {filepath} is empty")
                parent_dir = os.path.basename(root.strip("/"))
                if parent_dir in ["icon", "screenshots"]:
                    self.assertTrue(filesize < self.MAX_FILE_SIZE, f"size of file: {filepath} < {self.MAX_FILE_SIZE}")
                if parent_dir == "screenshots":
                    im = Image.open(filepath)
                    width, height = im.size
                    logger.info("ImageName: %s Width: %s Height: %s" % (filename, width, height))
                    self.assertTrue(width > 832 and height > 520,
                                    "Dashboard Screenshot dimension should be 832x520 or greater")
                    self.assertTrue(width >= 1400, "For optimal full screen size we recommend width of 1400",
                                    warning=True)
                elif parent_dir == "icon":
                    im = Image.open(filepath)
                    width, height = im.size
                    logger.info("ImageName: %s Width: %s Height: %s" % (filename, width, height))
                    self.assertTrue(72 <= width <= 150 and 72 <= height <= 150, "App Icon dimension should be 72x150")
                elif parent_dir == "logs":
                    self.assertTrue(filesize <= 2 * self.MAX_FILE_SIZE, "%s exceeds 10 MB limit" % filepath)
                    self.assertTrue(filesize > 0, "%s should not be empty" % filepath)
                    self.assertFalse(filesize <= self.MIN_LOG_FILE_SIZE, "%s should be > 1KB and < 10 MB" % filepath,
                                     warning=True)
                    self.assertTrue(self.validate_format(filepath),
                                    "Only .txt, .csv, .xml, .json file formats are allowed")
                file_size_sum += filesize

        self.assertTrue(file_size_sum < self.CUMULATIVE_MAX_FILE_SIZE)

    @skip_test_wrapper
    def test_has_category(self):
        catg = self.manifestjson.get("categories", [])
        self.assertTrue(len(catg) > 0, "No App category found")
        self.assertTrue(len(catg) <= 4, "Maximum 4 App categories allowed")

    @skip_test_wrapper
    def test_has_valid_parseMode(self):
        for dash in self.dashboards:
            panels = dash.get("panels")
            for panel in panels:
                queries = panel.get("queries")
                if queries is not None:
                    for query in queries:
                        parseMode = query.get("parseMode", '').lower()
                        self.assertFalse(parseMode and parseMode != "manual",
                                         f"It's recommended to use manual parseMode in panel {panel.get('title')}  : {parseMode}",
                                         warning=True)

        # for saved searches
        for query_string, search_name, _, parsing_mode in self.saved_search_queries:
            self.assertFalse(parsing_mode and parsing_mode.lower() != "manual",
                             "It's recommended to use manual parseMode in search: " + search_name, warning=True)

        # for metric queries
        for query_string, panel_name, dash_name, query_key, _, _, parsing_mode in self.metric_queries:
            self.assertTrue(parsing_mode == "Advanced",
                            f"Found {parsing_mode} metric query mode in query_key: {query_key} of Panel: {panel_name} in Dashboard: {dash_name}")

    @skip_test_wrapper
    def test_is_deployable(self):
        from sumoapputils.appdev.appdeployapi import push_app_api_v2
        status, response = push_app_api_v2(self.deployment_name, self.appfile, self.manifestfile, self.access_id,
                                           self.access_key)
        self.assertTrue("success" in str(response).lower(),
                        "Unable to deploy app on deployment: %s response: %s" % (
                            self.deployment_name, response))

    @skip_test_wrapper
    def test_valid_timerange(self):

        for dash in self.dashboards:
            if self.is_mew_board(dash):
                self.assertTrue(self.matchanyterms(self.datetime_terms, json.dumps(dash["timeRange"])),
                                "Dashboard: %s does not use relative time" % dash.get("name"))
                panels = dash["rootPanel"]["panels"] if dash.get("rootPanel") else dash.get("panels")
                for panel in panels:
                    self.assertTrue("timeRange" not in panel or panel["timeRange"] is None or self.matchanyterms(
                        self.datetime_terms, json.dumps(panel["timeRange"])),
                        "Panel: %s in Dashboard: %s does not use relative time" % (
                        panel.get("title"), dash.get("name")))
                    self.assertTrue(panel.get("timeRange") is None,
                                    "It's recommended to use dashboard level timerange in Panel: %s in Dashboard: %s" % (
                                        panel.get("title"), dash.get("name")), warning=True)
            else:
                for panel in dash["panels"]:
                    self.assertTrue(
                        "timeRange" not in panel or panel["timeRange"] is None or self.matchanyterms(
                            self.datetime_terms, json.dumps(panel["timeRange"])
                        ),
                        "Panel: %s in Dashboard: %s does not use relative time" % (panel.get("name"), dash.get("name"))
                    )

        for search in self.searches:
            self.assertTrue(search['search']["defaultTimeRange"].startswith("-"),
                            "Saved Search: %s does not use relative time " % search["name"])

    @skip_test_wrapper
    def test_has_scheduled_searches(self):
        for search in self.searches:
            self.assertTrue(search.get("searchSchedule") is None, "SavedSearch %s is scheduled with type %s" % (
                search['name'], json.dumps(search.get('searchSchedule', {}))))

    @skip_test_wrapper
    def test_has_helpdoc_url(self):
        url = self.manifestjson.get("helpURL", "")
        self.assertTrue(url != "", "HelpURL is empty")
        resp = self._is_valid_url(url, "HelpURL")
        # including this test in warning because dochub service may be down
        if hasattr(resp, "status_code"):
            self.assertTrue(resp.status_code == 200,
                            f"HelpURL: {url} throwing {resp.status_code} status_code Reason: {resp.reason}")
            self.assertTrue(resp.url != self.HELP_HOME_URL, f"HelpURL: {url} redirecting to Doc Home Page")
            appname_expr = "%s|%s" % (self.appname, self.appname.replace("-", ""))
            self.assertTrue(re.search(appname_expr, self.get_docpage_content(resp), flags=re.IGNORECASE),
                            f"HelpURL: {url} Does not contains appname", warning=True)

    #  ******************************* Override Common Tests *****************

    @skip_test_wrapper
    def test_all_metadata_replaced_in_query(self):
        if self.localappfoldername in self.HARDCODED_PARAM_APPS_FOLDER:
            return
        super(TestClassicDashboardsV2, self).test_all_metadata_replaced_in_query()

        log_variable_queries, metric_variable_queries = self.get_variable_queries(self.dashboards)

        for query_string, variable_name, dash_name in log_variable_queries:
            self.check_params_in_log_query(query_string,
                                           "Log variable: %s in Dashboard: %s" % (variable_name, dash_name))

        for query_string, variable_name, dash_name in metric_variable_queries:
            self.check_params_in_metric_query(query_string,
                                              "Metric variable: %s in Dashboard: %s" % (variable_name, dash_name))


class TestTfDashboards(TestApp):
    APPS_WITHOUT_CONFIG_PARAMS = ("Data Volume", "Infrequent Data Tier", "Enterprise Search Audit", "Audit",
                                  "Enterprise Audit - Collector & Data Forwarding Management",
                                  "Enterprise Audit - Content Management", "Enterprise Audit - Security Management",
                                  "Enterprise Audit - User & Role Management", "Flex", "Enterprise Audit - Cloud SIEM")
    EXCLUDED_PANEL_TYPES = ("text_panel")
    VALID_STATIC_FILES = ['CHANGELOG.md', 'config.yaml', 'README.md', 'manifest.yaml']
    VALID_TERRAFORM_FILES = ['dashboards.tf', 'folders.tf', 'output.tf', 'variables.tf', 'monitors.tf',
                             'logSearches.tf']

    def __init__(self, *args, **kwargs):
        super(TestTfDashboards, self).__init__(*args, **kwargs)
        assets_folder_exists = os.path.isdir(os.path.join(self.appdir, "assets"))
        otconfig_file_exists = os.path.isfile(os.path.join(self.appdir, "collection", "otSourceConfig.yaml.tmpl"))
        resources_folder_exists = os.path.isdir(os.path.join(self.appdir, "resources"))
        self.isTfApp = assets_folder_exists
        non_empty_otconfig_file = False
        # OTEL app will have non empty otSourceConfig.yaml.tmpl file
        if otconfig_file_exists:
            non_empty_otconfig_file = os.stat(os.path.join(self.appdir, "collection", "otSourceConfig.yaml.tmpl")).st_size != 0
        self.otelv2app = otconfig_file_exists and non_empty_otconfig_file
        self.nonotelv2app = (not non_empty_otconfig_file) and resources_folder_exists and assets_folder_exists
        self.doconlyapp = (not non_empty_otconfig_file) and (not resources_folder_exists) and assets_folder_exists

        self.variablesjson = {}
        self.app_version = self.manifestjson["version"]
        if not self.doconlyapp:
            appjson = load_tf_to_json(self.appfile)
            self.variablesjson = load_tf_to_json(os.path.join(self.appdir, "resources", "variables.tf"))
            logSearchFile = os.path.join(self.appdir, "resources", "logSearches.tf")
            monitorFile = os.path.join(self.appdir, "resources", "monitors.tf")
            logsearchjson = load_tf_to_json(logSearchFile) if os.path.exists(logSearchFile) else {}
            monitorsjson = load_tf_to_json(monitorFile) if os.path.exists(monitorFile) else {}
            self.dashboards, self.searches = self.get_content(appjson, logsearchjson)
            self.monitors = self.get_monitor_content(monitorsjson)
            self.remove_text_panels(self.dashboards)
            self.log_queries, self.metric_queries = self.extract_queries(self.dashboards)
            self.saved_search_queries = self.get_saved_search_queries(self.searches)
            self.monitor_log_queries, self.monitor_metric_queries = self.get_monitor_queries(self.monitors)

            # if v2 app is with config.yaml
            if self.nonotelv2app:
                config_file_path = os.path.join(self.appdir, "config.yaml")
                if os.path.isfile(config_file_path):
                    configjson = load_yaml_to_json(config_file_path)
                    self.queryparams = [get_scope_key_variable_value(mapping) for mapping in configjson['parameters']]

            # if v2 app is with otel collection
            if self.otelv2app:
                exampleyamlfile = f"{self.localappfoldername.lower()}.yaml.example"
                self.examplefile = os.path.join(os.path.dirname(os.path.dirname(self.appdir)), "otelcol-examples",
                                                exampleyamlfile)
                self.otelconfigyaml = load_yaml_to_json(self.examplefile)
                self.queryparams.append("sumo.datasource")

    @classmethod
    def get_test_config_path(cls):
        from sumoapputils.appdev.utils import apps_v2_repo_path
        return os.path.join(apps_v2_repo_path(), "scripts", "testConfig.yaml")

    @classmethod
    def get_manifest_json(self, manifestfile):
        return load_yaml_to_json(manifestfile)

    @skip_test_wrapper
    def test_sumo_metadata_otel_config(self):
        if not self.otelv2app:
            return
        receivers = self.otelconfigyaml["receivers"]
        processors = self.otelconfigyaml["processors"]
        pipelines = self.otelconfigyaml["service"]["pipelines"]
        receivers_used = []
        # receivers used
        for receiver in receivers:
            receivers_used.append(receiver.split('/')[0])
        metric_pipeline_exists = False
        log_pipeline_exists = False
        for pipeline, pipeline_impl in pipelines.items():
            if pipeline.startswith("metrics"):
                metric_pipeline_exists = True
            if pipeline.startswith("logs"):
                log_pipeline_exists = True
        # sumo.datasource
        # _contentType
        sumo_datasource = ""
        content_type = ""
        for processor, processorimpl in processors.items():
            if processor.startswith("resource") and not processor.endswith(
                    "/logs/localhost") and not processor.endswith("/metrics/localhost"):
                for attribute in processorimpl["attributes"]:
                    if attribute["key"].lower() == "sumo.datasource":
                        sumo_datasource = attribute["value"]
                    if attribute["key"].lower() == "_contenttype":
                        content_type = attribute["value"]
        self.assertTrue(sumo_datasource != "", "sumo.datasource missing in otel collection config yaml")
        self.assertTrue(content_type == "OpenTelemetry",
                        "_contentType missing or has incorrect value in otel collection config yaml")
        # _source - for logs and metrics
        # _source name - for metrics
        _source_for_log_arr = []
        _source_for_metrics_arr = []
        _sourcename_for_metrics = ""
        for processor, processorimpl in processors.items():
            if processor.startswith("resource") and processor.endswith("/logs/localhost"):
                for attribute in processorimpl["attributes"]:
                    if attribute["key"].lower() == "_source":
                        _source_for_logs = attribute["value"]
                        _source_for_log_arr = _source_for_logs.split("/")

            elif processor.startswith("resource") and processor.endswith("/metrics/localhost"):
                for attribute in processorimpl["attributes"]:
                    if attribute["key"].lower() == "_source":
                        _source_for_metrics = attribute["value"]
                        _source_for_metrics_arr = _source_for_metrics.split("/")
                    if attribute["key"].lower() == "_sourcename":
                        _sourcename_for_metrics = attribute["value"]
        _source_for_log_arr_length = len(_source_for_log_arr)
        if log_pipeline_exists:
            self.assertTrue(
                _source_for_log_arr_length == 2 and _source_for_log_arr[0] == sumo_datasource and _source_for_log_arr[
                    1] in receivers_used, "Misssing or Invalid value for _source for logs resource processor")
        _source_for_metrics_arr_len = len(_source_for_metrics_arr)
        if metric_pipeline_exists:
            self.assertTrue(
                _source_for_metrics_arr_len == 2 and _source_for_metrics_arr[0] == sumo_datasource and _source_for_metrics_arr[1] in receivers_used,
                "Missing or Invalid value for _source for metric resource processor"
            )
            self.assertTrue(_sourcename_for_metrics == sumo_datasource,
                            "Invalid or missing value for _sourcename for metrics")

        # _sourcename for log
        if log_pipeline_exists:
            for receivername, receiver_impl in receivers.items():
                found_sourcename = False
                if receivername.startswith("windowseventlog"):
                    for operator in receiver_impl["operators"]:
                        if operator["type"] == "add" and operator["field"] == "resource[\"_sourceName\"]" and len(
                                operator["value"]) != 0:
                            found_sourcename = True
                    self.assertTrue(found_sourcename,
                                    "_sourceName tagging missing or invalid for windowseventlog receiver")
                if receivername.startswith("filelog"):
                    for operator in receiver_impl["operators"]:
                        if operator["type"] == "copy" and operator["from"] == "resource[\"log.file.path\"]" and \
                                operator["to"] == "resource[\"_sourceName\"]":
                            found_sourcename = True
                    self.assertTrue(found_sourcename, "_sourceName tagging missing or invalid for filelog receiver")

    @classmethod
    def get_content(self, appjson, logsearchjson):
        dashboards = appjson.get("resource", {}).get("sumologic_dashboard", [])
        searches = logsearchjson.get("resource", {}).get("sumologic_log_search", [])
        dashboards = [dashboards] if isinstance(dashboards, dict) else dashboards
        searches = [searches] if isinstance(searches, dict) else searches
        dashboards = [dash for dash_resource in dashboards for _, dash in dash_resource.items()]
        searches = [search for search_resource in searches for _, search in search_resource.items()]
        return dashboards, searches

    @classmethod
    def extract_queries(self, dashboards):
        log_queries = []
        metric_queries = []

        for dash in dashboards:
            dash_name = dash["title"]
            panels = dash["panel"]
            allPanels = [panels] if isinstance(panels, dict) else panels
            variables = dash.get("variable", [])
            if isinstance(variables, dict):
                variables = [variables]
            dash_variables = []
            for variable in variables:
                dash_variables.append(
                    (variable["name"], variable["default_value"] if variable.get("default_value") else "*"))
            for panel in allPanels:
                paneltype = list(panel.keys())[0]
                if paneltype in self.EXCLUDED_PANEL_TYPES:
                    continue

                queries = panel["sumo_search_panel"]["query"]
                panel_name = panel["sumo_search_panel"]["title"]
                panel_key = panel["sumo_search_panel"]["key"]

                allQueries = [queries] if isinstance(queries, dict) else queries
                for query in allQueries:
                    query_key = query["query_key"]
                    query_string = query["query_string"]
                    query_type = query["query_type"]
                    query_string_with_variable_replaced = copy.copy(query_string)
                    try:
                        # replacing variables {{varname}} with default values
                        for variable_name, variable_default_value in dash_variables:
                            query_string_with_variable_replaced = re.sub(r"{{\s*" + variable_name + r"\s*}}",
                                                                         variable_default_value,
                                                                         query_string_with_variable_replaced)

                        # replacing ${var.scope_key\d*}={{${var.scope_key\d*_variable_display_name}}} with _sourceCategory=testappquery
                        query_string_with_variable_replaced = re.sub(
                            r"\${var.scope_key\d*}\s*=\s*{{\${var.scope_key\d*_variable_display_name}}}\s+",
                            "_sourceCategory=testappquery ", query_string_with_variable_replaced)
                        query_string_with_variable_replaced = re.sub(
                            r"\${var.scope_key\d*}\s*=\s*{{\${var.scope_key\d*}}}\s+", "_sourceCategory=testappquery ",
                            query_string_with_variable_replaced)

                        # replacing \\ in queries
                        # In V2 apps \n inside regex expression in queries do not get escaped hence test_sumo_query test fails due to parsing error
                        query_string_with_variable_replaced = query_string_with_variable_replaced.encode("utf8").decode(
                            'unicode_escape')

                    except Exception as e:
                        logger.error(
                            f"Error in creating query_string_with_variable_replaced for query_string: {query_string} error: {e}")

                    if query_type == "Logs":
                        log_queries.append((query_string, panel_name, dash_name, query_key, panel_key,
                                            query_string_with_variable_replaced))
                    else:
                        metric_queries.append((query_string, panel_name, dash_name, query_key, panel_key,
                                               query_string_with_variable_replaced,
                                               query.get("metrics_query_mode", "Advanced")))

        return log_queries, metric_queries

    @classmethod
    def get_saved_search_queries(self, searches):
        search_queries = []
        for search in searches:

            logsearch_query_parameters = []
            logsearch_parameters = search.get("query_parameter")
            if isinstance(logsearch_parameters, dict):
                logsearch_parameters = [logsearch_parameters]
            if logsearch_parameters:
                for query_param in logsearch_parameters:
                    logsearch_query_parameters.append(
                        (query_param['name'], query_param['value'] if query_param.get("value") else "*"))

            query_string = search["query_string"]
            query_string_with_variable_replaced = copy.copy(query_string)
            try:
                # replacing variables {{varname}} with default values
                for variable_name, variable_default_value in logsearch_query_parameters:
                    query_string_with_variable_replaced = re.sub(r"{{\s*" + variable_name + r"\s*}}",
                                                                 variable_default_value,
                                                                 query_string_with_variable_replaced)

                # replacing ${var.scope_key\d*}={{${var.scope_key\d*_variable_display_name}}} with _sourceCategory=testappquery
                query_string_with_variable_replaced = re.sub(
                    r"\${var.scope_key\d*}\s*=\s*{{\${var.scope_key\d*_variable_display_name}}}\s+",
                    "_sourceCategory=testappquery ", query_string_with_variable_replaced)
                query_string_with_variable_replaced = re.sub(r"\${var.scope_key\d*}\s*=\s*{{\${var.scope_key\d*}}}\s+",
                                                             "_sourceCategory=testappquery ",
                                                             query_string_with_variable_replaced)

                # replacing \\ in queries
                # In V2 apps \n inside regex expression in queries do not get escaped hence test_sumo_query test fails due to parsing error
                query_string_with_variable_replaced = query_string_with_variable_replaced.encode("utf8").decode(
                    'unicode_escape')
            except Exception as e:
                logger.error(
                    f"Error in creating query_string_with_variable_replaced for query_string: {query_string} error: {e}")

            search_queries.append(
                (query_string, search["name"], query_string_with_variable_replaced, search["parsing_mode"]))

        return search_queries

    @classmethod
    def get_monitor_content(self, monitorjson):
        monitors = monitorjson.get("resource", {}).get("sumologic_monitor", [])
        monitors = [monitors] if isinstance(monitors, dict) else monitors
        monitors = [monitor for monitor_resource in monitors for _, monitor in monitor_resource.items()]
        return monitors

    @classmethod
    def replace_monitor_variables(self, query_string, monitor_variables=[]):
        if not monitor_variables:
            return query_string
        result = copy.copy(query_string)
        for var_name, var_default_value in monitor_variables:
            result = re.sub(r"{{\s*" + var_name + r"\s*}}", var_default_value, result)
        return re.sub(r"\$\$[\w]+\s+", "_sourceCategory=testappquery ", result)

    @classmethod
    def get_monitor_queries(self, monitors):
        log_queries = []
        metrics_queries = []

        for monitor in monitors:
            monitor_name = monitor.get("name")
            monitor_type = monitor.get("monitor_type")
            monitor_triggers = monitor.get("triggers")
            variables = monitor.get("variable", [])
            monitor_variables = [(var.get("name"), var.get("defaultValue", "*")) for var in variables]
            query = monitor.get("queries")

            if not isinstance(query, (dict, list)):
                raise ValueError("Invalid query type in monitor")

            queries = [query] if isinstance(query, dict) else query
            target_list = log_queries if monitor_type == "Logs" else metrics_queries

            for q in queries:
                query_string = q.get("query")
                query_key = q.get("row_id")
                query_string_with_variable_replaced = self.replace_monitor_variables(query_string=query_string, monitor_variables=monitor_variables)
                query_string_with_variable_replaced = query_string_with_variable_replaced.encode("utf8").decode('unicode_escape')
                target_list.append((query_string, monitor_name, monitor_triggers, query_key, query_string_with_variable_replaced))
        return log_queries, metrics_queries

    def remove_text_panels(self, dashboards):
        for dash in dashboards:
            panels = dash["panel"]
            updatedPanels = []
            allPanels = [panels] if isinstance(panels, dict) else panels
            for idx, panel in enumerate(allPanels):
                paneltype = list(panel.keys())[0]
                if not (paneltype in self.EXCLUDED_PANEL_TYPES):
                    updatedPanels.append(panel)
            dash["panel"] = updatedPanels[0] if isinstance(panels, dict) else updatedPanels

    @skip_test_wrapper
    def test_has_helpdoc_url(self):
        url = self.manifestjson["author"]["documentationUrl"]
        self.assertTrue(url != "", "HelpURL is empty")
        resp = self._is_valid_url(url, "HelpURL")
        # including this test in warning because dochub service may be down
        if hasattr(resp, "status_code"):
            self.assertTrue(resp.status_code == 200,
                            f"HelpURL: {url} throwing {resp.status_code} status_code Reason: {resp.reason}")
            self.assertTrue(resp.url != self.HELP_HOME_URL, f"HelpURL: {url} redirecting to Doc Home Page")
            appname_expr = "%s|%s" % (self.appname, self.appname.replace("-", ""))
            self.assertTrue(re.search(appname_expr, self.get_docpage_content(resp), flags=re.IGNORECASE),
                            f"HelpURL: {url} Does not contains appname", warning=True)

    @skip_test_wrapper
    def test_valid_timerange(self):
        for dash in self.dashboards:
            if isinstance(dash, dict) and 'title' in dash:
                self.assertTrue(self.matchanyterms(self.datetime_terms, json.dumps(dash["time_range"])),
                                "Dashboard: %s does not use relative time" % dash["title"])
                panels = dash["panel"]
                allPanels = [panels] if isinstance(panels, dict) else panels
                for panel in allPanels:
                    panel_resource = panel["sumo_search_panel"]
                    self.assertTrue(
                        "time_range" not in panel_resource or panel_resource["time_range"] is None or self.matchanyterms(
                            self.datetime_terms,
                            json.dumps(panel_resource["time_range"])
                        ),
                        "Panel: %s in Dashboard: %s does not use relative time" % (panel_resource["title"], dash["title"])
                    )

                    self.assertFalse("time_range" in panel_resource,
                                     "It's recommended to use dashboard level timerange in Panel: %s in Dashboard: %s" % (
                                         panel_resource["title"], dash["title"]), warning=True)
        for search in self.searches:
            self.assertTrue("relative_time_range" in (json.dumps(search["time_range"])),
                            "Saved Search: %s does not use relative time " % search["name"])

    @skip_test_wrapper
    def test_has_valid_parseMode(self):
        # parseMode not exposed in dashboard resource for terraform log queries

        # for metric panels
        for query_string, panel_name, dash_name, query_key, _, _, parsing_mode in self.metric_queries:
            self.assertTrue(parsing_mode == "Advanced",
                            f"Found {parsing_mode} metric query mode in query_key: {query_key} of Panel: {panel_name} in Dashboard: {dash_name}")

        # for saved searches
        for query_string, search_name, _, parsing_mode in self.saved_search_queries:
            self.assertFalse(parsing_mode and parsing_mode.lower() != "manual",
                             "It's recommended to use manual parseMode in search: " + search_name, warning=True)

    @skip_test_wrapper
    def test_has_scheduled_searches(self):
        for search in self.searches:
            self.assertTrue(search.get("schedule") is None, "SavedSearch %s is scheduled with type %s" % (
                search['name'], json.dumps(search.get('schedule', {}))))

    @classmethod
    def get_variable_queries(self, dashboards):
        log_variable_queries = []
        metric_variable_queries = []
        for dash in dashboards:
            if isinstance(dash, dict) and 'variable' in dash and 'name' in dash:
                variables = dash["variable"]
                if isinstance(variables, dict):
                    variables = [variables]
                if variables:
                    for variable in variables:
                        if 'source_definition' in variable:
                            var_name = variable["name"]
                            definition = variable["source_definition"]
                            if "log_query_variable_source_definition" in definition:
                                log_variable_queries.append(
                                    (definition["log_query_variable_source_definition"]["query"],
                                     var_name, dash["name"]
                                     ))
                            elif "metadata_variable_source_definition" in definition:
                                metric_variable_queries.append((
                                    definition["metadata_variable_source_definition"]["filter"], var_name, dash["name"]
                                ))

        return log_variable_queries, metric_variable_queries

    def check_params_in_log_query(self, query_string, location_text):
        metadata_fields = [r"\b_sourcecategory\b", r"\b_source\b", r"\b_collector\b", r"\$\$\w+"]
        found_metadata = [s for s in metadata_fields if re.search(s, query_string.lower())]
        found_metadata_string = ",".join(found_metadata)
        self.assertTrue(len(found_metadata) == 0,
                        "found %s metadata in query_string of %s" % (found_metadata_string, location_text))
        query_scope = query_string.split("|")[0].strip()
        if not self.queryparams:
            return True
        func = lambda r, x: r or (
            re.search('\s*\${\s*var.%s\s*}' % x, query_scope) if not self.otelv2app else x in query_scope)
        has_params_in_query = reduce(func, self.queryparams, False)
        if not has_params_in_query:
            msg = "%s is not using queryparams in %s" % (
                location_text, ",".join(self.queryparams))

            self.assertTrue(has_params_in_query, msg)

    def check_params_in_metric_query(self, query_string, location_text):
        metadata_fields = [r"\b_sourcecategory\b", r"\b_source\b", r"\b_collector\b", r"\$\$\w+"]
        found_metadata = [s for s in metadata_fields if re.search(s, query_string.lower())]
        found_metadata_string = ",".join(found_metadata)
        self.assertTrue(len(found_metadata) == 0,
                        "found %s metadata in query_string of %s" % (found_metadata_string, location_text))
        query_scope = query_string.split("|")[0].strip()
        if not self.queryparams:
            return True
        func = lambda r, x: r or (
            re.search('\s*\${\s*var.%s\s*}' % x, query_scope) if not self.otelv2app else x in query_scope)
        has_params_in_query = reduce(func, self.queryparams, False) or '#' in query_string
        if not has_params_in_query:
            msg = "%s is not using queryparams in %s" % (
                location_text, ",".join(self.queryparams))
            self.assertTrue(has_params_in_query, msg)

    @skip_test_wrapper
    def test_all_metadata_replaced_in_query(self):
        if self.nonotelv2app:
            # apps having hardcoded params
            if self.appname in self.APPS_WITHOUT_CONFIG_PARAMS:
                return
            super(TestTfDashboards, self).test_all_metadata_replaced_in_query()
            log_variable_queries, metric_variable_queries = self.get_variable_queries(self.dashboards)

            for query_string, variable_name, dash_name in log_variable_queries:
                self.check_params_in_log_query(query_string,
                                               "Log variable: %s in Dashboard: %s" % (variable_name, dash_name))

            for query_string, variable_name, dash_name in metric_variable_queries:
                self.check_params_in_metric_query(query_string,
                                                  "Metric variable: %s in Dashboard: %s" % (variable_name, dash_name))

            for query_string, monitor_name, _, _, _ in self.monitor_log_queries:
                self.check_params_in_log_query(query_string, "Monitor: %s" % monitor_name)

            for query_string, monitor_name, _, _, _ in self.monitor_metric_queries:
                self.check_params_in_metric_query(query_string, "Monitor: %s" % monitor_name)

    @skip_test_wrapper
    def test_query_parameter_description(self):
        # test non empty query parameter description
        for search in self.searches:
            if isinstance(search, dict) and 'title' in search:
                query_parameters = search["query_parameter"]
                if isinstance(query_parameters, dict):
                    query_parameters = [query_parameters]
                if query_parameters:
                    for query_paramter in query_parameters:
                        self.assertTrue(0 < len(query_paramter.get("description")) <= 255,
                                        "Log Search's Query Paramters Description length exceeds")

    @skip_test_wrapper
    def test_linked_dashboards(self):
        # test relative path matches valid dashboard name
        for dash in self.dashboards:
            panels = dash.get("panel")
            allPanels = [panels] if isinstance(panels, dict) else panels
            for panel in allPanels:
                panelimpllist = list(panel.values())
                panelimpl = panelimpllist[0]
                self.assertTrue("linked_dashboard" not in panelimpl or panelimpl["linked_dashboard"],
                                "Panel: %s in Dashboard: %s have linked dashboard" % (
                                    panelimpl["title"], dash["title"]))

    @skip_test_wrapper
    def test_mandatory_variables(self):
        if self.doconlyapp:
            return

        # integration_root_dir integration_name integration_description should be present
        integration_root_dir = self.variablesjson.get("variable", {}).get("integration_root_dir", {})
        integration_name = self.variablesjson.get("variable", {}).get("integration_name", {})
        integration_description = self.variablesjson.get("variable", {}).get("integration_description", {})
        self.assertTrue(len(integration_root_dir) > 0, "integration_root_dir is empty")
        self.assertTrue(len(integration_name) > 0, "integration_name is empty")
        self.assertTrue(len(integration_description) > 0, "integration_description is empty")
        self.assertTrue(0 < len(integration_root_dir.get("description")) <= 255,
                        "integration_root_dir Description length exceeeds")
        self.assertTrue(0 < len(integration_name.get("description")) <= 255,
                        "integration_name Description length exceeeds")
        self.assertTrue(0 < len(integration_description.get("description")) <= 255,
                        "integration_description Description length exceeeds")

        # Todo description in variables.tf < 250

    @skip_test_wrapper
    def test_valid_tf_resourcenames(self):
        # Todo check not starting with numbers
        # dashboard resource
        # variable resource
        # folder resource
        # log searches resource
        # monitors.tf
        pass

    @skip_test_wrapper
    def test_variables_description(self):
        if self.doconlyapp:
            return

        variables = self.variablesjson.get("variable", {})
        for variable_name, variable_data in variables.items():
            description = variable_data.get("description", "")
            self.assertTrue(0 <= len(description) <= 255, f"{variable_name} description length exceeds 255 characters")

    @skip_test_wrapper
    def test_has_category(self):
        attributes = self.manifestjson.get("attributes", {})
        catg = attributes.get("category")
        for category in catg:
            self.assertTrue(category in APP_CATEGORIES, "Invalid category: %s found" % category)
        self.assertTrue(len(catg) > 0, "No App category found")
        self.assertTrue(len(catg) <= 4, "Maximum 4 App categories allowed")

        usecases = attributes.get("useCase")
        valid_usecases = ["observability", "security"]
        for usecase in usecases:
            self.assertTrue(usecase in valid_usecases, "Invalid usecase attributes: %s found" % usecase)

        collection_methods = attributes.get("collection")
        valid_collection_methods = ["Hosted", "Installed", "OpenTelemetry"]
        for collection_method in collection_methods:
            self.assertTrue(collection_method in valid_collection_methods,
                            "Invalid collection attribute: %s found" % collection_method)

    # not applicable for v2 apps as app beta not supported private app supported
    @skip_test_wrapper
    def test_version_preview_consistent(self):
        pass

    @skip_test_wrapper
    def test_has_valid_screenshots(self):
        from sumoapputils.appdev.utils import slugify_text
        if self.doconlyapp:
            return
        v2appdir = os.path.dirname(self.manifestfile)
        if self.manifestjson["installable"]:
            dashlist = self.manifestjson["appMedia"]
            for dash in dashlist:
                dashtitle = dash["title"]
                screenshotlocation = dash["location"]
                # removing ./ relative url from screenshot
                screenshotpath = os.path.join(v2appdir, screenshotlocation[2:])
                self.assertTrue(screenshotpath.endswith(".png"), "Dashboard: %s does not have png screenshot" % (
                    dashtitle))
                self.assertTrue(os.path.isfile(screenshotpath),
                                "Dashboard: %s does not have screenshot present in the app" % (dashtitle))
                # test image file name should follow convention based on dashboard title
                expected_imagefile_name = slugify_text(dashtitle) + ".png"
                current_imagefile_name = os.path.basename(screenshotpath)
                self.assertTrue(expected_imagefile_name == current_imagefile_name,
                                "Dashboard: %s has current image filename: %s expected image filename :%s" % (
                                    dashtitle, current_imagefile_name, expected_imagefile_name), warning=True)

                im = Image.open(screenshotpath)
                width, height = im.size
                logger.info("Dashboard: %s Screenshot Width: %s & Height: %s" % (screenshotpath, width, height))
                self.assertTrue(width > 832 and height > 520,
                                "Dashboard Screenshot dimension should be 832x520 or greater")
                self.assertTrue(width >= 1400, "For optimal full screen size we recommend width of 1400", warning=True)

            self.assertTrue(len(self.dashboards) <= len(dashlist), "Number of dashboards <= Number of screenshots")

    @skip_test_wrapper
    def test_dashboard_description(self):

        err_dashboards = []
        for dash in self.dashboards:
            if not dash.get("description"):
                err_dashboards.append(dash["title"])

        self.assertFalse(err_dashboards,
                         "No dashboard description in following dashboards %s" % ",".join(
                             err_dashboards), warning=True)

    @skip_test_wrapper
    def test_has_valid_icon(self):
        v2appdir = os.path.dirname(self.manifestfile)
        iconfile = os.path.join(v2appdir, "assets/images/icon.png")
        self.assertTrue(os.path.isfile(iconfile), "App does not have icon present at the location: %s" % (
            iconfile))
        im = Image.open(iconfile)
        width, height = im.size
        logger.info("For App: %s icon Width: %s & Height: %s" % (self.manifestjson["name"], width, height))
        self.assertTrue(width >= 72 and height >= 72,
                        f"App: {self.manifestjson['name']} icon dimension should be >= 72", warning=True)
        self.assertTrue(width <= 150 and height <= 150,
                        f"App: {self.manifestjson['name']} icon dimension should be <= 150", warning=True)

    @skip_test_wrapper
    def test_has_valid_dashboard_title(self):
        err_dashboards = []
        for dash in self.dashboards:
            if self.appname not in dash["title"]:
                err_dashboards.append(dash["title"])
        self.assertFalse(err_dashboards,
                         "Following dashboards %s should follow <appname> - <dashboard title>" % ",".join(
                             err_dashboards), warning=True)

    @skip_test_wrapper
    def test_terraform_validate(self):
        from sumoapputils.appdev.actions.terraform_validate import TerraformValidate
        if not self.terraform_path:
            self.assertTrue(False, "TERRAFORM_PATH environment variable is not set")
        tf_validate = TerraformValidate()
        tf_validate.execute(app_path=self.appdir, terraform_path=self.terraform_path)

    @skip_test_wrapper
    def test_is_deployable(self):
        from sumoapputils.appdev import state
        from sumoapputils.appdev.actions.upload import UploadAction
        app_name = self.manifestjson["name"]
        state.initialize(self.deployment_name, app_name, "")
        errors = UploadAction().execute()
        error_msg = ""
        if self.deployment_name in errors:
            error_msg = errors[self.deployment_name]
        self.assertTrue(self.deployment_name not in errors, "V2 Deployment failed with error: %s " % (error_msg))

    @skip_test_wrapper
    def test_tfApp_installable(self):
        from sumoapputils.appdev import state
        from sumoapputils.appdev.actions.install_appsv2 import InstallAction
        if self.manifestjson["installable"]:
            app_name = self.manifestjson["name"]
            state.initialize(self.deployment_name, app_name, version=self.manifestjson["version"])
            source_input_mapping = InstallAction.get_config_mapping({
                "name": app_name,
                "version": self.manifestjson["version"],
                "relativeFolderPath": os.path.basename(self.appdir),
                "uuid": None,
                "demo_input_mapping": None
            })
            app_install_status_list = InstallAction().execute(source_input_mapping)
            app_install_status = True
            for dep, status in app_install_status_list.items():
                if status != "":
                    app_install_status = False
                    break
            self.assertTrue(app_install_status,
                            "V2 app install failed. Here is list of error for each deployment: %s " % (
                                app_install_status_list))

    @skip_test_wrapper
    def test_update_v2_app(self):
        if not self.manifestjson["installable"]:
            return
        from sumoapputils.appdev import state
        from sumoapputils.appdev.actions.install_appsv2 import InstallAction
        from sumoapputils.appdev.actions.update_appsv2 import UpdateAction
        from sumoapputils.appdev.actions.version_info_appsv2 import AppsVersionInfo
        full_app_list_path = os.path.join(os.environ.get('SUMO_APPS_V2_REPO_PATH'), "scripts", "full_app_list.yaml")
        data = load_yaml_to_json(full_app_list_path)
        apps = data["apps"]
        for app in apps:
            if self.manifestjson["name"] == app['name']:
                app_uuid = app['uuid']
                app_name = app['name']
                latest_source_input_mapping = InstallAction.get_config_mapping({
                    "name": app_name,
                    "version": self.manifestjson["version"],
                    "relativeFolderPath": app["relativeFolderPath"],
                    "uuid": app_uuid,
                    "demo_input_mapping": []
                })
                prev_versions = app.get('prevVersions')
                if prev_versions:
                    app_update_status_list_final = []
                    app_update_status = True
                    for prev_version in prev_versions:
                        # TODO : dont use state. Arrange and pass the param instead
                        state.initialize(self.deployment_name, app_name, app_uuid, prev_version)
                        version_info_list = AppsVersionInfo().execute(app_name, app_uuid, prev_version)
                        prev_version_config = ""
                        prev_version_manifest = ""
                        for dep, version_response in version_info_list.items():
                            self.assertTrue(version_response[0] != "Failure", f"Error for endpoint {dep} while getting details for App: {app_name} and version {prev_version} with: {version_response[1]} ")
                            if version_response[1]["config"] is not None:
                                prev_version_config = yaml.safe_load(base64.b64decode(version_response[1]["config"]))
                            if version_response[1]["manifest"] is not None:
                                prev_version_manifest = yaml.safe_load(base64.b64decode(version_response[1]["manifest"]))
                        is_installable = prev_version_manifest.get("installable",True)
                        if not is_installable:
                            utils.info(f"App: {app_name} previous_version: {prev_version} is a doc only app, skipping test_update_v2_app test")
                            continue
                        prev_version_demo_input_mapping = []
                        if prev_version_config != "":
                            for params in prev_version_config["parameters"]:
                                param_key = get_scope_key_variable_value(params)
                                param_value = get_scope_key_variable_default_value(params, silent=True)
                                for app_param in app["demo_input_mapping"]:
                                    if param_key == app_param["input_name"]:
                                        param_key_value = app_param["input_name_value"]
                                        prev_version_demo_input_mapping.append({
                                            "input_name": param_key,
                                            "input_name_value": param_key_value
                                        })
                                    if params["componentType"] == "scope" and param_value == app_param["input_name"]:
                                        param_value_val = app_param["input_name_value"]
                                        prev_version_demo_input_mapping.append({
                                            "input_name": param_value,
                                            "input_name_value": param_value_val
                                        })

                        app_install_status_list = InstallAction().execute(prev_version_demo_input_mapping)
                        app_install_status = True
                        for dep, status in app_install_status_list.items():
                            if status != "":
                                app_install_status = False
                                break
                        self.assertTrue(app_install_status, f"V2 app install for previous version: {prev_version} failed in upgrade test. Here is list of error for each deployment: {app_install_status_list}")
                        # update

                        app_update_status_list = UpdateAction().execute(latest_source_input_mapping, self.manifestjson["version"])
                        for dep, status in app_update_status_list.items():
                            if status != "":
                                app_update_status = False
                                break
                        app_update_status_list_final.append(app_update_status_list)
                    # TODO: Create a single list of errors for install errors and update errors and show the status for all the prev versions.
                    self.assertTrue(app_update_status, "V2 app update failed for . Here is list of error for each deployment: %s " % (app_update_status_list_final))
                else:
                    utils.info("No previous version found skipping test_update_v2_app test")

    @skip_test_wrapper
    def test_single_stack_linking_topology(self):
        for dash in self.dashboards:
            self.assertTrue('topology_label_map' in dash, f"Topology not present in {dash.get('title')} dashboard",
                            warning=True)
            self.assertTrue(type(dash.get('topology_label_map', {})) == dict, "Multiple Topologies")

    @skip_test_wrapper
    def test_domain_exists(self):
        for dash in self.dashboards:
            self.assertTrue('domain' in dash, f"Domain not present in {dash.get('title')} dashboard", warning=True)

    @skip_test_wrapper
    def test_no_percentage_for_variables_containing_dots(self):
        for query_string, panel_name, dash_name, _, _, _ in self.log_queries:
            query_scope = query_string.split("|")[0]
            self.assertTrue("%\"" not in query_scope,
                            "Panel: %s in Dashboard: %s contains percentage in query scope" % (panel_name, dash_name))

        for query_string, search_name, _, _ in self.saved_search_queries:
            query_scope = query_string.split("|")[0]
            self.assertTrue("%" not in query_scope,
                            "Saved Search: %s contains percentage in query scope" % (search_name))

        # for monitors
        for query_string, monitor_name, _, _, _ in self.monitor_log_queries:
            query_scope = query_string.split("|")[0]
            self.assertTrue("%" not in query_scope,
                            "Monitor: %s contains percentage in query scope" % (monitor_name))

    @skip_test_wrapper
    def test_valid_ui_json_schema(self):
        v2appdir = os.path.dirname(self.manifestfile)
        uiConfigSchemaPath = os.path.join(v2appdir, "collection", "uiConfigSchema.json")
        if os.path.isfile(uiConfigSchemaPath):
            try:
                uiConfigSchemaJson = self.get_valid_json(uiConfigSchemaPath)
            except:
                self.assertTrue(False, f"Invalid UI json schema: {uiConfigSchemaPath}")
            if self.otelv2app:
                platforms = uiConfigSchemaJson["form"][0]["ui"]["fields"]["agentSetup"]["platforms"]
                self.assertTrue("chef" in platforms, "chef platform not present in uiConfigSchema.json")
                self.assertTrue("ansible" in platforms, "ansible platform not present in uiConfigSchema.json")
                self.assertTrue("puppet" in platforms, "puppet platform not present in uiConfigSchema.json")

    @skip_test_wrapper
    def test_folder_structure(self):
        assets_folder_exists = os.path.isdir(os.path.join(self.appdir, "assets"))
        self.assertTrue(assets_folder_exists, "assets folder should exists in appdir: %s" % (self.appdir))
        changelog_file_exists = os.path.isfile(os.path.join(self.appdir, "CHANGELOG.md"))
        readme_file_exists = os.path.isfile(os.path.join(self.appdir, "README.md"))
        manifest_file_exists = os.path.isfile(os.path.join(self.appdir, "manifest.yaml"))
        self.assertTrue(changelog_file_exists and readme_file_exists and manifest_file_exists,
                        "CHANGELOG.md README.md and manfiest.yaml should exists in appdir: %s" % (self.appdir))
        self.assertTrue(self.has_png_assets(self.appdir), "Assets directory should contain only png files")
        self.assertTrue(self.has_valid_static_files(self.appdir), f"{self.appdir} should contain following static files: {self.VALID_STATIC_FILES}")

        if not self.doconlyapp:
            self.assertTrue(self.has_valid_terraform_files(self.appdir), f"{self.appdir} should contain following static files: {self.VALID_TERRAFORM_FILES}")
            preview_folder_exists = os.path.isdir(os.path.join(self.appdir, "assets", "images", "preview"))
            self.assertTrue(preview_folder_exists,
                            "preview folder should exists in appdir: %s/assets/images/" % (self.appdir))
            resources_folder_path = os.path.join(self.appdir, "resources")
            dashboards_file_exists = os.path.isfile(os.path.join(resources_folder_path, "dashboards.tf"))
            folders_file_exists = os.path.isfile(os.path.join(resources_folder_path, "folders.tf"))
            output_file_exists = os.path.isfile(os.path.join(resources_folder_path, "output.tf"))
            variables_file_exists = os.path.isfile(os.path.join(resources_folder_path, "variables.tf"))
            self.assertTrue(
                dashboards_file_exists and folders_file_exists and output_file_exists and variables_file_exists,
                "dashboards.tf folders.tf output.tf variables.tf should exists in resources folder of appdir: %s" % (
                    self.appdir))

        if self.otelv2app:
            collection_folder_path = os.path.join(self.appdir, "collection")
            otconfig_file_exists = os.path.isfile(os.path.join(collection_folder_path, "otSourceConfig.yaml.tmpl"))
            uiconfig_file_exists = os.path.isfile(os.path.join(collection_folder_path, "uiConfigSchema.json"))
            preinstall_file_exists = os.path.isfile(os.path.join(collection_folder_path, "preinstall.md"))
            self.assertTrue(otconfig_file_exists and uiconfig_file_exists and preinstall_file_exists,
                            "otSourceConfig.yaml.tmpl uiConfigSchema.json and preinstall.md should exists in collection folder of appdir: %s" % (
                                self.appdir))
            example_file_exists = os.path.isfile(self.examplefile)
            self.assertTrue(example_file_exists,
                            "example file %s should exists in appdir: %s" % (self.examplefile, self.appdir))

        if self.nonotelv2app:
            if not (self.appname in EXCLUDED_APPS_WITHOUT_SC_PARAMS):
                config_yaml_exists = os.path.isfile(os.path.join(self.appdir, "config.yaml"))
                self.assertTrue(config_yaml_exists, "config.yaml should exists in appdir: %s" % (self.appdir),
                                warning=True)

    @skip_test_wrapper
    def test_validate_urls(self):
        def _validate_url(url_key, url_value):
            self.assertTrue(url_value != "", f"{url_key} is empty")
            resp = self._is_valid_url(url_value, url_key)
            self.assertTrue(resp.status_code == 200, "URL key: %s value: %s Throwing %d status_code Reason: %s" % (
                url_key, url_value, resp.status_code, resp.reason))

        _validate_url("supportUrl", self.manifestjson.get("author", {}).get("supportUrl"))
        homeURL = self.manifestjson.get("author", {}).get("homeUrl")
        if homeURL:
            _validate_url("homeUrl", homeURL)

    @skip_test_wrapper
    def test_valid_account_types(self):
        accountTypes = self.manifestjson.get("accountTypes", [])
        if accountTypes:
            valid_v2_account_types = account_type_mapping.values()
            for account_type in accountTypes:
                self.assertTrue(account_type in valid_v2_account_types, "Invalid account type")

    def extract_number_and_unit(input_string):
        match = re.match(r'(\d+)(\w+)', input_string)
        if match:
            number = int(match.group(1))
            unit = match.group(2)
            return number, unit
        else:
            return None, None

    def check_time_range_less_than_fifteen_minutes(self, triggers, location_text):
        if len(triggers) == 0:
            return
        for trigger in triggers:
            time_range = trigger.get("timeRange")
            if time_range:
                num, unit = self.extract_number_and_unit(time_range)
                if num and unit:
                    if unit == "m":
                        self.assertTrue(num < 15, f"Time range for {location_text} trigger is {num} minutes. It should be less than 15 minutes")
                    elif unit == "s":
                        num = num // 60
                        self.assertTrue(num < 15, f"Time range for {location_text} trigger is {num} seconds. It should be less than 15 minutes")
                    else:
                        self.assertTrue(False, f"Unknown unit error: {unit}. Time range for {location_text} trigger should be less than 15 minutes")

    def check_receipt_time_not_in_query(self, query_string, location_text):
        if re.search(r'\b_receiptTime\b', query_string):
            self.assertTrue(False, f"Receipt time should not be in query for {location_text}")

    def check_log_reduce_log_compare_not_present_in_query(self, query_string, location_text):
        if re.search(r'\b(logreduce|logcompare)\b', query_string, re.IGNORECASE):
            self.assertTrue(False, f"Log Reduce or Log Compare should not be in query for {location_text}")

    def check_timeshift_operator_not_present_in_query(self, query_string, location_text):
        if re.search(r'\btimeshift\b', query_string, re.IGNORECASE):
            self.assertTrue(False, f"Timeshift operator should not be in query for {location_text}")

    @skip_test_wrapper
    def test_monitors_time_range_less_than_fifteen_minutes(self):
        for _, monitor_name, triggers, _, _ in self.monitor_log_queries:
            self.check_time_range_less_than_fifteen_minutes(triggers, "Monitor: %s" % monitor_name)

        for _, monitor_name, triggers, _, _ in self.monitor_metric_queries:
            self.check_time_range_less_than_fifteen_minutes(triggers, "Monitor: %s" % monitor_name)

    @skip_test_wrapper
    def test_monitors_receipt_time_not_in_query(self):
        for query_string, monitor_name, _, _, _ in self.monitor_log_queries:
            self.check_receipt_time_not_in_query(query_string, "Monitor: %s" % monitor_name)

    @skip_test_wrapper
    def test_monitors_timeshift_not_present_in_query(self):
        for query_string, monitor_name, _, _, _ in self.monitor_log_queries:
            self.check_timeshift_operator_not_present_in_query(query_string, "Monitor: %s" % monitor_name)

        for query_string, monitor_name, _, _, _ in self.monitor_metric_queries:
            self.check_timeshift_operator_not_present_in_query(query_string, "Monitor: %s" % monitor_name)

    @skip_test_wrapper
    def test_monitors_log_reduce_log_compare_not_present_in_query(self):
        for query_string, monitor_name, _, _, _ in self.monitor_log_queries:
            self.check_log_reduce_log_compare_not_present_in_query(query_string, "Monitor: %s" % monitor_name)

    # below tests are for solutions which have hierarchy
    @skip_test_wrapper
    def test_correct_variable_ordering(self):
        pass

    @skip_test_wrapper
    def test_child_variable_has_parent_variable_filter(self):
        pass

    @skip_test_wrapper
    def test_has_correct_dashboard_entities(self):
        pass

    @classmethod
    def has_png_assets(cls, appdir: str):
        assets_folder = os.path.join(appdir, "assets")
        assets = cls.list_files_in_directory_recursive(assets_folder)
        status = all([file_path.lower().endswith('.png') for file_path in assets])
        if not status:
            invalid_files = "\n".join([file_path for file_path in assets if not file_path.lower().endswith('.png')])
            utils.warn(f"Found following invalid files: \n {invalid_files}")
        return status

    @classmethod
    def has_valid_terraform_files(cls, appdir: str):
        resources_folder = os.path.join(appdir, "resources")
        terraform_files = cls.list_files_in_directory_recursive(resources_folder)
        VALID_TERRAFORM_FILES_PATH = [os.path.join(resources_folder, file) for file in cls.VALID_TERRAFORM_FILES]
        status = all([file in VALID_TERRAFORM_FILES_PATH for file in terraform_files])
        if not status:
            invalid_files = "\n".join([file for file in terraform_files if file not in VALID_TERRAFORM_FILES_PATH])
            utils.warn(f"Found following invalid files: \n {invalid_files}")
        return status

    @classmethod
    def has_valid_static_files(cls, appdir: str):
        static_files = cls.list_files_in_directory(appdir)
        VALID_STATIC_FILES_PATH = [os.path.join(appdir, file) for file in cls.VALID_STATIC_FILES]
        status = all([file in VALID_STATIC_FILES_PATH for file in static_files])
        if not status:
            invalid_files = "\n".join([file for file in static_files if file not in VALID_STATIC_FILES_PATH])
            utils.warn(f"Found following invalid files: \n {invalid_files}")
        return status

    @classmethod
    def list_files_in_directory_recursive(cls, directory):
        file_list = []
        # returns hidden files
        for root, directories, files in os.walk(directory):
            for filename in files:
                filepath = os.path.join(root, filename)
                file_list.append(filepath)
        return file_list

    @classmethod
    def list_files_in_directory(cls, directory):
        file_list = []
        # returns hidden files
        for filename in os.listdir(directory):
            filepath = os.path.join(directory, filename)
            if os.path.isfile(filepath):
                file_list.append(filepath)
        return file_list

    @skip_test_wrapper
    def test_changelog(self):
        changelog_handler = KeepachangelogHandler(app_name=self.appname, changelog_filepath=self.appdir + '/CHANGELOG.md')
        app_version = VerifyUploadAction.get_latest_app_version_from_repo(utils.find_app_directory(self.appname))

        full_app_list_path = os.path.join(os.environ.get('SUMO_APPS_V2_REPO_PATH'), "scripts", "full_app_list.yaml")
        data = load_yaml_to_json(full_app_list_path)

        current_app = [app for app in data["apps"] if app["name"] == self.appname]
        current_app = current_app.pop() if current_app else None

        #  check current version
        test_result, message = changelog_handler.has_current_version(app_version)
        self.assertTrue(test_result, msg=message)

        #  check prevVersions exists
        if current_app:
            prev_versions = current_app.get("prevVersions", [])
            if not prev_versions and app_version != '1.0.0':
                self.assertTrue(False, msg=f"prevVersions is not available for app {self.appname}", warning=True)
            elif prev_versions:
                missing_versions = [version for version in prev_versions if not changelog_handler.has_changelog_version(version)]
                self.assertTrue(
                    len(missing_versions) == 0,
                    msg=f"Previous Versions do not exists in changelog - {','.join(missing_versions)} for app {self.appname}",
                )

        # check for validating changelog format as per specification
        test_has_valid_format = changelog_handler.has_valid_format()
        self.assertFalse(test_has_valid_format)

    @skip_test_wrapper
    def test_readme_links(self):
        readme_filepath = os.path.join(self.appdir, "README.md")
        link_pattern = r"\[[^\]]+\]\s*\((\s*[^)]+\s*)\)"
        link_pattern_compiled = re.compile(link_pattern)
        link_starting_path = "https://"
        relative_links = []
        with open(readme_filepath, 'r') as fin:
            for line in fin:
                pattern_match = link_pattern_compiled.findall(line)
                if pattern_match:
                    for item in set(pattern_match):
                        item = item.strip()
                        if (not item.startswith(link_starting_path)) and (not item.startswith("#")) and (not item.startswith("mailto")):
                            relative_links.append(item)
        relative_links = "\n".join(relative_links)
        self.assertTrue(len(relative_links) == 0, f"README.md should not contain relative links: {relative_links}")

    @skip_test_wrapper
    def test_text_panel_background_color(self):
        for dash in self.dashboards:
            if isinstance(dash, dict) and 'title' in dash:
                panels = dash["panel"]
                allPanels = [panels] if isinstance(panels, dict) else panels
                for panel in allPanels:
                    try:
                        panel_type = list(panel.keys())[0]
                        if panel_type == "text_panel":
                            visual_settings_json = json.loads(panel["text_panel"]["visual_settings"])
                            self.assertTrue(visual_settings_json['text']['backgroundColor'] == '#DFE5E9' and visual_settings_json['text']['textColor'] == '#222D3B',
                                f"App: {self.manifestjson['name']} backgroundColor should be #DFE5E9 and textColor should be #222D3B", warning=True)
                    except Exception as e:
                        logger.error("panelType not found in json of dashboard -", dash['title'])

    @skip_test_wrapper
    def test_text_panel_font_size(self):
        for dash in self.dashboards:
            if isinstance(dash, dict) and 'title' in dash:
                panels = dash["panel"]
                allPanels = [panels] if isinstance(panels, dict) else panels
                for panel in allPanels:
                    try:
                        panel_type = list(panel.keys())[0]
                        if panel_type == "text_panel":
                            visual_settings_json = json.loads(panel["text_panel"]["visual_settings"])
                            self.assertTrue(visual_settings_json['title']['fontSize'] == '20',
                                f"App: {self.manifestjson['name']} fontSize should be 20", warning=True)
                    except Exception as e:
                        logger.error("panelType not found in json of dashboard -", dash['title'])

    @skip_test_wrapper
    def test_svp_label(self):

        for dash in self.dashboards:
            if isinstance(dash, dict) and 'title' in dash:
                panels = dash["panel"]
                allPanels = [panels] if isinstance(panels, dict) else panels
                for panel in allPanels:
                    try:
                        panel_type = list(panel.keys())[0]
                        if panel_type == "sumo_search_panel":
                            visual_settings_json = json.loads(panel["sumo_search_panel"]["visual_settings"])
                            if visual_settings_json['general'] and visual_settings_json['general']['type'] == 'svp':
                                self.assertTrue(visual_settings_json['svp']['label'] != '',
                                    f"App: {self.manifestjson['name']} label should not be empty", warning=True)
                    except Exception as e:
                        logger.error("panelType not found in json of dashboard -", dash['title'])

    @skip_test_wrapper
    def test_panel_title(self):
        for dash in self.dashboards:
            if isinstance(dash, dict) and 'title' in dash:
                panels = dash["panel"]
                allPanels = [panels] if isinstance(panels, dict) else panels
                for panel in allPanels:
                    try:
                        panel_type = list(panel.keys())[0]
                        panel_title = panel.get("title",'') or panel.get('name', '')
                        panel_title_list = panel_title.split(' ')
                        self.assertTrue('the' not in panel_title_list, f"App: {self.manifestjson['name']} title should not contain `the`", warning=True)
                    except Exception as e:
                        logger.error("panelType not found in json of dashboard -", dash['title'])
